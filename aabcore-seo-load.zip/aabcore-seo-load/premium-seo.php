<?php
/**
 * Plugin Name: Page Meta Title & Description
 */

if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

class Aabcore_load_premium{






    public function __construct() {

    }





    public function aabcore_seo_l_premium() { 
		






    if (isset($_POST['aabcore_link_submit'])) {
        if ( ! isset( $_POST['aabcore_link_submit_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['aabcore_link_submit_nonce'])), 'aabcore_link_submit_settings' ) ) {
        return;
    }
        if (!isset($_POST['aabcorelink_field'])) return;

    $aabcoremykey=sanitize_text_field(wp_unslash($_POST['aabcorelink_field']));

    if($aabcoremykey==='Premium'){
    update_option('aabcore_plan','Your Current Plan free '.$aabcoremykey);}
    else if($aabcoremykey==='Enterprise'){
    update_option('aabcore_plan','Your Current Plan free '.$aabcoremykey);}
?>
		
            <br><br><br><br>
            <div class='inst'>

<h2>Congratulations! 🎉<br></h2>



<h3>Aabcore SEO Free <?php echo $aabcoremykey; ?> Version<br></h3>

<h4>Free <?php echo $aabcoremykey; ?> - <font style="color:red;"> 30%</font> Capable<br></h4>

<br><br><br>

<div style="width:300px;">
<a href='admin.php?page=aabcore-seo-load-seo-seo&aabcorepremiuma=seopload' class='btn btn-primary d-grid w-100' >Click to Load <?php echo $aabcoremykey; ?> Version</a></div></div>
<?php
		
	
die();
}



/*
   ?>





<form method="POST" action="<?php echo esc_url( admin_url('admin.php?page=aabcore-seo-load-seo-seo') ); ?>">

			  <?php   wp_nonce_field( 'aabcore_link_submit_settings', 'aabcore_link_submit_nonce' ); ?>

			 
          <div class="seo-seo_l_seo row mb-6">
            
            <div class="seo-seo_l_seo- col-sm-10-">

              <input type="hidden"  class="seo-seo_l_seo form-control" name="aabcorelink_field" id="aabcorelink_field" placeholder="License key" value="Enterprise">
            <br>
										   
										   </div>
<center>
        <input type="submit" name="aabcore_link_submit" value="Submit License Key" class='btn btn-primary d-grid w-100'>
     </form>














<?php
*/

         if (isset($_GET['aabcorepremiuma']) && $_GET['aabcorepremiuma'] == 'seopload') { ?>

            <div class='loadpl'>
            <br><br><h2>Downloading Aabcore Premium SEO</h2>
            <div class='inst'>
            <h3>Installing plugin</h3>
<?php 
            $wp_upgrader = new WP_Upgrader();
            $install = $wp_upgrader->run([
                "package"                       => 'https://aabcore-plugin.github.io/plugin/aabcore-seo.zip', // plugin_dir_path(__FILE__) . "aabcore-seo.zip",
                "destination"                   => str_replace("aabcore-seo-load","",plugin_dir_path( __FILE__ ))."/aabcore-seo",
                "clear_destination"             => true,
                "abort_if_destination_exists"   => false
            ]);
           
            if (is_array($install)) {
                echo("<b>Plugin installed!</b><br/><br/><br/>");
            }
            else {
                echo("<b>Could not install plugin!</b><br/><br/>");
                
            }
            
            $activate = activate_plugin(str_replace('/aabcore-seo-load','',plugin_dir_path( __FILE__ )).'aabcore-seo/aabcore-seo.php');
            if (!$activate) { // No errors
                echo("<b>Plugin activated!</b><br/><br/>");
            }            else { ?>
                <b>Could not activate plugin!</b><br/><br/>
                <a href='admin.php?page=aabcore-seo-load-seo-seo&aabcorepremiuma=yes' class='abot'>Continue to Active</button></a><?php die();
            } ?>
            <a href='admin.php?page=aabcore-seo-ho-seo-seo' class='abot'>Continue</a>
            </div></div>
            <?php die();
        }

?>


















<br><br><br><br>

  <!-- Pricing Plans -->
  <section class="section-py first-section-pt">
    <div class="container">
      <h2 class="text-center mb-2">Aabcore SEO Plan</h2>
      <h2 class="text-center mb-2">Click to Auto-Load SEO Plan</h2>
      <p class="text-center mb-0">

      </p>
      <div class="d-flex align-items-center justify-content-center flex-wrap gap-2 pt-9 pb-3 mb-2">
<br><br>
        <div class="mt-n5 ms-n10 ml-2 mb-10 d-none d-sm-flex align-items-center gap-1">
          <br>
          <br>
        </div>
      </div>

      <div class="row g-6">
        

        <!-- Pro -->
        <div class="col-lg">
          <div class="card border-primary border shadow-none">
            <div class="card-body position-relative pt-4">
              <div class="position-absolute end-0 me-5 top-0 mt-4">
                <span class="badge bg-label-primary rounded-1">Premium</span>
              </div>
              <div class="my-5 pt-6 text-center">


				  
               	<div class="row my-6" style="border:1px green solid;border-radius:5px;margin:0 20px;">
    <div class="col-12 text-center my-6">
      <h4 class="my-2"><font class="cred"></font>Free Premium - <font style="color:red;">30%</font> Capable</h4>


      <form method="POST" action="<?php echo esc_url( admin_url('admin.php?page=aabcore-seo-load-seo-seo') ); ?>">
			  <?php   wp_nonce_field( 'aabcore_link_submit_settings', 'aabcore_link_submit_nonce' ); ?>
              <input type="hidden"  class="seo-seo_l_seo form-control" name="aabcorelink_field" id="aabcorelink_field" placeholder="License key" value="Premium">
      <center>
        <input type="submit" name="aabcore_link_submit" value="Load Free Premium" class='btn btn-primary d-grid w-100-' style="padding:10px 50px;">
      </form>



</div>
<p>For small to medium businesses</p>
    </div>

<br><br>

				  
              </div>
              <h4 class="card-title text-center text-capitalize mb-1">Premium Plus <font style="color:red;">99%</font> Capable</h4>
              <p class="text-center mb-5">For small to medium businesses</p>
              <div class="text-center h-px-50">
                <div class="d-flex justify-content-center">
                  <sup class="h6 text-body pricing-currency mt-2 mb-0 me-1">$</sup>
                  <h1 class="price-toggle price-yearly text-primary mb-0">25</h1>
                  <h1 class="price-toggle price-monthly text-primary mb-0 d-none">9</h1>
                  <sub class="h6 text-body pricing-duration mt-auto mb-1 ms-1">/year</sub>
                </div>
                <small class="price-yearly price-yearly-toggle text-body-secondary">USD 25 / year</small>
              </div>

              <ul class="list-group my-5 pt-9">
  <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Free plugin solutions for every kind of website</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Static, Dynamic & WooCommerce Website optimization</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>WooCommerce Shop Page SEO</span>
                    </li>



                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>WooCommerce Products Page SEO</span>
                    </li>

                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Website speed optimization</span>
                    </li>
                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>XML sitemap optimization</span>
                    </li>
                
 <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Category page SEO</span>
                    </li>


     <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Maximum keywords targeting</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Product page optimization</span>
                    </li>



                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>On-page SEO</span>Keyword research<br>
Title tag optimization<br>
Meta descriptions<br>
Internal linking<br>
Content optimization<br>
Header structure (H1, H2, H3)<br>
Image SEO<br>
Entity-based optimization
                    </li>

                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Technical audit</span>
                    </li>
                
                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Local keyword targeting</span>
                    </li>

              </ul>
              <a href="https://aabcore.co.in/seo/seo-premium.php" class="btn btn-primary d-grid w-100" target="_blank">Upgrade</a>
            </div>
          </div>
        </div>

        <!-- Enterprise 
        <div class="col-lg">
          <div class="card border rounded shadow-none">
            <div class="card-body pt-12">
              <div class="mt-3 mb-5 text-center">
-->

        <div class="col-lg">
          <div class="card border-primary border shadow-none">
            <div class="card-body position-relative pt-4">
              <div class="position-absolute end-0 me-5 top-0 mt-4">
                <span class="badge bg-label-primary rounded-1">Enterprise</span>
              </div>
              <div class="my-5 pt-6 text-center">


				

				                 	<div class="row my-6" style="border:1px green solid;border-radius:5px;margin:0 20px;">
    <div class="col-12 text-center my-6">
      <h4 class="my-2"><font class="cred"></font>Free Enterprise - <font style="color:red;">30%</font> Capable</h4>


      <form method="POST" action="<?php echo esc_url( admin_url('admin.php?page=aabcore-seo-load-seo-seo') ); ?>">
			  <?php   wp_nonce_field( 'aabcore_link_submit_settings', 'aabcore_link_submit_nonce' ); ?>
              <input type="hidden"  class="seo-seo_l_seo form-control" name="aabcorelink_field" id="aabcorelink_field" placeholder="License key" value="Enterprise">
      <center>
        <input type="submit" name="aabcore_link_submit" value="Load Free Enterprise" class='btn btn-primary d-grid w-100-' style="padding:10px 50px;">
      </form>

   </div>
<p>Solution for big organizations</p>
    </div>

<br><br>


				  
              </div>
              <h4 class="card-title text-center text-capitalize mb-1">Enterprise Plus <font style="color:red;">99%</font> Capable</h4>
              <p class="text-center mb-5">Solution for big organizations</p>

              <div class="text-center h-px-50">
                <div class="d-flex justify-content-center">
                  <sup class="h6 text-body pricing-currency mt-2 mb-0 me-1">$</sup>
                  <h1 class="price-toggle price-yearly text-primary mb-0">30</h1>
                  <h1 class="price-toggle price-monthly text-primary mb-0 d-none">19</h1>
                  <sub class="h6 text-body pricing-duration mt-auto mb-1 ms-1">/year</sub>
                </div>
                <small class="price-yearly price-yearly-toggle text-body-secondary">USD 30 / year</small>
              </div>
              <ul class="list-group my-5 pt-9">


				   <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Free plugin solutions for every kind of website</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Static, Dynamic & WooCommerce Website optimization</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>WooCommerce Shop Page SEO</span>
                    </li>



                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>WooCommerce Products Page SEO</span>
                    </li>

                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Website speed optimization</span>
                    </li>
                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>XML sitemap optimization</span>
                    </li>
                
 <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Category page SEO</span>
                    </li>


     <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Maximum keywords targeting</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Product page optimization</span>
                    </li>



                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>On-page SEO</span>Keyword research<br>
Title tag optimization<br>
Meta descriptions<br>
Internal linking<br>
Content optimization<br>
Header structure (H1, H2, H3)<br>
Image SEO<br>
Entity-based optimization
                    </li>

                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Technical audit</span>
                    </li>
                
                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Local keyword targeting</span>
                    </li>



                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center" style="background-image: linear-gradient(to right, white , red);border-radius:5px;">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2" style=""><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Firewall protect website</span>
                    </li>





                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center" style="background-image: linear-gradient(to right, white , red);border-radius:5px;">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2" style=""><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Prevent Malware</span>
                    </li>


				  
              </ul>
              <a href="https://aabcore.co.in/seo/seo-premium.php" class="btn btn-primary d-grid w-100" target="_blank">Upgrade</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/ Pricing Plans -->







<?php

}



}

new Aabcore_load_premium();
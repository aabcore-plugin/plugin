<?php
/**
 * Plugin Name: Aabcore SEO Load
 * Plugin URI:        https://www.aabcore.co.in/seo/
 * Description:       Advanced SEO Plugin – Improve Google Rankings, Link Management, Keyword Tracking, Boost Traffic & Optimize Content.
 * Version:           109.0.5
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            aabcorec
 * Author URI:        https://www.aabcore.co.in/plugins.php
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: aabcore-seo-
 */








if ( ! defined( 'ABSPATH' ) ) exit; // No direct access admin_menu

define( 'AABCORE_SEO_PLUGINL_SEO_DIR', plugin_dir_path( __FILE__ ) );
define( 'AABCORE_SEO_LOAD_SEO_URL', plugin_dir_url( __FILE__ ) );


  class Aabcore_Home_seo_load_seo_seo{




		public function __construct() {

            add_action('admin_menu',  [$this,'aabcore_seo_loada_seo_seo']);
            add_action('admin_enqueue_scripts', [$this,'aabcore_seo_script_load_seo_seo' ]);
                }


       public function aabcore_seo_script_load_seo_seo() {



wp_enqueue_style( 'aabcore-iconify-icons-seo-seo', AABCORE_SEO_LOAD_SEO_URL. 'iconify-icons-seo-seo.css', array(),  filemtime(AABCORE_SEO_PLUGINL_SEO_DIR. 'iconify-icons-seo-seo.css' ) );

wp_enqueue_style( 'aabcore-core-seo-seo', AABCORE_SEO_LOAD_SEO_URL. 'core-seo-seo.css', array(),                     filemtime(AABCORE_SEO_PLUGINL_SEO_DIR. 'core-seo-seo.css' ) );


wp_enqueue_style( 'aabcore-bs-stepper-seo-seo', AABCORE_SEO_LOAD_SEO_URL. 'bs-stepper-seo-seo.css', array(),     filemtime(AABCORE_SEO_PLUGINL_SEO_DIR. 'bs-stepper-seo-seo.css' ) );

wp_enqueue_style( 'aabcore-tagify-seo-seo', AABCORE_SEO_LOAD_SEO_URL. 'tagify-seo-seo.css', array(),     filemtime(AABCORE_SEO_PLUGINL_SEO_DIR. 'tagify-seo-seo.css' ) );

	   }



        public function aabcore_seo_loada_seo_seo() {
             add_menu_page(
            'Aabcore SEO Load',                 // Page title
            'Aabcore SEO Load',                 // Menu title
            'manage_options',                // Capability
            'aabcore-seo-load-seo-seo',       // Menu slug
            [$this,'aabcore_seo_load_seo_c_seo']);     
            
                                       
        


     }



     public function aabcore_seo_load_seo_c_seo() {


        $Aabcore_load_premium= new Aabcore_load_premium(); 
        $Aabcore_load_premium->aabcore_seo_l_premium();

   }

     


   }




new Aabcore_Home_seo_load_seo_seo();


    require_once AABCORE_SEO_PLUGINL_SEO_DIR . 'premium-seo.php';


register_activation_hook(__FILE__, 'my_plugin_activate');

function my_plugin_activate() {
    add_option('my_plugin_activated', true);
}

add_action('admin_init', 'my_plugin_activation_redirect');

function my_plugin_activation_redirect() {

    if (get_option('my_plugin_activated')) {

        delete_option('my_plugin_activated');

        wp_safe_redirect(
            admin_url('admin.php?page=aabcore-seo-load-seo-seo')
        );

        exit;
    }
}


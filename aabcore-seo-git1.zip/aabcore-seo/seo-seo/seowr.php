<?php


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


	class AABCore_SEO_Wizard {
    private $option_namec = 'aabcore_seo_paeg';
    private $option_nameo = 'aabcore_seo_paeo';
    private $option_namep = 'aabcore_seo_paep';
    private $option_nameq = 'aabcore_seo_paeq';
		private $total_steps = 5;

    public function __construct() {

			add_action(
				'admin_post_aabcore_seo_wizard',
				array( $this, 'process_wizard' )
			);

			add_action(
				'admin_enqueue_scripts',
				array( $this, 'enqueue_assets' )
			);

			add_action(
				'admin_head',
				array( $this, 'admin_head' )
			);
		}



		private function is_wizard_page() {


			
			if ( ! is_admin() ) {
				return false;
			}

			
			if ( ! isset( $_GET['page'] ) ) {
				return false;
			}

			$page = sanitize_key(
				wp_unslash( $_GET['page'] )
			);

			return 'aabcore-seo-ho-seo-seo' === $page;
		}

		/**
		 * Hide WordPress interface on wizard page.
		 */
		public function admin_head() {

			if ( ! $this->is_wizard_page() ) {
				return;
			}

			?>
			<style>
				#adminmenumain,
				#wpadminbar,
				#wpfooter {
					display: none !important;
				}

				#wpcontent,
				#wpbody,
				#wpbody-content {
					margin: 0 !important;
					padding: 0 !important;
					width: 100% !important;
				}

				#wpcontent {
					margin-left: 0 !important;
				}
			</style>
			<?php
		}

		/**
		 * Load external wizard CSS.
		 */
		public function enqueue_assets() {

			
                if ( ! $this->is_wizard_page() ) {
				return;
			}

			wp_enqueue_style(
				'aabcore-seo-ho-seo-seo',
				AABCORE_SEO_PLUGIN_SEO_URL. 'seo-assets/wizard.css',
				array(),
				'109.0.5'
			);
		}

		/**
		 * Process wizard.
		 */
		public function process_wizard() {

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'You do not have permission to access this page.' );
			}

			check_admin_referer(
				'aabcore_seo_wizard',
				'aabcore_seo_wizard_nonce'
			);

			$step = 1;

			if ( isset( $_POST['wizard_step'] ) ) {
				$step = absint( $_POST['wizard_step'] );
			}

			if ( $step < 1 ) {
				$step = 1;
			}

			if ( $step > $this->total_steps ) {
				$step = $this->total_steps;
			}

			$action = '';

			if ( isset( $_POST['wizard_action'] ) ) {
				$action = sanitize_key(
					wp_unslash( $_POST['wizard_action'] )
				);
			}

			$this->save_step( $step );

			if ( 'back' === $action ) {

				$this->redirect_to_step(
					max( 1, $step - 1 )
				);
			}

			if ( 'next' === $action ) {

				$this->redirect_to_step(
					min(
						$this->total_steps,
						$step + 1
					)
				);
			}

			if ( 'finish' === $action ) {

				update_option(
					'aabcore_seo_wizard_completed',
					1
				);

				wp_safe_redirect(
					add_query_arg(
						array(
							'page'      => 'aabcore-seo-ho-seo-seo',
							'completed' => 1,
						),
						admin_url( 'admin.php' )
					)
				);

				exit;
			}

			$this->redirect_to_step( $step );
		}

		/**
		 * Save step data.
		 */
		private function save_step( $step ) {

			switch ( $step ) {

				case 1:

					$value = '';

					if ( isset( $_POST['site_name'] ) ) {
						$value = sanitize_text_field(
							wp_unslash( $_POST['site_name'] )
						);
					}


update_option($this->option_namec, [
            'aabcore_seo_site_name' => $value,
            'email'   => 'test',
         ]);


/*
					update_option(
						'aabcore_seo_site_name',
						$value
					);
*/
					break;

				case 2:

					$title = '';
					$description = '';

					if ( isset( $_POST['seo_title'] ) ) {
						$title = sanitize_text_field(
							wp_unslash( $_POST['seo_title'] )
						);
					}

					if ( isset( $_POST['seo_description'] ) ) {
						$description = sanitize_textarea_field(
							wp_unslash( $_POST['seo_description'] )
						);
					}



update_option($this->option_nameo, [
            'aabcore_seo_title' => $title,
            'aabcore_seo_description'   => $description,
         ]);


/*
					update_option(
						'aabcore_seo_title',
						$title
					);

					update_option(
						'aabcore_seo_description',
						$description
					);
*/
					break;

				case 3:

					$twitter = '';
					$facebook = '';

					if ( isset( $_POST['twitter_url'] ) ) {
						$twitter = esc_url_raw(
							wp_unslash( $_POST['twitter_url'] )
						);
					}

					if ( isset( $_POST['facebook_url'] ) ) {
						$facebook = esc_url_raw(
							wp_unslash( $_POST['facebook_url'] )
						);
					}


update_option($this->option_namep, [
            'aabcore_seo_twitter_url' => $twitter,
            'aabcore_seo_facebook_url'   => $facebook,
         ]);



/*
					update_option(
						'aabcore_seo_twitter_url',
						$twitter
					);

					update_option(
						'aabcore_seo_facebook_url',
						$facebook
					);
*/
					break;

				case 4:

					$robots = 'index,follow';

					if ( isset( $_POST['robots'] ) ) {
						$robots = sanitize_text_field(
							wp_unslash( $_POST['robots'] )
						);
					}

					$allowed_robots = array(
						'index,follow',
						'noindex,follow',
						'noindex,nofollow',
					);

					if ( ! in_array( $robots, $allowed_robots, true ) ) {
						$robots = 'index,follow';
					}


update_option($this->option_nameq, [
            'aabcore_seo_robots' => $robots,
            'now'   => 'to',
         ]);



/*
					update_option(
						'aabcore_seo_robots',
						$robots
					);
*/
					break;

				case 5:

					break;
			}
		}

		/**
		 * Redirect to wizard step.
		 */
		private function redirect_to_step( $step ) {

			$url = add_query_arg(
				array(
					'page' => 'aabcore-seo-ho-seo-seo',
					'step' => absint( $step ),
				),
				admin_url( 'admin.php' )
			);

			wp_safe_redirect( $url );
			exit;
		}

		/**
		 * Render wizard.
		 */
		public function render_page() {

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'Permission denied.' );
			}

			$step = 1;

			if ( isset( $_GET['step'] ) ) {
				$step = absint( $_GET['step'] );
			}

			if ( $step < 1 ) {
				$step = 1;
			}

			if ( $step > $this->total_steps ) {
				$step = $this->total_steps;
			}

			$completed = isset( $_GET['completed'] );

			?>
			<div class="aabcore-seo-wizard">

				<header class="aabcore-header">

					<div class="aabcore-brand">

						<div class="aabcore-logo">
							SEO
						</div>

						<div class="aabcore-brand-text">

							<strong>
								AABCore SEO
							</strong>

							<span>
								Setup Wizard
							</span>

						</div>

					</div>

					<div class="aabcore-step-count">

						Step <?php echo esc_html( $step ); ?>
						of
						<?php echo esc_html( $this->total_steps ); ?>

					</div>

				</header>

				<div class="aabcore-progress">
					<div
						class="aabcore-progress-bar"
						style="width: <?php echo esc_attr(
							( $step / $this->total_steps ) * 100
						); ?>%;"
					></div>
				</div>

				<div class="aabcore-step-list">

					<?php
					$step_titles = array(
						1 => 'Website',
						2 => 'SEO',
						3 => 'Social',
						4 => 'Robots',
						5 => 'Review',
					);

					foreach ( $step_titles as $number => $title ) {

						$class = '';

						if ( $number === $step ) {
							$class = 'active';
						} elseif ( $number < $step ) {
							$class = 'completed';
						}

						?>

						<div class="aabcore-step <?php echo esc_attr( $class ); ?>">

							<span class="aabcore-step-number">
								<?php echo esc_html( $number ); ?>
							</span>

							<span class="aabcore-step-title">
								<?php echo esc_html( $title ); ?>
							</span>

						</div>

						<?php
					}
					?>

				</div>

				<main class="aabcore-main">

					<div class="aabcore-container">

						<?php if ( $completed ) : ?>

							<?php $this->render_completed(); ?>

						<?php else : ?>

							<form
								method="post"
								action="<?php echo esc_url(
									admin_url( 'admin-post.php' )
								); ?>"
								class="aabcore-form"
							>

								<input
									type="hidden"
									name="action"
									value="aabcore_seo_wizard"
								>

								<input
									type="hidden"
									name="wizard_step"
									value="<?php echo esc_attr( $step ); ?>"
								>

								<?php
								wp_nonce_field(
									'aabcore_seo_wizard',
									'aabcore_seo_wizard_nonce'
								);
								?>

								<?php

								switch ( $step ) {

									case 1:
										$this->step_one();
										break;

									case 2:
										$this->step_two();
										break;

									case 3:
										$this->step_three();
										break;

									case 4:
										$this->step_four();
										break;

									case 5:
										$this->step_five();
										break;
								}

								?>

							</form>

						<?php endif; ?>

					</div>

				</main>

				<footer class="aabcore-footer">

					<span>
						AABCore SEO
					</span>

					<span>
						WordPress SEO Setup
					</span>

				</footer>

			</div>
			<?php
		}

		/**
		 * Step 1.
		 */
		private function step_one() {


$sitename = get_option($this->option_namec);
//echo $sitename['aabcore_seo_site_name'];


			$value =$sitename['aabcore_seo_site_name'];

			$this->heading(
				'Welcome to AABCore SEO',
				'Let us start with your website information.'
			);

			?>

			<div class="aabcore-card">

				<label for="site_name">
					Website Name
				</label>

				<input
					type="text"
					id="site_name"
					name="site_name"
					value="<?php echo esc_attr( $value ); ?>"
					placeholder="Your website name"
				>

				<p class="aabcore-help">
					Enter the name of your website or business.
				</p>

			</div>

			<?php

			$this->navigation( false, true, false );
		}

		/**
		 * Step 2.
		 */
		private function step_two() {



$sitetitle = get_option($this->option_nameo);
//echo $sitetitle['aabcore_seo_title'];
//echo $sitetitle['aabcore_seo_description'];



$title =$sitetitle['aabcore_seo_title'];
$description =$sitetitle['aabcore_seo_description'];

/*
			$title = get_option(
				'aabcore_seo_title',
				''
			);

			$description = get_option(
				'aabcore_seo_description',
				''
			);
*/
			$this->heading(
				'SEO Settings',
				'Configure your basic search engine metadata.'
			);

			?>

			<div class="aabcore-card">

				<label for="seo_title">
					SEO Title
				</label>

				<input
					type="text"
					id="seo_title"
					name="seo_title"
					value="<?php echo esc_attr( $title ); ?>"
					placeholder="Your website SEO title"
				>

				<label for="seo_description">
					Meta Description
				</label>

				<input type="text" 
					id="seo_description"
					name="seo_description"
					rows="5"
					placeholder="Describe your website..."
				value="<?php echo esc_textarea( $description ); ?>">

			</div>

			<?php

			$this->navigation( true, true, false );
		}

		/**
		 * Step 3.
		 */
		private function step_three() {



$sitetwi = get_option($this->option_namep);
$twitter =$sitetwi['aabcore_seo_twitter_url'];
$facebook =$sitetwi['aabcore_seo_facebook_url'];




/*
			$twitter = get_option(
				'aabcore_seo_twitter_url',
				''
			);

			$facebook = get_option(
				'aabcore_seo_facebook_url',
				''
			);
*/
			$this->heading(
				'Social Profiles',
				'Connect your social profiles for social SEO.'
			);

			?>

			<div class="aabcore-card">

				<label for="twitter_url">
					Twitter / X URL
				</label>

				<input
					type="url"
					id="twitter_url"
					name="twitter_url"
					value="<?php echo esc_attr( $twitter ); ?>"
					placeholder="https://x.com/example"
				>

				<label for="facebook_url">
					Facebook URL
				</label>

				<input
					type="url"
					id="facebook_url"
					name="facebook_url"
					value="<?php echo esc_attr( $facebook ); ?>"
					placeholder="https://facebook.com/example"
				>

			</div>

			<?php

			$this->navigation( true, true, false );
		}

		/**
		 * Step 4.
		 */
		private function step_four() {

$srobots = get_option($this->option_nameq);
$robots =$srobots['aabcore_seo_robots'];


/*
			$robots = get_option(
				'aabcore_seo_robots',
				'index,follow'
			);
*/
			$this->heading(
				'Search Engine Settings',
				'Choose how search engines should crawl your website.'
			);

			?>

			<div class="aabcore-card">

				<label for="robots">
					Robots Directive
				</label>

				<select
					id="robots"
					name="robots"
				>

					<option
						value="index,follow"
						<?php selected( $robots, 'index,follow' ); ?>
					>
						Index & Follow
					</option>

					<option
						value="noindex,follow"
						<?php selected( $robots, 'noindex,follow' ); ?>
					>
						No Index & Follow
					</option>

					<option
						value="noindex,nofollow"
						<?php selected( $robots, 'noindex,nofollow' ); ?>
					>
						No Index & No Follow
					</option>

				</select>

			</div>

			<?php

			$this->navigation( true, true, false );
		}

		/**
		 * Step 5.
		 */
		private function step_five() {

$sitename = get_option($this->option_namec);
//echo $sitename['aabcore_seo_site_name'];



			$site_name = $sitename['aabcore_seo_site_name'];
$sitetitle = get_option($this->option_nameo);
$title =$sitetitle['aabcore_seo_title'];
$description =$sitetitle['aabcore_seo_description'];

/*
			$title = get_option(
				'aabcore_seo_title',
				''
			);

			$description = get_option(
				'aabcore_seo_description',
				''
			);
*/


$sitetwi = get_option($this->option_namep);
$twitter =$sitetwi['aabcore_seo_twitter_url'];
$facebook =$sitetwi['aabcore_seo_facebook_url'];


$srobots = get_option($this->option_nameq);
$robots =$srobots['aabcore_seo_robots'];






			$this->heading(
				'Review Your Settings',
				'Everything looks good? Finish the setup below.'
			);

			?>

			<div class="aabcore-review">

				<div class="aabcore-review-row">
					<strong>Website</strong>

					<span>
						<?php echo esc_html( $site_name ); ?>
					</span>
				</div>

				<div class="aabcore-review-row">
					<strong>SEO Title</strong>

					<span>
						<?php
						echo esc_html(
							$title ? $title : 'Not configured'
						);
						?>
					</span>
				</div>

				<div class="aabcore-review-row">
					<strong>Meta Description</strong>

					<span>
						<?php
						echo esc_html(
							$description ? $description : 'Not configured'
						);
						?>
					</span>
				</div>

				<div class="aabcore-review-row">
					<strong>Twitter / X</strong>

					<span>
						<?php
						echo esc_html(
							$twitter ? $twitter : 'Not configured'
						);
						?>
					</span>
				</div>

				<div class="aabcore-review-row">
					<strong>Facebook</strong>

					<span>
						<?php
						echo esc_html(
							$facebook ? $facebook : 'Not configured'
						);
						?>
					</span>
				</div>

				<div class="aabcore-review-row">
					<strong>Robots</strong>

					<span>
						<?php echo esc_html( $robots ); ?>
					</span>
				</div>

			</div>

			<?php

			$this->navigation( true, false, true );
		}

		/**
		 * Heading.
		 */
		private function heading( $title, $description ) {

			?>

			<div class="aabcore-heading">

				<div class="aabcore-heading-icon">
					✓
				</div>

				<h1>
					<?php echo esc_html( $title ); ?>
				</h1>

				<p>
					<?php echo esc_html( $description ); ?>
				</p>

			</div>

			<?php
		}

		/**
		 * Navigation.
		 */
		private function navigation(
			$back = true,
			$next = true,
			$finish = false
		) {

			?>

			<div class="aabcore-navigation">

				<div class="aabcore-navigation-left">

					<?php if ( $back ) : ?>

						<button
							type="submit"
							name="wizard_action"
							value="back"
							class="aabcore-button aabcore-button-secondary"
						>
							← Back
						</button>

					<?php endif; ?>

				</div>

				<div class="aabcore-navigation-right">

					<?php if ( $next ) : ?>

						<button 
							type="submit"
							name="wizard_action"
							value="next"
							class="aabcore-button aabcore-button-primary"
						>
							Continue →
						</button>

					<?php endif; ?>

					<?php if ( $finish ) : ?>

						<button
							type="submit"
							name="wizard_action"
							value="finish"
							class="aabcore-button aabcore-button-primary"
						>
							Finish Setup ✓
						</button>

					<?php endif; ?>

				</div>

			</div>

			<?php
		}

		/**
		 * Completed page.
		 */
		private function render_completed() {

			?>

			<div class="aabcore-completed">

				<div class="aabcore-completed-icon">
					✓
				</div>

				<h1>
					Setup Complete!
				</h1>

				<p>
					AABCore SEO has been configured successfully.
				</p>

				<a
					href="admin.php?page=aabcore-seo-home-seo-seo<?php //echo esc_url( admin_url() ); ?>"
					class="aabcore-button aabcore-button-primary"
				>
					Go to WordPress Dashboard
				</a>

			</div>

			<?php
		}
	}

new AABCore_SEO_Wizard();

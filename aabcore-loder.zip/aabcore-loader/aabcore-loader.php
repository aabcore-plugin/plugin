<?php
/**
 * Plugin Name: Aabcore Loader
 * Plugin URI:        https://www.aabcore.co.in/seo/
 * Description:       Advanced SEO Plugin – Improve Google Rankings, Link Management, Keyword Tracking, Boost Traffic & Optimize Content.
 * Version:           100.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            aabcore
 * Author URI:        https://www.aabcore.co.in/plugins.php
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: aabcore-loader
 */








if ( ! defined( 'ABSPATH' ) ) exit; // No direct access admin_menu

define( 'AABCORE_SEO_PLUGINL_SEO_DIR', plugin_dir_path( __FILE__ ) );
define( 'AABCORE_SEO_LOAD_SEO_URL', plugin_dir_url( __FILE__ ) );


  class Aabcore_Home_seo_load_seo_seo{

        	public $plugin_slug;
		public $version;
		public $cache_key;
		public $cache_allowed;


		public function __construct() {

			$this->plugin_slug = plugin_basename( __DIR__ );
			$this->version = get_option('aabcore_seo_load');
			$this->cache_key = 'aabcore-loader';
			$this->cache_allowed = false;

			add_filter( 'plugins_api', array( $this, 'infol' ), 20, 3 );
			add_filter( 'site_transient_update_plugins', array( $this, 'aabcore_updatel' ) );
			add_action( 'upgrader_process_complete', array( $this, 'purgel' ), 10, 2 );


            add_action('admin_menu',  [$this,'aabcore_seo_loada_seo_seo']);
            add_action('admin_enqueue_scripts', [$this,'aabcore_seo_script_load_seo_seo' ]);

          update_option('aabcore_seo_load', $this->get_load_version());
                }



    public static function get_load_version() {
        $readme = plugin_dir_path( __FILE__ ) . 'readme.txt';

        if ( ! file_exists( $readme ) ) {
            return null;
        }

        $contents = file_get_contents( $readme );

        if ( preg_match( '/^Stable tag:\s*(.+)$/mi', $contents, $matches ) ) {
            
            return trim( $matches[1] );
        }

        return null;
    }



       public function aabcore_seo_script_load_seo_seo() {



wp_enqueue_style( 'aabcore-iconify-icons-seo-seo', AABCORE_SEO_LOAD_SEO_URL. 'iconify-icons-seo-seo.css', array(),  filemtime(AABCORE_SEO_PLUGINL_SEO_DIR. 'iconify-icons-seo-seo.css' ) );

wp_enqueue_style( 'aabcore-core-seo-seo', AABCORE_SEO_LOAD_SEO_URL. 'core-seo-seo.css', array(),                     filemtime(AABCORE_SEO_PLUGINL_SEO_DIR. 'core-seo-seo.css' ) );


wp_enqueue_style( 'aabcore-bs-stepper-seo-seo', AABCORE_SEO_LOAD_SEO_URL. 'bs-stepper-seo-seo.css', array(),     filemtime(AABCORE_SEO_PLUGINL_SEO_DIR. 'bs-stepper-seo-seo.css' ) );

wp_enqueue_style( 'aabcore-tagify-seo-seo', AABCORE_SEO_LOAD_SEO_URL. 'tagify-seo-seo.css', array(),     filemtime(AABCORE_SEO_PLUGINL_SEO_DIR. 'tagify-seo-seo.css' ) );

	   }



        public function aabcore_seo_loada_seo_seo() {
             add_menu_page(
            'Aabcore Loader',                 // Page title
            'Aabcore Loader',                 // Menu title
            'manage_options',                // Capability
            'aabcore-seo-load-seo-seo',       // Menu slug
            [$this,'aabcore_seo_load_seo_c_seo']);     
            
                                       
        


     }



     public function aabcore_seo_load_seo_c_seo() {


        $Aabcore_load_premium= new Aabcore_load_premium(); 
        $Aabcore_load_premium->aabcore_seo_l_premium();

   }

     
















		public function requestl(){

			$remote = get_transient( $this->cache_key );

			if( false === $remote || ! $this->cache_allowed ) {

				$remote = wp_remote_get(
					'https://aabcore-plugin.github.io/plugin/load-update.json',
					array(
						'timeout' => 10,
						'headers' => array(
							'Accept' => 'application/json'
						)
					)
				);

				if(
					is_wp_error( $remote )
					|| 200 !== wp_remote_retrieve_response_code( $remote )
					|| empty( wp_remote_retrieve_body( $remote ) )
				) {
					return false;
				}

				set_transient( $this->cache_key, $remote, DAY_IN_SECONDS );

			}

			$remote = json_decode( wp_remote_retrieve_body( $remote ) );

			return $remote;

		}


		function infol( $res, $action, $args ) {

			// print_r( $action );
			// print_r( $args );

			// do nothing if you're not getting plugin information right now
			if( 'plugin_information' !== $action ) {
				return $res;
			}

			// do nothing if it is not our plugin
			if( $this->plugin_slug !== $args->slug ) {
				return $res;
			}

			// get updates
			$remote = $this->requestl();

			if( ! $remote ) {
				return $res;
			}

			$res = new stdClass();

			$res->name = $remote->name;
			$res->slug = $remote->slug;
			$res->version = $remote->version;
			//$res->tested = $remote->tested;
			$res->requires = $remote->requires;
			$res->author = $remote->author;
			$res->author_profile = $remote->author_profile;
		      //$res->download_link = $remote->download_url;
                        $res->download_link = $remote->download_url;
                        $res->slug = $this->plugin_slug;
                        
			$res->trunk = $remote->download_url;
			$res->requires_php = $remote->requires_php;
			$res->last_updated = $remote->last_updated;

			$res->sections = array(
				'description' => $remote->sections->description,
				'installation' => $remote->sections->installation,
				'changelog' => $remote->sections->changelog
			);

			if( ! empty( $remote->banners ) ) {
				$res->banners = array(
					'low' => $remote->banners->low,
					'high' => $remote->banners->high
				);
			}

			return $res;

		}

		public function aabcore_updatel( $transient ) {

			if ( empty($transient->checked ) ) {
				return $transient;
			}

			$remote = $this->requestl();

			if(
				$remote
				&& version_compare( $this->version, $remote->version, '<' )
				&& version_compare( $remote->requires, get_bloginfo( 'version' ), '<=' )
				&& version_compare( $remote->requires_php, PHP_VERSION, '<' )
			) {
				$res = new stdClass();
				$res->slug = $this->plugin_slug;
				$res->plugin = plugin_basename( __FILE__ ); 
				$res->new_version = $remote->version;
				$res->tested = $remote->tested;
				$res->package = $remote->download_url;

				$transient->response[ $res->plugin ] = $res;

	    }

			return $transient;

		}

		public function purgel( $upgrader, $options ){

			if (
				$this->cache_allowed
				&& 'update' === $options['action']
				&& 'plugin' === $options[ 'type' ]
			) {
				// just clean the cache when new plugin version is installed
				delete_transient( $this->cache_key );
			}

		}






















   }




new Aabcore_Home_seo_load_seo_seo();


    require_once AABCORE_SEO_PLUGINL_SEO_DIR . 'premium-seo.php';


register_activation_hook(__FILE__, 'my_plugin_activate');

function my_plugin_activate() {
    add_option('my_plugin_activated', true);
}

add_action('admin_init', 'my_plugin_activation_redirect');

function my_plugin_activation_redirect() {

    if (get_option('my_plugin_activated')) {

        delete_option('my_plugin_activated');

        wp_safe_redirect(
            admin_url('admin.php?page=aabcore-seo-load-seo-seo')
        );

        exit;
    }
}


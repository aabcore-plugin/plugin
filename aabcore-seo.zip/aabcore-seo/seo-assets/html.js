jQuery(document).ready(function ($) {

    $('#aabcore_link_form').on('submit', function (e) {
        e.preventDefault();

        $.ajax({
            type: 'POST',
            url: ajaxurl, // available in admin pages
            data: {
                action: 'aabcore_link_submit',
                aabcorelink_field: $('#aabcorelink_field').val(),
                aabcore_link_submit_nonce: $('#aabcore_link_submit_nonce').val()
            },
            success: function (response) {
                $('#aabcore_result').html(response);
            }
        });

    });

});
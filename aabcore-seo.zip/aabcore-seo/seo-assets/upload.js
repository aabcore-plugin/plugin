       jQuery(document).ready(function($){

            var frame;

            $('.upload-btn').click(function(e){
                e.preventDefault();




                var target = $(this).data('target');

                frame = wp.media({
                    title: 'Select Image',
                    button: { text: 'Use Image' },
                    multiple: false
                });

                frame.on('select', function(){
                    var attachment = frame.state().get('selection').first().toJSON();

                $('#aabcore_seo_up_seo_me_seo_' + target).show();

                    $('#' + target).val(attachment.id);
                    $('#preview_' + target).html('<img style=\"width:150px;height:100px;\" src=\"' + attachment.sizes.thumbnail.url + '\" />');
                    $('#hide_' + target).hide();
                    $('#aabcore_seo_img_seo_url_seo_' + target).val(attachment.sizes.thumbnail.url);

                });

                frame.open();
            });


            $('#image-upload-form').submit(function(){
                $('#upload-message').show();
            });

        });
function go(e) {
  e.preventDefault();
  const value = document.getElementById("name").value;
  window.location.href = "admin.php?page=aabcore-seo-audit-seo-p-seo&name=" + encodeURIComponent(value);
}
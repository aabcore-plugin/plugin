jQuery(document).ready(function ($) {
    // Handle Toggle Switches
    $(".aabcore-cache-togg-cache").on("change", function () {


   //message("info", "⏳ Saving...");


        var checkbox = $(this);
        var optionName = checkbox.data("option");

  // $("#" + optionName + "-status").text("⏳ Saving...");

        var state = checkbox.is(":checked") ? "on" : "off";

        $("#" + optionName + "-s-seo-seo").text("⏳ Saving...");

        $.post(Aabcore_tmss2_ajax.ajax_url, {
            action: "aabcore_l_up_seo_seo_op_seo",
            option_name: optionName,
            state: state,
            nonce: Aabcore_tmss2_ajax.nonce,
        }).done(function (response) {
            if (response.success) {
               // $("#" + optionName + "-s-cache").text(response.data.state.toUpperCase());
                $("#" + optionName + "-sw-cache").show();


                                     
    if(response.data.state=='on'){
         $("#" + optionName + "-s-seo-seo").text('✅');
         $("#" + optionName + "-on-cache").text('Enable');
         $("#" + optionName + "-tw-cache").text('✅');
                $("#" + optionName + "-seo-wa-seo-seo").hide();
                $("#" + optionName + "-seo-pri-seo-seo").show(); 
                $("#" + optionName + "-txt-cache").text('85%'); 
                $("#" + optionName + "-pan-cache").hide();
    }else{
                $("#" + optionName + "-s-seo-seo").text('❌');
                $("#" + optionName + "-seo-wa-seo-seo").show(); 
                $("#" + optionName + "-seo-pri-seo-seo").hide();
                $("#" + optionName + "-txt-cache").text('15%');
                $("#" + optionName + "-pan-cache").show();
    $("#" + optionName + "-sw-cache").hide();
    $("#" + optionName + "-on-cache").text('OFF');
    $("#" + optionName + "-tw-cache").text('❌========');
    }

            } else {
                alert("Error: " + response.data);
            }
        });
    });






/*

    // Handle First Select
    $("#aab-cache-cdn-caching").on("change", function () {
        var select = $(this);
        var optionName = select.data("option");
        var value = select.val();
        $.post(Aabcore_tmss2_ajax.ajax_url, {
            action: "aabcore_up_cache_op_cache",
            option_name: optionName,
            state: value,
            nonce: Aabcore_tmss2_ajax.nonce,
        }).done(function (response) {
            if (response.success) {
                $("#" + optionName + "-status").text( '✅ ' +response.data.state.toUpperCase());
            } else {
                alert("Error: " + response.data);
            }
        });
    });

*/












  /*
    // Handle First Select
    $("#tms-select-one").on("change", function () {
        var select = $(this);
        var optionName = select.data("option");
        var value = select.val();
        $.post(Aabcore_tmss2_ajax.ajax_url, {
            action: "aabcore_up_cache_op_cache",
            option_name: optionName,
            state: value,
            nonce: Aabcore_tmss2_ajax.nonce,
        }).done(function (response) {
            if (response.success) {
                $("#" + optionName + "-status").text(response.data.state.toUpperCase());
            } else {
                alert("Error: " + response.data);
            }
        });
    });
  */
    // Handle Second Select
    $("#aabc-cache-cla-cache").on("change", function () {
        var select = $(this);
        var optionName = select.data("option");
        var value = select.val();

        $("#" + optionName + "-seo-c-seo").text("⏳ Saving...");


        $.post(Aabcore_tmss2_ajax.ajax_url, {
            action: "aabcore_up_cache_op_cache",
            option_name: optionName,
            state: value,
            nonce: Aabcore_tmss2_ajax.nonce,
        }).done(function (response) {
       
        $("#" + optionName + "-seo-c-seo").text(response.data.state);

//if(response.data.state=='on'){

            if (response.data.state=='Basic Icons SEO Form') {


$("#" + optionName + "-seo-n-seo").hide();
$("#" + optionName + "-seo-m-seo").hide();
$("#" + optionName + "-seo-q-seo").hide();
$("#" + optionName + "-seo-p-seo").show();

            } else if (response.data.state=='Vertical Icons SEO Form') {

$("#" + optionName + "-seo-n-seo").hide();
$("#" + optionName + "-seo-m-seo").hide();
$("#" + optionName + "-seo-q-seo").show();
$("#" + optionName + "-seo-p-seo").hide();

            } else if (response.data.state=='Modern seo Icons Form') {


$("#" + optionName + "-seo-n-seo").hide();
$("#" + optionName + "-seo-m-seo").show();
$("#" + optionName + "-seo-q-seo").hide();
$("#" + optionName + "-seo-p-seo").hide();

            } else if (response.data.state=='Simple Icons SEO Form') {


$("#" + optionName + "-seo-n-seo").show();
$("#" + optionName + "-seo-m-seo").hide();
$("#" + optionName + "-seo-q-seo").hide();
$("#" + optionName + "-seo-p-seo").hide();
            }





        });
    });


    // Handle Second Select
    $("#aabc-cache-clb-cache").on("change", function () {
        var select = $(this);
        var optionName = select.data("option");
        var value = select.val();
        $("#" + optionName + "-stas-cache").text("⏳ Saving...");
        $.post(tmss2_ajax.ajax_url, {
            action: "aabcore_up_cache_op_cache",
            option_name: optionName,
            state: value,
            nonce: tmss2_ajax.nonce,
        }).done(function (response) {
            if (response.success) {
                $("#" + optionName + "-sta-cache").text(response.data.state);
                $("#" + optionName + "-stas-cache").text(response.data.state);
            } else {
                alert("Error: " + response.data);
            }
        });
    });





     // Handle Second Select
    $("#aabc-cache-clc-cache").on("change", function () {
        var select = $(this);
        var optionName = select.data("option");
        var value = select.val();
        $("#" + optionName + "-stas-cache").text("⏳ Saving...");
        $.post(tmss2_ajax.ajax_url, {
            action: "aabcore_up_cache_op_cache",
            option_name: optionName,
            state: value,
            nonce: tmss2_ajax.nonce,
        }).done(function (response) {
            if (response.success) {
                $("#" + optionName + "-sta-cache").text(response.data.state);
                $("#" + optionName + "-stas-cache").text(response.data.state);
            } else {
                alert("Error: " + response.data);
            }
        });
    });


    // Handle Second Select
    $("#aabc-cache-cld-cache").on("change", function () {
        var select = $(this);
        var optionName = select.data("option");
        var value = select.val();
        $("#" + optionName + "-stas-cache").text("⏳ Saving...");
        $.post(tmss2_ajax.ajax_url, {
            action: "aabcore_up_cache_op_cache",
            option_name: optionName,
            state: value,
            nonce: tmss2_ajax.nonce,
        }).done(function (response) {
            if (response.success) {
                $("#" + optionName + "-sta-cache").text(response.data.state);
                $("#" + optionName + "-stas-cache").text(response.data.state);
            } else {
                alert("Error: " + response.data);
            }
        });
    });




});
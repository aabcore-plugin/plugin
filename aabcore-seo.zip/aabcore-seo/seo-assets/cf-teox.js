jQuery(document).ready(function ($) {

    function message(type, text) {
        $("#cf-message").html(`<div class="notice notice-${type}"><p>${text}</p></div>`);
    }

    // SAVE SETTINGS
    $("#aabcore-cdn-cache-btaotax").on("click", function () {

        //message("info", "⏳ Saving...");
        $('#aabcore-cache-cdn-key').text("⏳ Saving...");

        var indexType = $('input[name="aabcore_seo_ind_seo"]:checked').val();
        var followType = $('input[name="aabcore_seo_folw_seo"]:checked').val();

        $.post(Aabcore_CF_AJAX_teox.ajax_url, {
            action: "aabcore_seo_cdn_settings_ttexo",
            post_id: $('#post_ido').val(),

            aabcore_seo_tit_seo_aj_seo_seo: $("#aabcore_seo_title_seo").val(),
            aabcore_seo_desc_seo_aj_seo_seo:   $("#aabcore_seo_desc_seo").val(),
            aabcore_seo_key_seo_aj_seo_seo: $("#aabcore_seo_keyw_seo").val(),
            aabcore_seo_index_seo_aj_seo_seo:indexType,
            aabcore_seo_follow_seo_aj_seo_seo:followType,
            aabcore_seo_cnl_seo_aj_seo_seo: $("#aabcore_seo_cal_seo").val(),

            aabcore_f_seo_tit_seo_aj_seo_seo: $("#aabcore_seo_f_seo_title_seo").val(),
            aabcore_f_seo_desc_seo_aj_seo_seo:   $("#aabcore_seo_f_seo_desc_seo").val(),
            aabcore_f_seo_type_seo_aj_seo_seo: $("#aabcore_seo_f_seo_type_seo").val(),
            aabcore_f_seo_url_seo_aj_seo_seo: $("#aabcore_seo_img_seo_url_seo_image1").val(),

            aabcore_t_seo_tit_seo_aj_seo_seo: $("#aabcore_seo_t_seo_title_seo").val(),
            aabcore_t_seo_desc_seo_aj_seo_seo:   $("#aabcore_seo_t_seo_desc_seo").val(),
            aabcore_t_seo_url_seo_aj_seo_seo: $("#aabcore_seo_img_seo_url_seo_image2").val(),





            _ajax_nonce: Aabcore_CF_AJAX_teox.nonce
        }, function (response) {
            if (response.success) {
                //message("success", response.data);
             $('#aabcore-cache-cdn-key').text(response.data);
$('#for_cache_cdn_cache-on-cache').text('Enable');
$('#for_cache_cdn_cache-tw-cache').text('✅');
$('#cache-botl-cache').hide('');
             } else {
                //message("error", response.data);
             $('#aabcore-cache-cdn-key').text(response.data);
$('#for_cache_cdn_cache-on-cache').text('OFF');
$('#for_cache_cdn_cache-tw-cache').text('❌');
$('#cache-botl-cache').show('');
            }
        });
    });


    // PURGE URL
    $("#aabcore-cdn-cache-btb").on("click", function () {

       // message("info", "⏳ Purging URL...");
      $('#aabcore-cache-cdn-url').text("⏳ Purging URL...");

        $.post(CF_AJAX.ajax_url, {
            action: "aabcore_cache_cdn_cache_purge_url",
            url: $("#aabcore-cache-k-cdn-url").val(),
            _ajax_nonce: CF_AJAX.nonce
        }, function (response) {
            if (response.success) {
                //message("success", response.data);
          $('#aabcore-cache-cdn-url').text(response.data);
            } else {
                //message("error", response.data);
          $('#aabcore-cache-cdn-url').text(response.data);
            }
        });

    });




    // PURGE URLS
    $("#aabcore-cdn-cache-btc").on("click", function () {

        //message("info", "⏳ Purging URL...");

   $('#aabcore-cache-cdn-all').text("⏳ Purging URLS...");

        $.post(CF_AJAX.ajax_url, {
            action: "aabcore_cache_cdn_cache_purge_urlall",
            url: $("#aabcore-cache-k-cdn-allurl").val(),
            _ajax_nonce: CF_AJAX.nonce
        }, function (response) {
            if (response.success) {
               // message("success", response.data);
                $('#aabcore-cache-cdn-all').text(response.data);
            } else {
                //message("error", response.data);
       $('#aabcore-cache-cdn-all').text(response.data);
            }
        });

    });


    
    


     
    // MINIFY CSS
    $("#aabcore-cache-cdn-cs-btn").on("click", function () {

        //message("info", "⏳ Purging URL...");

   $('#aabcore-cache-cs-cache-cdn').text("⏳ Purging URLS...");

        $.post(CF_AJAX.ajax_url, {
            action: "aabcore_cache_cf_cache_cs_cache",
            url: $("#aabcore-cache-url-cache-ula").val(),
            _ajax_nonce: CF_AJAX.nonce
        }, function (response) {
            if (response.success) {
               // message("success", response.data);
                $('#aabcore-cache-cs-cache-cdn').text(response.data);
            } else {
                //message("error", response.data);
       $('#aabcore-cache-cs-cache-cdn').text(response.data);
            }
        });

    });







      
     
    // MINIFY CSS
    $("#aabcore-cache-cdn-js-btn").on("click", function () {

        //message("info", "⏳ Purging URL...");

   $('#aabcore-cache-js-cache-cdn').text("⏳ Purging URLS...");

        $.post(CF_AJAX.ajax_url, {
            action: "aabcore_cache_cf_cache_js_cache",
            url: $("#aabcore-cache-url-cache-ulb").val(),
            _ajax_nonce: CF_AJAX.nonce
        }, function (response) {
            if (response.success) {
               // message("success", response.data);
                $('#aabcore-cache-js-cache-cdn').text(response.data);
            } else {
                //message("error", response.data);
       $('#aabcore-cache-js-cache-cdn').text(response.data);
            }
        });

    });








    // Purge my url
    $("#aabcore-cache-btnb").on("click", function () {

        //message("info", "⏳ Purging URL...");

   $('#aabcore_cache_myst_cache').text("⏳ Purging URLS...");

        $.post(CF_AJAX.ajax_url, {
            action: "aabcore_cache_my_cache",
            url: $("#aabcore_cache_my_cache").val(),
            _ajax_nonce: CF_AJAX.nonce
        }, function (response) {
            if (response.success) {
               // message("success", response.data);
                $('#aabcore_cache_myst_cache').text(response.data);
            } else {
                //message("error", response.data);
       $('#aabcore_cache_myst_cache').text(response.data);
            }
        });

    });





    // Purge my url
    $("#aabcore-cache-btna").on("click", function () {

        //message("info", "⏳ Purging URL...");

   $('#aabcore_cache_allst_cache').text("⏳ Purging URLS...");

        $.post(CF_AJAX.ajax_url, {
            action: "aabcore_cache_all_cache",
            url: $("#aabcore_cache_all_cache").val(),
            _ajax_nonce: CF_AJAX.nonce
        }, function (response) {
            if (response.success) {
               // message("success", response.data);
                $('#aabcore_cache_allst_cache').text(response.data);
            } else {
                //message("error", response.data);
       $('#aabcore_cache_allst_cache').text(response.data);
            }
        });

    });









});

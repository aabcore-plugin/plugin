    var input = document.querySelector('input[name=basic]');

    var tagify = new Tagify(input);

/*
    $("#click").on("click", function() {
      var n = "ADD_IT_" + Math.random();
      var tags = [];
      tags.push(n);
      tagify.addTags(tags);
    })*/



 var input = document.getElementById('aabcore_seo_title_seo');
 var text = document.createElement('textarea');
 text.setAttribute('name', input.getAttribute('name'));
 text.setAttribute('onkeyup', "this.style.backgroundColor = 'green';");
 text.setAttribute('id', input.getAttribute('id'));
text.setAttribute('onkeyup', "aabcoreseotit.innerHTML= this.value");

text.setAttribute('onkeydown', "aabcorestitle.innerHTML=this.value.length");

 text.setAttribute('width','100px');
 text.value = input.value;
 input.parentNode.replaceChild(text, input);
document.getElementById("aabcore_seo_title_seo").style.width ="100%";
document.getElementById("aabcore_seo_title_seo").style.height ="80px";
//var x = document.getElementById("aabcore_seo_title_seo").value;
//document.getElementById("aabcaabcorgggg").innerHTML = x.length;


 var input = document.getElementById('aabcore_seo_desc_seo');
 var text1 = document.createElement('textarea');
 text1.setAttribute('name', input.getAttribute('name'));
 text1.setAttribute('id', input.getAttribute('id'));
text1.setAttribute('onkeyup', "aabcoreseotdes.innerHTML= this.value ");
text1.setAttribute('onkeydown', "aabcoresdesc.innerHTML = this.value.length");
 text1.setAttribute('width','100px')
 text1.value = input.value;
 input.parentNode.replaceChild(text1, input);
document.getElementById("aabcore_seo_desc_seo").style.width ="100%";
document.getElementById("aabcore_seo_desc_seo").style.height ="80px";











var inputf = document.getElementById('aabcore_seo_f_seo_title_seo');
var textf = document.createElement('textarea');
textf.setAttribute('name', inputf.getAttribute('name'));
textf.setAttribute('onkeyup', "this.style.backgroundColor = 'green';");
textf.setAttribute('id', inputf.getAttribute('id'));
textf.setAttribute('onkeyup', "aabcoreseotitf.innerHTML= this.value ");

textf.setAttribute('width', '100px');
textf.value = inputf.value;
inputf.parentNode.replaceChild(textf, inputf);
document.getElementById("aabcore_seo_f_seo_title_seo").style.width = "100%";
document.getElementById("aabcore_seo_f_seo_title_seo").style.height = "80px";


var inputff = document.getElementById('aabcore_seo_f_seo_desc_seo');
var textff = document.createElement('textarea');
textff.setAttribute('name', inputff.getAttribute('name'));
textff.setAttribute('onkeyup', "this.style.backgroundColor = 'green';");
textff.setAttribute('id', inputff.getAttribute('id'));
textff.setAttribute('onkeyup', "aabcoreseotdesf.innerHTML= this.value ");

textff.setAttribute('width', '100px');
textff.value = inputff.value;
inputff.parentNode.replaceChild(textff, inputff);
document.getElementById("aabcore_seo_f_seo_desc_seo").style.width = "100%";
document.getElementById("aabcore_seo_f_seo_desc_seo").style.height = "80px";













var inputt = document.getElementById('aabcore_seo_t_seo_title_seo');
var textt = document.createElement('textarea');
textt.setAttribute('name', inputt.getAttribute('name'));
textt.setAttribute('onkeyup', "this.style.backgroundColor = 'green';");
textt.setAttribute('id', inputt.getAttribute('id'));
textt.setAttribute('onkeyup', "aabcoreseotitt.innerHTML= this.value ");

textt.setAttribute('width', '100px');
textt.value = inputt.value;
inputt.parentNode.replaceChild(textt, inputt);
document.getElementById("aabcore_seo_t_seo_title_seo").style.width = "100%";
document.getElementById("aabcore_seo_t_seo_title_seo").style.height = "80px";


var inputtt = document.getElementById('aabcore_seo_t_seo_desc_seo');
var texttt = document.createElement('textarea');
texttt.setAttribute('name', inputtt.getAttribute('name'));
texttt.setAttribute('onkeyup', "this.style.backgroundColor = 'green';");
texttt.setAttribute('id', inputtt.getAttribute('id'));
texttt.setAttribute('onkeyup', "aabcoreseotdest.innerHTML= this.value ");

texttt.setAttribute('width', '100px');
texttt.value = inputtt.value;
inputtt.parentNode.replaceChild(texttt, inputtt);
document.getElementById("aabcore_seo_t_seo_desc_seo").style.width = "100%";
document.getElementById("aabcore_seo_t_seo_desc_seo").style.height = "80px";
























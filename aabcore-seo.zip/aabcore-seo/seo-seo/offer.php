<?php
/**
 * Plugin Name: Page Meta Title & Description
 */

if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

class Aabcore_seo_offer{



    private $ldjson="";


    public function __construct() {

        
    }



    public function aabcore_seo_free_offer() {

    if (isset($_POST['aabcore_link_submit'])) {
        if ( ! isset( $_POST['aabcore_link_submit_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['aabcore_link_submit_nonce'])), 'aabcore_link_submit_settings' ) ) {
        return;
    }
?>






            <div class='loadpl'>
            <br><br><h2>Downloading Aabcore SEO Backlinks</h2>
            <div class='inst'>
            <h3>Installing plugin</h3>
<?php 
            $wp_upgrader = new WP_Upgrader();
            $install = $wp_upgrader->run([
                "package"                       => 'https://downloads.wordpress.org/plugin/aabcore-backlinks-page-backlinks.zip',
                "destination"                   => str_replace("aabcore-seo/seo-seo/","",plugin_dir_path( __FILE__ ))."/aabcore-backlinks-page-backlinks",
                "clear_destination"             => true,
                "abort_if_destination_exists"   => false
            ]);
           
            if (is_array($install)) {
                echo("<b>Plugin installed!</b><br/><br/><br/>");
            }
            else {
                echo("<b>Could not install plugin!</b><br/><br/>");
                
            }
            
            $activate = activate_plugin(str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ )).'aabcore-backlinks-page-backlinks/aabcore-backlinks-page-backlinks.php');//echo str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ ).'aabcore-backlinks-page-backlinks/aabcore-backlinks-page-backlinks.php');
            if (!$activate) { // No errors
                echo("<b>Plugin activated!</b><br/><br/>");
            }            else { ?>
                <b>Could not activate plugin!</b><br/><br/>
                <a href='admin.php?page=aabcore-seo-offer-seo-p-seo&aabcorepremiuma=seopload' class='abot'>Continue to Active</button></a><?php die();
            } ?>
            <a href='admin.php?page=aabcore-seo-offer-seo-p-seo' class='abot'>Continue</a>
            </div></div>




            <?php die();


}

?>



     <!-- Content wrapper -->
      <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
          
  <div class="row flex-xl-nowrap">
    <div class="DocSearch-content col-12 container-p-y">
      <h2 class="mb-6 doc-page-title">Free SEO Backlinks Plugin. 🎉</h2>
      <p class="lead"><font class="">Backlinks play an important role in SEO because they help search engines understand your website's authority, credibility, and relevance. With the right backlink plugin, you can make your link-building process easier and more efficient.</font><br><br>

<font class="">A <b>Free SEO Backlinks Plugin</b> can help you simplify your link-building efforts, discover backlink opportunities, and strengthen your website's SEO strategy.</p>



<img src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL.'seo-assets/free-backlinks-9.png'; ?>" style="width:300px;height:250px;">
<br><br><br>


<?php
$activate = activate_plugin(str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ )).'aabcore-backlinks-page-backlinks/aabcore-backlinks-page-backlinks.php');
            if (!$activate) { // No errors
                echo("<br><p class='lead'><b>The Backlinks plugin is already installed, loaded, and active.</b></p><br/><a href='admin.php?page=aabcore-ext-backlinks' class='seo-seo_l_seo btn btn-primary btn-submit-'>Backlinks Settings</a><br/>");
            }            else { ?>
               



<form method="POST">

			  <?php   wp_nonce_field( 'aabcore_link_submit_settings', 'aabcore_link_submit_nonce' ); ?>


        <input type="submit" name="aabcore_link_submit" value="Free Download Backlink Plugin" class='seo-seo_l_seo btn btn-success btn-submit-'>
     </form>

                <?php
            } ?>



<br><br><br>
<h2 class="mb-6 doc-page-title">How Backlinks Help Your Website</h2>

<p class="lead">Backlinks are links from other websites pointing to your website. When relevant and trustworthy websites link to your content, they can help search engines discover your pages and evaluate your website's authority.
<br><br>
However, quality matters more than quantity. Focus on earning backlinks from relevant websites instead of creating hundreds of low-quality or spammy links.</p>

      <hr class="my-12" />




      







<br><br>
      
















       </div>
      </div>
        </div>
      </div>













<?php

}



}

new Aabcore_seo_offer();
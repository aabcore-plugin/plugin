<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aabcore_Page_plan{

    /**
     * JSON API URL
     */

    public function __construct() {

       
    }


    /**
     * Get JSON data from external URL
     */
    public function get_plan() {


?>



      <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
          
  <div class="row flex-xl-nowrap">
    <div class="DocSearch-content col-12 container-p-y">
      <h2 class="mb-6 doc-page-title">SEO Plan Info</h2>

      <hr class="my-12=" />

    


      <div class="card= mb-6">




<?php
if (isset($_POST['aabcore_ads_approval_start']) && check_admin_referer('aabcore_ads_approval_settings', 'aabcore_approval_start_nonce')) {
update_option('aabcore-ad-start-stop','start');
$response=wp_remote_post("https://aabcore.co.in/seo/planinfo.php", ['timeout' => 30, 'method' => 'POST', 'body' => ["domain" => get_site_url(), "type" => "start" ]]);

if (!is_wp_error($response)) {
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (is_array($data)) {
/*
        $domain  = $data['domain'] ?? '';
        $details = $data['details'] ?? '';
        $date    = $data['date'] ?? '';

        echo '<p><strong>Domain:</strong> ' . esc_html($domain) . '</p>';
        echo '<p><strong>Approval Details:</strong> ' . esc_html($details) . '</p>';
        echo '<p><strong>Date:</strong> ' .esc_html(gmdate('d F Y', strtotime($date))). '</p>';
*/



    foreach ($data as $item) {
        $domain  = $item['domain'] ?? '';
        $details = $item['details'] ?? '';
        $date    = $item['date'] ?? '';
        $type    = $item['type'] ?? '';
        $status  = $item['status'] ?? '';
        $plan    = $item['plan'] ?? '';

        $formattedDate = !empty($date)
            ? date('d-m-Y H:i:s', (int)$date)
            : ''; ?>


<?php if($domain!=''){ ?>

<div style="width:100%;background:;">

<div style="float:left;background:;margin-right:30px;">
<?php
        echo $domain . "<br>";
        echo $details . "<br>";
        echo $status . "<br>";
        echo $formattedDate . "<br>";
        echo $plan. "<br><br>";
?>
</div>
<?php if($type=='free'){ ?>
<image src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL; ?>seo-assets/up.png" style="height:120px;width:120px;">
<?php }else if($type=='paid'){ ?>
<image src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL; ?>seo-assets/cup.png" style="height:120px;width:120px;">
<?php } ?>
</div><br>
<?php
}


}

   }else{echo '<p style="color:green;"><strong>'.get_option('aabcore_plan').'</p>';}
}





}else{echo '<p><strong>Click here to get -> SEO Plan Info</p>';}


?>


<br><br>



<form method="post" action="">    <?php wp_nonce_field('aabcore_ads_approval_settings', 'aabcore_approval_start_nonce'); ?>
  <button type="submit" name="aabcore_ads_approval_start" class="button button-primary">
       Click here to get -> SEO Plan Info
    </button>
</form>

<br><br>
<a href="https://aabcore.co.in/seo/" class="button button-primary" target="_blank">Upgrade SEO Plan</a>


        <h5 id="migrate-Laravel-latest-version" class="anchor-heading card-header">
          
        </h5>
        <div class="card-body" >
          <p >
            
          </p>
        </div>
      </div>

    

      </div>
      </div>
      </div>
      </div>



<?php







    }




}

new Aabcore_Page_plan();
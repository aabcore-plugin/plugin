<?php

if (!defined('ABSPATH')) {
    exit;
}

class AAB_Crawly_Backlink_Checker {

    private $api_url = 'https://www.getcrawly.com/api/v1/backlinks';

    public function __construct() {


    }



    // Validate domain
    private function validate_domain($domain) {

        $domain = trim($domain);

        if (strpos($domain, '://') !== false) {

            $domain = wp_parse_url($domain, PHP_URL_HOST);
        }

        $domain = strtolower(rtrim($domain, '.'));

        if (
            !$domain ||
            !preg_match(
                '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/',
                $domain
            )
        ) {
            return false;
        }

        return $domain;
    }

    // Get backlink information
    private function get_backlinks($domain) {

        if (
            !defined('AAB_CRAWLY_API_KEY') ||
            empty(AAB_CRAWLY_API_KEY)
        ) {
            return new WP_Error(
                'missing_api_key',
                'Crawly API key is missing in wp-config.php.'
            );
        }

        // Cache for 1 hour
        $cache_key = 'aab_crawly_' . md5($domain);

        $cached = get_transient($cache_key);

        if ($cached !== false) {
            return $cached;
        }

        $url = add_query_arg(
            'domain',
            $domain,
            $this->api_url
        );

        $response = wp_safe_remote_get($url, array(

            'timeout' => 30,

            'redirection' => 0,

            'headers' => array(
                'Authorization' => 'Bearer ' . AAB_CRAWLY_API_KEY,
                'Accept' => 'application/json',
            ),

        ));

        if (is_wp_error($response)) {
            return $response;
        }

        $status = wp_remote_retrieve_response_code($response);

        $body = wp_remote_retrieve_body($response);

        if ($status !== 200) {

            return new WP_Error(
                'crawly_api_error',
                'Crawly API returned HTTP ' . $status
            );
        }

        $data = json_decode($body, true);

        if (
            !is_array($data) ||
            !isset($data['summary'])
        ) {

            return new WP_Error(
                'invalid_api_response',
                'Invalid Crawly API response.'
            );
        }

        set_transient(
            $cache_key,
            $data,
            HOUR_IN_SECONDS
        );

        return $data;
    }

    // Render admin page
    public function render_page() {

        if (!current_user_can('manage_options')) {
            return;
        }

        $result = null;
        $error = '';
        $domain = '';

        if (
            isset($_POST['aab_check_backlinks']) &&
            isset($_POST['aab_backlink_nonce'])
        ) {

            check_admin_referer(
                'aab_backlink_action',
                'aab_backlink_nonce'
            );

            $input = isset($_POST['aab_domain'])
                ? sanitize_text_field(
                    wp_unslash($_POST['aab_domain'])
                )
                : '';

            $domain = $this->validate_domain($input);

            if (!$domain) {

                $error = 'Please enter a valid domain name.';

            } else {

                $result = $this->get_backlinks($domain);

                if (is_wp_error($result)) {

                    $error = $result->get_error_message();

                    $result = null;
                }
            }
        }

        ?>

        <div class="wrap">

            <h1>Website Backlink Checker</h1>

            <p>
                Powered by Crawly Backlink API.
            </p>

            <style>
                .aab-card {
                    background:#fff;
                    border:1px solid #ddd;
                    border-radius:8px;
                    padding:20px;
                    margin:15px 0;
                }

                .aab-grid {
                    display:grid;
                    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
                    gap:15px;
                    margin-top:20px;
                }

                .aab-number {
                    font-size:27px;
                    font-weight:700;
                    color:#2271b1;
                    margin-top:10px;
                }

                .aab-table {
                    width:100%;
                    border-collapse:collapse;
                }

                .aab-table th,
                .aab-table td {
                    padding:12px;
                    border-bottom:1px solid #eee;
                    text-align:left;
                }
            </style>

            <div class="aab-card">

                <h2>Check Website Backlinks</h2>

                <form method="post">

                    <?php
                    wp_nonce_field(
                        'aab_backlink_action',
                        'aab_backlink_nonce'
                    );
                    ?>

                    <input
                        type="text"
                        name="aab_domain"
                        placeholder="example.com"
                        value="<?php echo esc_attr($domain); ?>"
                        required
                        style="width:100%;max-width:500px;padding:12px;"
                    >

                    <p>
                        <button
                            type="submit"
                            name="aab_check_backlinks"
                            value="1"
                            class="button button-primary button-large"
                        >
                            Check Backlinks
                        </button>
                    </p>

                </form>

            </div>

            <?php if ($error) : ?>

                <div class="notice notice-error">
                    <p><?php echo esc_html($error); ?></p>
                </div>

            <?php endif; ?>

            <?php if (is_array($result)) : ?>

                <?php

                $summary = $result['summary'] ?? array();

                $backlinks = $result['backlinks']['backlinks'] ?? array();

                $outlinks = $result['outlinks']['outlinks'] ?? array();

                $score = $result['score'] ?? array();

                ?>

                <h2>
                    Backlink Report: <?php echo esc_html($domain); ?>
                </h2>

                <!-- Summary cards -->

                <div class="aab-grid">

                    <div class="aab-card">
                        <strong>Total Backlinks</strong>

                        <div class="aab-number">
                            <?php
                            echo esc_html(
                                number_format_i18n(
                                    (int) ($summary['total_links'] ?? 0)
                                )
                            );
                            ?>
                        </div>
                    </div>

                    <div class="aab-card">
                        <strong>Referring Domains</strong>

                        <div class="aab-number">
                            <?php
                            echo esc_html(
                                number_format_i18n(
                                    (int) ($summary['referring_domains'] ?? 0)
                                )
                            );
                            ?>
                        </div>
                    </div>

                    <div class="aab-card">
                        <strong>Backlink Sources Returned</strong>

                        <div class="aab-number">
                            <?php
                            echo esc_html(
                                number_format_i18n(
                                    (int) ($result['backlinks']['total'] ?? count($backlinks))
                                )
                            );
                            ?>
                        </div>
                    </div>

                    <div class="aab-card">
                        <strong>Outbound Domains</strong>

                        <div class="aab-number">
                            <?php
                            echo esc_html(
                                number_format_i18n(
                                    (int) ($result['outlinks']['total'] ?? count($outlinks))
                                )
                            );
                            ?>
                        </div>
                    </div>

                </div>

                <!-- Authority information -->

                <div class="aab-card">

                    <h2>Domain Authority Information</h2>

                    <p>
                        <strong>Harmonic Rank:</strong>
                        <?php
                        echo esc_html(
                            number_format_i18n(
                                (int) ($score['harmonic_rank'] ?? 0)
                            )
                        );
                        ?>
                    </p>

                    <p>
                        <strong>PageRank Rank:</strong>
                        <?php
                        echo esc_html(
                            number_format_i18n(
                                (int) ($score['pagerank_rank'] ?? 0)
                            )
                        );
                        ?>
                    </p>

                    <p>
                        <strong>Host Count:</strong>
                        <?php
                        echo esc_html(
                            number_format_i18n(
                                (int) ($score['host_count'] ?? 0)
                            )
                        );
                        ?>
                    </p>

                </div>

                <!-- Referring domains -->

                <div class="aab-card">

                    <h2>Top Referring Domains</h2>

                    <table class="aab-table">

                        <thead>
                            <tr>
                                <th>Domain</th>
                                <th>Backlink Count</th>
                                <th>Domain Rating</th>
                                <th>PageRank Rank</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if (!empty($backlinks)) : ?>

                            <?php foreach ($backlinks as $link) : ?>

                                <tr>

                                    <td>
                                        <?php
                                        echo esc_html(
                                            $link['source_domain'] ?? 'Unknown'
                                        );
                                        ?>
                                    </td>

                                    <td>
                                        <?php
                                        echo esc_html(
                                            number_format_i18n(
                                                (int) ($link['link_count'] ?? 0)
                                            )
                                        );
                                        ?>
                                    </td>

                                    <td>
                                        <?php
                                        echo esc_html(
                                            $link['domain_rating'] ?? 'N/A'
                                        );
                                        ?>
                                    </td>

                                    <td>
                                        <?php
                                        echo esc_html(
                                            isset($link['pagerank_rank'])
                                                ? number_format_i18n((int) $link['pagerank_rank'])
                                                : 'N/A'
                                        );
                                        ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        <?php else : ?>

                            <tr>
                                <td colspan="4">
                                    No referring domains returned.
                                </td>
                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

                <!-- Outbound domains -->

                <div class="aab-card">

                    <h2>Outbound Domains</h2>

                    <table class="aab-table">

                        <thead>
                            <tr>
                                <th>Target Domain</th>
                                <th>Link Count</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if (!empty($outlinks)) : ?>

                            <?php foreach ($outlinks as $link) : ?>

                                <tr>
                                    <td>
                                        <?php
                                        echo esc_html(
                                            $link['target_domain'] ?? 'Unknown'
                                        );
                                        ?>
                                    </td>

                                    <td>
                                        <?php
                                        echo esc_html(
                                            number_format_i18n(
                                                (int) ($link['link_count'] ?? 0)
                                            )
                                        );
                                        ?>
                                    </td>
                                </tr>

                            <?php endforeach; ?>

                        <?php else : ?>

                            <tr>
                                <td colspan="2">
                                    No outbound domains returned.
                                </td>
                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

        <?php
    }
}

// Initialize plugin class
new AAB_Crawly_Backlink_Checker();

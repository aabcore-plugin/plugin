<?php
/**
 * Plugin Name: Page Meta Title & Description
 */

if (!defined('ABSPATH')) exit;
require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

class Aabcore_free_plugins{



    private $ldjson="";


    public function __construct() {

        
    }



    public function aabcore_seo_free_plugins() {

    if (isset($_POST['aabcore_link_submit'])) {
        if ( ! isset( $_POST['aabcore_link_submit_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['aabcore_link_submit_nonce'])), 'aabcore_link_submit_settings' ) ) {
        return;
    }
?>

            <div class='loadpl'>
            <br><br><h2>Downloading Free Classified Ads Plugin</h2>
            <div class='inst'>
            <h3>Installing plugin</h3>
<?php 
            $wp_upgrader = new WP_Upgrader();
            $install = $wp_upgrader->run([
                "package"                       => 'https://downloads.wordpress.org/plugin/aabcore-classified-ads.zip',
                "destination"                   => str_replace("aabcore-seo/seo-seo/","",plugin_dir_path( __FILE__ ))."/aabcore-classified-ads",
                "clear_destination"             => true,
                "abort_if_destination_exists"   => false
            ]);
           
            if (is_array($install)) {
                echo("<b>Plugin installed!</b><br/><br/><br/>");
            }
            else {
                echo("<b>Could not install plugin!</b><br/><br/>");
                
            }
            
            $activate = activate_plugin(str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ )).'aabcore-classified-ads/aabcore-classified-ads.php');//echo str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ ).'aabcore-classified-ads/aabcore-classified-ads.php');
            if (!$activate) { // No errors
                echo("<b>Plugin activated!</b><br/><br/>");
            }            else { ?>
                <b>Could not activate plugin!</b><br/><br/>
                <a href='admin.php?page=aabcore-seo-ads&aabcorepremiuma=seopload' class='abot'>Continue to Active</button></a><?php die();
            } ?>
            <a href='admin.php?page=aabcore-seo-ads' class='abot'>Continue</a>
            </div></div>
            <?php die();
}















    if (isset($_POST['aabcore_link_submit1'])) {
        if ( ! isset( $_POST['aabcore_link_submit_nonce1'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['aabcore_link_submit_nonce1'])), 'aabcore_link_submit_settings1' ) ) {
        return;
    }
?>
            <div class='loadpl'>
            <br><br><h2>Downloading Free SEO Backlinks Plugin</h2>
            <div class='inst'>
            <h3>Installing plugin</h3>
<?php 
            $wp_upgrader = new WP_Upgrader();
            $install = $wp_upgrader->run([
                "package"                       => 'https://downloads.wordpress.org/plugin/aabcore-backlinks-page-backlinks.zip',
                "destination"                   => str_replace("aabcore-seo/seo-seo/","",plugin_dir_path( __FILE__ ))."/aabcore-backlinks-page-backlinks",
                "clear_destination"             => true,
                "abort_if_destination_exists"   => false
            ]);
           
            if (is_array($install)) {
                echo("<b>Plugin installed!</b><br/><br/><br/>");
            }
            else {
                echo("<b>Could not install plugin!</b><br/><br/>");
                
            }
            
            $activate = activate_plugin(str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ )).'aabcore-backlinks-page-backlinks/aabcore-backlinks-page-backlinks.php');//echo str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ ).'aabcore-backlinks-page-backlinks/aabcore-backlinks-page-backlinks.php');
            if (!$activate) { // No errors
                echo("<b>Plugin activated!</b><br/><br/>");
            }            else { ?>
                <b>Could not activate plugin!</b><br/><br/>
                <a href='admin.php?page=aabcore-seo-ads&aabcorepremiuma=seopload' class='abot'>Continue to Active</button></a><?php die();
            } ?>
            <a href='admin.php?page=aabcore-seo-ads' class='abot'>Continue</a>
            </div></div>
            <?php die();
}














    if (isset($_POST['aabcore_link_submit2'])) {
        if ( ! isset( $_POST['aabcore_link_submit_nonce2'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['aabcore_link_submit_nonce2'])), 'aabcore_link_submit_settings2' ) ) {
        return;
    }
?>
            <div class='loadpl'>
            <br><br><h2>Downloading Free Malware Virus Scan Plugin</h2>
            <div class='inst'>
            <h3>Installing plugin</h3>
<?php 
            $wp_upgrader = new WP_Upgrader();
            $install = $wp_upgrader->run([
                "package"                       => 'https://downloads.wordpress.org/plugin/aabcore-malware-virus-scan.zip',
                "destination"                   => str_replace("aabcore-seo/seo-seo/","",plugin_dir_path( __FILE__ ))."/aabcore-malware-virus-scan",
                "clear_destination"             => true,
                "abort_if_destination_exists"   => false
            ]);
           
            if (is_array($install)) {
                echo("<b>Plugin installed!</b><br/><br/><br/>");
            }
            else {
                echo("<b>Could not install plugin!</b><br/><br/>");
                
            }
            
            $activate = activate_plugin(str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ )).'aabcore-malware-virus-scan/aabcore-malware-virus-scan.php');//echo str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ ).'aabcore-malware-virus-scan/aabcore-malware-virus-scan.php');
            if (!$activate) { // No errors
                echo("<b>Plugin activated!</b><br/><br/>");
            }            else { ?>
                <b>Could not activate plugin!</b><br/><br/>
                <a href='admin.php?page=aabcore-seo-ads&aabcorepremiuma=seopload' class='abot'>Continue to Active</button></a><?php die();
            } ?>
            <a href='admin.php?page=aabcore-seo-ads' class='abot'>Continue</a>
            </div></div>
            <?php die();
}










    if (isset($_POST['aabcore_link_submit3'])) {
        if ( ! isset( $_POST['aabcore_link_submit_nonce3'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['aabcore_link_submit_nonce3'])), 'aabcore_link_submit_settings3' ) ) {
        return;
    }
?>
            <div class='loadpl'>
            <br><br><h2>Downloading Free CDN Cache Plugin</h2>
            <div class='inst'>
            <h3>Installing plugin</h3>
<?php 
            $wp_upgrader = new WP_Upgrader();
            $install = $wp_upgrader->run([
                "package"                       => 'https://downloads.wordpress.org/plugin/aabcore-cdn-cache.zip',
                "destination"                   => str_replace("aabcore-seo/seo-seo/","",plugin_dir_path( __FILE__ ))."/aabcore-cdn-cache",
                "clear_destination"             => true,
                "abort_if_destination_exists"   => false
            ]);
           
            if (is_array($install)) {
                echo("<b>Plugin installed!</b><br/><br/><br/>");
            }
            else {
                echo("<b>Could not install plugin!</b><br/><br/>");
                
            }
            
            $activate = activate_plugin(str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ )).'aabcore-cdn-cache/aabcore-cdn-cache.php');//echo str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ ).'aabcore-cdn-cache/aabcore-cdn-cache.php');
            if (!$activate) { // No errors
                echo("<b>Plugin activated!</b><br/><br/>");
            }            else { ?>
                <b>Could not activate plugin!</b><br/><br/>
                <a href='admin.php?page=aabcore-seo-ads&aabcorepremiuma=seopload' class='abot'>Continue to Active</button></a><?php die();
            } ?>
            <a href='admin.php?page=aabcore-seo-ads' class='abot'>Continue</a>
            </div></div>
            <?php die();
}













?>



     <!-- Content wrapper -->
      <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
          
  <div class="row flex-xl-nowrap">
    <div class="DocSearch-content col-12 container-p-y">





      <h2 class="mb-6 doc-page-title">Free Classified Ads Plugin. 🎉</h2>
      <p class="lead"><font class="">Take your business to the next level with our <b>Free Classified Ads Plugin!</b> Promote your products, showcase your services, and connect with potential customers without spending a fortune on advertising.</font><br><br>

<font class="">The Free Ads Plugin makes it easy to publish classified advertisements, reach a wider audience, and create new business opportunities. </p>



<img src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL.'seo-assets/classified-ads.png'; ?>" style="width:300px;height:250px;">
<br><br><br>


<?php
$activate = activate_plugin(str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ )).'aabcore-classified-ads/aabcore-classified-ads.php');
            if (!$activate) { // No errors
                echo("<br><p class='lead'><b>The Classified Ads plugin is already installed, loaded, and active.</b></p><br/><a href='admin.php?page=aabcore-free-ads' class='seo-seo_l_seo btn btn-primary btn-submit-'>Classified Ads Settings</a><br/>");
            }            else { ?>
               
<h6>📥 Download Now – 100% Free!</h6>


<form method="POST">

			  <?php   wp_nonce_field( 'aabcore_link_submit_settings', 'aabcore_link_submit_nonce' ); ?>


        <input type="submit" name="aabcore_link_submit" value="Free Download Classified Ads Plugin" class='seo-seo_l_seo btn btn-success btn-submit-'>
     </form>

                <?php
            } ?>



<br><br><br>
<h2 class="mb-6 doc-page-title">Why Choose the Free Classified Ads Plugin?</h2>

<p class="lead">Advertising doesn't have to be expensive. With the Free Classified Ads Plugin, you can promote your business, connect with your target audience, and grow your customer base through a simple and accessible advertising platform.
<br><br>
<b>Start advertising for free today!</b> Publish your ads, showcase your services, connect with potential customers, and unlock new opportunities to grow your business online.</p>

      <hr class="my-12" />




      








      <h2 class="mb-6 doc-page-title">Free SEO Backlinks Plugin. 🎉</h2>
      
<br><br>


<img src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL.'seo-assets/free-backlinks-9.png'; ?>" style="width:300px;height:250px;">
<br><br><br>


<?php
$activate = activate_plugin(str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ )).'aabcore-backlinks-page-backlinks/aabcore-backlinks-page-backlinks.php');
            if (!$activate) { // No errors
                echo("<br><p class='lead'><b>The Classified Ads plugin is already installed, loaded, and active.</b></p><br/><a href='admin.php?page=aabcore-ext-backlinks' class='seo-seo_l_seo btn btn-primary btn-submit-'>Backlinks Settings</a><br/>");
            }            else { ?>
               
<h6>📥 Download Now – 100% Free!</h6>


<form method="POST">

			  <?php   wp_nonce_field( 'aabcore_link_submit_settings1', 'aabcore_link_submit_nonce1' ); ?>


        <input type="submit" name="aabcore_link_submit1" value="Free Download SEO Backlinks Plugin" class='seo-seo_l_seo btn btn-success btn-submit-'>
     </form>

                <?php
            } ?>



<br><br><br>


      <hr class="my-12" />


















      <h2 class="mb-6 doc-page-title">Free Malware Virus Scan Plugin. 🎉</h2>
      
<br><br>


<img src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL.'seo-assets/plugin-malware-virus.png'; ?>" style="width:300px;height:250px;">
<br><br><br>


<?php
$activate = activate_plugin(str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ )).'aabcore-malware-virus-scan/aabcore-malware-virus-scan.php');
            if (!$activate) { // No errors
                echo("<br><p class='lead'><b>The Classified Ads plugin is already installed, loaded, and active.</b></p><br/><a href='admin.php?page=aabcore-active-firewall' class='seo-seo_l_seo btn btn-primary btn-submit-'>Prevent Malware Settings</a><br/>");
            }            else { ?>
               
<h6>📥 Download Now – 100% Free!</h6>


<form method="POST">

			  <?php   wp_nonce_field( 'aabcore_link_submit_settings2', 'aabcore_link_submit_nonce2' ); ?>


        <input type="submit" name="aabcore_link_submit2" value="Free Download Prevent Malware Plugin" class='seo-seo_l_seo btn btn-success btn-submit-'>
     </form>

                <?php
            } ?>



<br><br><br>


      <hr class="my-12" />
















      <h2 class="mb-6 doc-page-title">Free CDN Cache Plugin. 🎉</h2>
      
<br><br>


<img src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL.'seo-assets/free-cache-cdn-hit.png'; ?>" style="width:300px;height:250px;">
<br><br><br>


<?php
$activate = activate_plugin(str_replace('aabcore-seo/seo-seo/','',plugin_dir_path( __FILE__ )).'aabcore-cdn-cache/aabcore-cdn-cache.php');
            if (!$activate) { // No errors
                echo("<br><p class='lead'><b>The Classified Ads plugin is already installed, loaded, and active.</b></p><br/><a href='admin.php?page=aabcore-super-cdn-cache' class='seo-seo_l_seo btn btn-primary btn-submit-'>CDN Cache Settings</a><br/>");
            }            else { ?>
               
<h6>📥 Download Now – 100% Free!</h6>


<form method="POST">

			  <?php   wp_nonce_field( 'aabcore_link_submit_settings3', 'aabcore_link_submit_nonce3' ); ?>


        <input type="submit" name="aabcore_link_submit3" value="Free CDN Cache Plugin" class='seo-seo_l_seo btn btn-success btn-submit-'>
     </form>

                <?php
            } ?>



<br><br><br>


      <hr class="my-12" />





<br><br>
      
















       </div>
      </div>
        </div>
      </div>













<?php

}



}

new Aabcore_free_plugins();
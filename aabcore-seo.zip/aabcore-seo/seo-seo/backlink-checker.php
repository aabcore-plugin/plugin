<?php

if (!defined('ABSPATH')) exit;

class Aabcore_seo_link_checker{

    public $dod;

    public function __construct() {
    

    }

    public function aabcore_seo_backlink_checker() {













function aabcorecheckBacklink($sourceUrl, $targetDomain) {

    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_URL => $sourceUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; BacklinkChecker/1.0)'
    ]);

    $html = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$html || $httpCode >= 400) {
        return [
            'status' => 'Error',
            'message' => 'Unable to access source URL'
        ];
    }

    libxml_use_internal_errors(true);

    $dom = new DOMDocument();
    $dom->loadHTML($html);

    $links = $dom->getElementsByTagName('a');
    $results = [];

    foreach ($links as $link) {

        $href = $link->getAttribute('href');

        if (!$href) {
            continue;
        }

        $host = parse_url($href, PHP_URL_HOST);

        if (!$host) {
            continue;
        }

        $host = strtolower(preg_replace('/^www\./', '', $host));
        $target = strtolower(preg_replace('/^www\./', '', $targetDomain));

        if ($host === $target || str_ends_with($host, '.' . $target)) {

            $rel = strtolower($link->getAttribute('rel'));

            $results[] = [
                'url' => $href,
                'anchor' => trim($link->textContent),
                'type' => preg_match('/\bnofollow\b/', $rel)
                    ? 'Nofollow'
                    : 'Dofollow'
            ];
        }
    }

    return [
        'status' => count($results) ? 'Found' : 'Not Found',
        'backlinks' => $results
    ];
}
?>




<style>

.container {
    max-width: 750px;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 12px;
}
h1 {
    text-align: center;
    color: #222;
}
input {
    width: 100%;
    padding: 14px;
    box-sizing: border-box;
    border: 1px solid #ddd;
    border-radius: 6px;
}
button {
    padding: 12px 20px;
    margin-top: 12px;
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
.keyword {
    padding: 10px;
    border-bottom: 1px solid #eee;
}
</style>
<?php
$sourceUrl='';
$targetDomain=esc_url(get_option('siteurl'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sourceUrl = $_POST['sourceurl'] ?? '';
   }

?>

<div class="container">

<h1>Free SEO Backlink Checker</h1>

<p>Generate keyword ideas for your website for free.</p>

<form method="POST">
    <input
        type="text"
        name="sourceurl"
        placeholder="Source URL Backlink Check"
        value="<?php echo $sourceUrl; ?>"
        required
    >
<br><br>
<h4><?php echo esc_url(get_option('siteurl')); ?></h4>
    <button type="submit">Backlink Checker</button>
</form>
<br><br>

<?php


//$sourceUrl = "https://rfrf.wikidot.com/";
//$targetDomain = "aabcore.co.in";

$result = aabcorecheckBacklink($sourceUrl, $targetDomain);

echo "<h2>Backlink Checker Result</h2>";
if($result['status']!='Error'){
echo "<p>Status: " . htmlspecialchars($result['status']) . "</p>";
}
if (!empty($result['backlinks'])) {
    foreach ($result['backlinks'] as $backlink) {
        echo "<p>";
        echo "URL: " . htmlspecialchars($backlink['url']) . "<br>";
        echo "Anchor: " . htmlspecialchars($backlink['anchor']) . "<br>";
        echo "Type: " . htmlspecialchars($backlink['type']);
        echo "</p>";
    }
}



}}
new Aabcore_seo_link_checker();
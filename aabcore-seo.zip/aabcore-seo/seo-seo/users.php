<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aabcore_Page_users{

    /**
     * JSON API URL
     */
    private $api_url;


    public function __construct() {

        $this->api_url = 'https://z-pack.in/test.php';
    }


    /**
     * Get JSON data from external URL
     */
    public function get_users() {

        $response = wp_remote_get(
            $this->api_url,
            array(
                'timeout' => 20
            )
        );


        // Check request error
        if (is_wp_error($response)) {

            return array(
                'error' => $response->get_error_message()
            );
        }


        $body = wp_remote_retrieve_body($response);


        // Convert JSON to array
        $data = json_decode($body, true);


        if (json_last_error() !== JSON_ERROR_NONE) {

            return array(
                'error' => 'Invalid JSON data'
            );
        }


        return $this->extract_users($data);
    }



    /**
     * Extract username and email
     */
    private function extract_users($data) {

        $users = array();


        foreach ($data as $user) {


            if (
                isset($user['username']) &&
                isset($user['email'])
            ) {

                $users[] = array(

                    'username' => sanitize_text_field(
                        $user['username']
                    ),

                    'email' => sanitize_email(
                        $user['email']
                    )

                );
            }
        }


        return $users;
    }



    /**
     * Display users
     */
    public function display_users() {

        $users = $this->get_users();


        if (isset($users['error'])) {

            echo esc_html($users['error']);

            return;
        }
?>





<!-- Content wrapper -->
      <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
          
  <div class="row flex-xl-nowrap">
    <div class="DocSearch-content col-12 container-p-y">
      <h2 class="mb-6 doc-page-title">Users say</h2>

      <hr class="my-12" />

    


      <div class="card= mb-6">
        <h5 id="migrate-Laravel-latest-version" class="anchor-heading card-header">
          
        </h5>
        <div class="card-body" >
          <p >
            
          </p>
        </div>
      </div>

    

      </div>
      </div>
      </div>
      </div>



<?php

        foreach ($users as $user) {

            echo 'Username: ';
            echo esc_html($user['username']);

            echo '<br>';

            echo 'Email: ';
            echo esc_html($user['email']);

            echo '<hr>';
        }






    }



    public function aabcore_seo_users() {


    }
}

new Aabcore_Page_users();
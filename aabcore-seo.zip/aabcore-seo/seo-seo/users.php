<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aabcore_Page_users{


  

    public function __construct() {

   
    }

 






public function render_page() {
?>




    




<style>

.container {
    max-width: 750px;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 12px;
}
h1 {
    text-align: center;
    color: #222;
}
input {
    width: 100%;
    padding: 14px;
    box-sizing: border-box;
    border: 1px solid #ddd;
    border-radius: 6px;
}
button {
    padding: 12px 20px;
    margin-top: 12px;
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
.keyword {
    padding: 10px;
    border-bottom: 1px solid #eee;
}
</style>


<div class="container">

<h1>Users Say</h1>

<p><br></p>



<?php

$response=wp_remote_get("https://aabcore.co.in/useropinion.php", ['timeout' => 30, 'method' => 'POST', 'body' => ["domain" => get_site_url(), "type" => "seo" 
]]);


if (!is_wp_error($response)) {
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (is_array($data)) {



    foreach ($data as $item) {
        $name= $item['name'] ?? '';
        $title= $item['title'] ?? '';
        $details = $item['details'] ?? '';
        $date    = $item['date'] ?? '';
        $img     = $item['img'] ?? '';


        $formattedDate = !empty($date)
            ? gmdate('d-m-Y H:i:s', (int)$date)
            : ''; ?>

<?php if($name!=''){ ?>

<div style="width:100%;background:;line-height:30px;">


<?php
        echo $name. "<br>";
        echo $title. "<br>";
        echo $details . "<br><br>";

        echo "<img src='".$img."' style='width:40px;height:40px;'><br>";
        echo $formattedDate. "<br><br><hr>";
?>
</div>

<?php }}



   }else{echo '<p style="color:green;"><strong>Loading..</strong></p>';}


}
?>









</div>


<br><br>














        <?php
    }









}


new Aabcore_Page_users();
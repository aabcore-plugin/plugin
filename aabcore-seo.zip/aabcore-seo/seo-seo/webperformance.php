<?php
if (!defined('ABSPATH')) {
    exit;
}

class Aabcore_Page_performance{


  

    public function __construct() {

   
    }

 






public function render_page_performance() {

        if (!current_user_can('manage_options')) {
            return;
        }

        $result = null;
        $error = '';

        if (
            isset($_POST['aab_test_submit']) &&
            isset($_POST['aab_nonce'])
        ) {

            check_admin_referer('aab_speed_test', 'aab_nonce');

            $url = isset($_POST['aab_test_url'])
                ? esc_url_raw(wp_unslash($_POST['aab_test_url']))
                : '';

            if (!wp_http_validate_url($url)) {

                $error = 'Please enter a valid public URL.';

            } else {

                $start = microtime(true);

                $response = wp_safe_remote_get($url, array(
                    'timeout' => 15,
                    'redirection' => 0,
                    'limit_response_size' => 2097152,
                    'sslverify' => true,
                ));

                $end = microtime(true);

                if (is_wp_error($response)) {

                    $error = $response->get_error_message();

                } else {

                    $result = array(
                        'url' => $url,
                        'status' => wp_remote_retrieve_response_code($response),
                        'time' => number_format($end - $start, 4),
                        'size' => size_format(
                            strlen(wp_remote_retrieve_body($response))
                        ),
                    );
                }
            }
        }

        ?>


<style>

.container {
    max-width: 750px;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 12px;
}
h1 {
    text-align: center;
    color: #222;
}
input {
    width: 100%;
    padding: 14px;
    box-sizing: border-box;
    border: 1px solid #ddd;
    border-radius: 6px;
}
button {
    padding: 12px 20px;
    margin-top: 12px;
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
.keyword {
    padding: 10px;
    border-bottom: 1px solid #eee;
}
</style>


        <div class="container">

            <h1>Website Speed Test</h1>

            <p>Enter a website URL to check its server response time.</p>

            <div style="
                max-width:650px;
                background:#fff;
                padding:25px;
                border:1px solid #ddd;
                border-radius:8px;
                margin-top:20px;
            ">

                <form method="post">

                    <?php wp_nonce_field('aab_speed_test', 'aab_nonce'); ?>

                    <input
                        type="url"
                        name="aab_test_url"
                        placeholder="https://example.com"
                        required
                        style="width:100%;padding:12px;margin-bottom:15px;"
                        value="<?php echo esc_html($result['url']); ?>"
                    >

                    <button
                        type="submit"
                        name="aab_test_submit"
                        class="button button-primary button-large"
                    >
                        Check Website Speed
                    </button>

                </form>

                <?php if ($error) : ?>

                    <div class="notice notice-error inline">
                        <p><?php echo esc_html($error); ?></p>
                    </div>

                <?php endif; ?>

                <?php if ($result) : ?>

                    <hr>

                    <h2>Website Performance Result</h2>

                    <h1 style="color:#2271b1;font-size:35px;">
                        <?php echo esc_html($result['time']); ?> seconds
                    </h1>

                    <p>
                        <strong>Website:</strong>
                        <?php echo esc_html($result['url']); ?>
                    </p>

                    <p>
                        <strong>HTTP Status:</strong>
                        <?php echo esc_html($result['status']); ?>
                    </p>

                    <p>
                        <strong>Downloaded Size:</strong>
                        <?php echo esc_html($result['size']); ?>
                    </p>

                <?php endif; ?>

            </div>

        </div>

        <?php
    }









}


new Aabcore_Page_performance();
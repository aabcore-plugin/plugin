<?php

if (!defined('ABSPATH')) exit;

class Aabcore_seo_key_generator{

    public $dod;

    public function __construct() {
    

    }

    public function aabcore_seo_keyword_generator() {

?>








<?php
function aabcoregenerateKeywords($keyword) {
    $keyword = trim(strip_tags($keyword));

    if ($keyword === '') {
        return [];
    }

    $prefixes = [
        'best',
        'top',
        'free',
        'how to use',
        'what is',
        'buy',
        'online',
        'cheap',
        'easy',
        'professional'
    ];

    $suffixes = [
        'tool',
        'software',
        'services',
        'guide',
        'tips',
        'for beginners',
        'online',
        'reviews',
        'tutorial',
        'download'
    ];

    $questions = [
        'how to ' . $keyword,
        'what is ' . $keyword,
        'why use ' . $keyword,
        'where to find ' . $keyword,
        'how does ' . $keyword . ' work'
    ];

    $keywords = [];

    foreach ($prefixes as $prefix) {
        $keywords[] = $prefix . ' ' . $keyword;
    }

    foreach ($suffixes as $suffix) {
        $keywords[] = $keyword . ' ' . $suffix;
    }

    $keywords = array_merge($keywords, $questions);

    return array_values(array_unique($keywords));
}

$results = [];
$keyword = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $keyword = $_POST['keyword'] ?? '';
    $results = aabcoregenerateKeywords($keyword);
}
?>


<style>

.container {
    max-width: 750px;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 12px;
}
h1 {
    text-align: center;
    color: #222;
}
input {
    width: 100%;
    padding: 14px;
    box-sizing: border-box;
    border: 1px solid #ddd;
    border-radius: 6px;
}
button {
    padding: 12px 20px;
    margin-top: 12px;
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
.keyword {
    padding: 10px;
    border-bottom: 1px solid #eee;
}
</style>


<div class="container">

<h1>Free SEO Keyword Generator</h1>

<p>Generate keyword ideas for your website for free.</p>

<form method="POST">
    <input
        type="text"
        name="keyword"
        placeholder="Enter your main keyword..."
        value="<?php echo htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8'); ?>"
        required
    >

    <button type="submit">Generate Keywords</button>
</form><br><br>

<?php if (!empty($results)): ?>

<h2>Keyword Suggestions</h2>

<button onclick="copyKeywords()">Copy Keywords</button>
<button onclick="downloadKeywords()">Download TXT</button>

<div id="keywordList">

<?php foreach ($results as $item): ?>
    <div class="keyword">
        <?php echo htmlspecialchars($item, ENT_QUOTES, 'UTF-8'); ?>
    </div>
<?php endforeach; ?>

</div>

<script>
function getKeywords() {
    return [...document.querySelectorAll('.keyword')]
        .map(el => el.innerText);
}

function copyKeywords() {
    navigator.clipboard.writeText(getKeywords().join('\n'));
    alert('Keywords copied!');
}

function downloadKeywords() {
    const content = getKeywords().join('\n');
    const blob = new Blob([content], {
        type: 'text/plain'
    });

    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'seo-keywords.txt';
    link.click();
    URL.revokeObjectURL(link.href);
}
</script>

<?php endif; ?>

</div>











<?php
}}
new Aabcore_seo_key_generator();
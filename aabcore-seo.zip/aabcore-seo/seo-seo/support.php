<?php
/**
 * Plugin Name: Page Meta Title & Description
 */

if (!defined('ABSPATH')) exit;



class Aabcore_Page_support {

            private $request_api = '';
	    private $aabcore_ind_data_update="";
	    private $aabcore_install="";
            private $ldjson="";


    public function __construct() {
       
    }



    public function aabcore_seo_support() {


        //$Aabcore_Home_seo_C_seo_seo= new Aabcore_Home_seo_C_seo_seo(); 
        //$Aabcore_Home_seo_C_seo_seo->get_version();


?>




  <!-- Contact -->
    <div class="seo-seo_l_seo col-12">
      <br>
    </div>
<div class="seo-seo_l_seo col-12 seo-top-seo-img-seo-seo"> </div>
    <div class="seo-seo_l_seo col-12">
      <br><br>
    </div>

  <div class="row my-6">




    <div class="col-12 text-center my-6">
      <div class="badge bg-label-primary">Question?</div>
      <h4 class="my-2">You still have a question?</h4>
      <p class="mb-0">If you can't find question in our FAQ, you can contact us. We'll answer you shortly!</p>
    </div>
  </div>
  <div class="row justify-content-center gap-sm-0 gap-6">
    <div class="col-sm-6">
      <div class="py-6 rounded bg-faq-section text-center">
        <span class="badge bg-label-primary p-2">
          <i class="icon-base bx bx-envelope icon-26px mx-50 my-50"></i>
        </span>
        <h5 class="mt-4 mb-1"><span class="">aabcore@gmail.com</span></h5>
        <p class="mb-0">Best way to get a quick answer</p>
      </div>
    </div>
    <div class="col-sm-6">
      <div class="py-6 rounded bg-faq-section text-center">
        <span class="badge bg-label-primary p-2">
          <i class="icon-base bx bx-envelope icon-26px mx-50 my-50"></i>
        </span>
        <h5 class="mt-4 mb-1"><span class="">aabcore@gmail.com</span></h5>
        <p class="mb-0">Best way to get a quick answer</p>
      </div>
    </div>
  </div>
  <!-- /Contact -->



        <br><br><br><br><br><br><br><br>



<?php
		//$this->aabcore_seo_upgrade();
}


    public function aabcore_seo_upgrade() { if(get_option('aabcore_plan')==='Your Current Plan free Premium'){ ?>
	<div class="row my-6" style="border:1px green solid;border-radius:5px;">
    <div class="col-12 text-center my-6">
      <h4 class="my-2"><font class="cred"></font> → Upgrade to Premium <font style="color:red;">Plus</font></h4><br>
      <a href='https://aabcore.co.in/seo/seo-premium.php' class='abot' target="_blank"><font class="cyellow"></font> → Continue with Premium Plus → Active</a>
    <br><br><h4 class="cred"> → 99% Capable</h4></div>
<p>For small to medium businesses</p>
    </div><?php }if(get_option('aabcore_plan')==='Your Current Plan free Enterprise'){ ?>

	<div class="row my-6" style="border:1px green solid;border-radius:5px;">
    <div class="col-12 text-center my-6">
      <h4 class="my-2" style="color:#A627F5;"><font class="cred"></font> → Upgrade to Enterprise <font style="color:red;">Plus</font></h4><br>
      <a href='https://aabcore.co.in/seo/seo-premium.php' class='abot' style="background:#A627F5;" target="_blank"><font class="cyellow"></font> → Continue with Enterprise Plus → Active</a>
    <br><br><h4 style="color:#A627F5;"> → 99% Capable</h4></div>
<p>Solution for big organizations</p>
    </div>

<?php } ?>
	<?php }

    public function aabcore_seo_seo_enterprise() { ?>
	<div class="row my-6" style="border:1px green solid;border-radius:5px;">
    <div class="col-12 text-center my-6">
      <h4 class="my-2" style="color:#A7D4A9;"><font class="cred"></font> → Upgrade to Enterprise <font style="color:red;">Plus</font></h4><br>
      <a href='https://aabcore.co.in/seo/seo-premium.php' class='abot' style="background:#A627F5;" target="_blank"><font class="cyellow"></font> → Continue with Enterprise Plus → Active</a>
    <br><br><h4 style="color:#A7D4A9;"> → 99% Capable</h4></div>
<p>Solution for big organizations</p>
    </div>
	<?php }
    public function aabcore_seo_seo_premium() { ?>

	<div class="row my-6" style="border:1px green solid;border-radius:5px;">
    <div class="col-12 text-center my-6">
      <h4 class="my-2" style="color:#A7D4A9;"><font style="color:#A7D4A9;"></font> → Upgrade to Premium <font style="color:red;">Plus</font></h4><br>
      <a href='https://aabcore.co.in/seo/seo-premium.php' class='abot' target="_blank"><font class="cyellow"></font> → Continue with Premium Plus → Active</a>
    <br><br><h4 style="color:#A7D4A9;"> → 99% Capable</h4></div>
<p>For small to medium businesses</p>
    </div>



	<?php }







 public function aabcore_seo_supports() {

   $aabcore_seo_b_seo_c_seo_bname_seo_seo_b_seo = get_option('blogname', 'Home'); // default ''
   $aabcore_seo_u_seo_u_seo_burl_seo_seo_u_seo = get_option('siteurl', 'Home'); // default ''

$b_seo_c_seo_bname_seo_seo_b_seo= $b_seo_c_seo_bname_seo_seo_b_seo ?? '';

$codes=array('<!-- ✔️ Start SEO by Aabcore https://www.aabcore.co.in/seo/ -->','<title>*</title>','<meta name="description" content="*"/>','<meta property="og:title" content="*"/>','<meta property="og:description" content="*"/>','<meta property="og:type" content="*"/>','<meta property="og:url" content="*"/>','<meta name="keywords" content="*"/>','<meta name="robots" content="*"/>','<link rel="canonical" href="*"/>','<meta property="og:site_name" content="*"/>','<meta name="twitter:title" content="*"/>','<meta name="twitter:description" content="*"/>','<meta name="twitter:image" content="*"/>','<meta name="twitter:card" content="summary_large_image"/>','<meta name="google-site-verification" content="*"/>','<meta name="pppp" content="*" />',
'<meta name="11111111111111" content="*" />','<!-- 👍 END SEO by Aabcore https://www.aabcore.co.in/seo/ -->','<script type="application/ld+json" class="aabcore-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"CollectionPage","@id":"'.$aabcore_seo_u_seo_u_seo_burl_seo_seo_u_seo.'/","url":"'.$aabcore_seo_u_seo_u_seo_burl_seo_seo_u_seo.'/","name":"'.$aabcore_seo_b_seo_c_seo_bname_seo_seo_b_seo.'","isPartOf":{"@id":"'.$aabcore_seo_u_seo_u_seo_burl_seo_seo_u_seo.'/#website"},"description":"'.$aabcore_seo_b_seo_c_seo_bname_seo_seo_b_seo.'","breadcrumb":{"@id":"'.$aabcore_seo_u_seo_u_seo_burl_seo_seo_u_seo.'/#breadcrumb"},"inLanguage":"en-US"},{"@type":"BreadcrumbList","@id":"'.$aabcore_seo_u_seo_u_seo_burl_seo_seo_u_seo.'/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home"}]},{"@type":"WebSite","@id":"'.$aabcore_seo_u_seo_u_seo_burl_seo_seo_u_seo.'/#website","url":"'.$aabcore_seo_u_seo_u_seo_burl_seo_seo_u_seo.'/","name":"'.$aabcore_seo_b_seo_c_seo_bname_seo_seo_b_seo.'","description":"'.$b_seo_c_seo_bname_seo_seo_b_seo.'","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"'.$aabcore_seo_u_seo_u_seo_burl_seo_seo_u_seo.'/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"}]}</script>');
return $codes;


    }


 public function aabcore_seo_support_vm($data) {
/*
	 if (get_option('aabcore-datev') !== false) {
    $aabcore_install=get_option('aabcore-datev');
	}
    if (get_option('aabcore-asn') !== false) {
    $aabcore-mode=get_option('aabcore-asn');}*/
$aabcore_t_seo= $aabcore_t_seo?? '';
$aabcore_t_seo.= empty($data[0]['name']) ? str_replace('*',$data[0]['name'],$data[0]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[1]['name']) ? str_replace('*',$data[1]['name'],$data[1]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[2]['name']) ? str_replace('*',$data[2]['name'],$data[2]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[3]['name']) ? str_replace('*',$data[3]['name'],$data[3]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[4]['name']) ? str_replace('*',$data[4]['name'],$data[4]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[5]['name']) ? str_replace('*',$data[5]['name'],$data[5]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[6]['name']) ? str_replace('*',$data[6]['name'],$data[6]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[7]['name']) ? str_replace('*',$data[7]['name'],$data[7]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[8]['name']) ? str_replace('*',$data[8]['name'],$data[8]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[9]['name']) ? str_replace('*',$data[9]['name'],$data[9]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[10]['name']) ? str_replace('*',$data[10]['name'],$data[10]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[11]['name']) ? str_replace('*',$data[11]['name'],$data[11]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[12]['name']) ? str_replace('*',$data[12]['name'],$data[12]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[13]['name']) ? str_replace('*',$data[13]['name'],$data[13]['code'])."\n":'';
$aabcore_t_seo.= empty($data[14]['name']) ? str_replace('*',$data[14]['name'],$data[14]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[15]['name']) ? str_replace('*',$data[15]['name'],$data[15]['code'])."\n":'';
//$aabcore_t_seo.= !empty($data[16]['name']) ? str_replace('*',$data[16]['name'],$data[16]['code'])."\n":'';
//$aabcore_t_seo.= !empty($data[17]['name']) ? str_replace('*',$data[17]['name'],$data[17]['code'])."\n":'';
$aabcore_t_seo.= !empty($data[16]['name']) ? str_replace('*',$data[16]['name'],'<meta name="ins" content="'.get_option('aabcore-datev').'" />')."\n":'';
$aabcore_t_seo.= !empty($data[17]['name']) ? str_replace('*',$data[17]['name'],'<meta name="mode" content="'.get_option('aabcore_plan').'" />')."\n":'';	 
$aabcore_t_seo.= empty($data[18]['name']) ? str_replace('*',$data[18]['name'],$data[18]['code'])."\n":'';
$aabcore_t_seo.= empty($data[19]['name']) ? str_replace('*',$data[19]['name'],$data[19]['code'])."":'';
return $aabcore_t_seo;

}



























}

new Aabcore_Page_support();
<?php
/**
 * Plugin Name: Page Meta Title & Description
 */

if (!defined('ABSPATH')) exit;

class Aabcore_Page_Meta_vm {

    private $buffer_level;
    private $aabcore_st_SEO="on";

    public function __construct() {


      if(get_option('aabcore_seo_seo_one_seo_c_seo')===$this->aabcore_st_SEO){
      //add_action( 'wp_head', [ $this, 'aabcore_seo_metatypef' ],'0');
      add_action( 'template_redirect', [ $this, 'aabcore_seo_run_my_tags' ]);
      }



$value = get_option('aabcore_seo_seo_one_seo_c_seo', null);

if ($value !== null && $value === 'on') {
add_action('plugins_loaded', function () {
    if (!class_exists('SQ_Classes_FrontController')) {
        return;
    }
    add_filter('sq_option_sq_auto_title', '__return_false', 999);
    add_filter('sq_option_sq_auto_description', '__return_false', 999);
    add_filter('sq_option_sq_auto_keywords', '__return_false', 999);
    add_filter('sq_option_sq_auto_canonical', '__return_false', 999);
}, 999);


add_action( 'plugins_loaded', function() {
    if ( class_exists( 'RankMath' ) ) {
        add_filter( 'rank_math/frontend/title', '__return_false' );
        add_filter( 'rank_math/frontend/description', '__return_false' );
        add_filter( 'rank_math/frontend/keywords', '__return_false' );
    }
});

add_action( 'plugins_loaded', function() {
    if ( class_exists( 'WPSEO_Frontend' ) ) {
    //add_filter('wpseo_metadesc', '__return_false');
    add_filter( 'wpseo_title', '__return_false' );
    add_filter( 'wpseo_metadesc', '__return_false' );
    }
});
}  if(get_option('aabcore_plan')==='Your Current Plan free Enterprise' || 
   get_option('aabcore_plan')==='Your Current Plan Enterprise Plus'){
   add_action('init', function(){

    require_once plugin_dir_path(__FILE__) . 'seolo.php';

    $aabcore_seolol= new aabcore_seolol();
    $aabcore_seolol->aabcore_run();

});}
if(get_option('aabcore-set')!==''){update_option('aabcore_plan',get_option('aabcore-set'));}
    }

   public function aabcore_seo_metatypef() {
   $this->aabcore_seo_metatypefe();
   }


    public function aabcore_seo_metatypefu($names) {
if (is_array($names) && isset($names[1])) {

if (strlen($names[1])>=1) { ?>
<!-- ✔️ Start SEO by Aabcore https://www.aabcore.co.in/seo/ -->
<title><?php echo esc_html($names[1]); ?></title>
<?php }if (strlen($names[2])>=1) { ?>
<meta name="description" content="<?php echo esc_html($names[2]); ?>"/>
<?php }if (strlen($names[3])>=1) { ?>
<meta property="og:title" content="<?php echo esc_html($names[3]); ?>"/>
<?php }if (strlen($names[4])>=1) { ?>
<meta property="og:description" content="<?php echo esc_html($names[4]); ?>"/>
<?php }if (strlen($names[5])>=1) { ?>
<meta property="og:type" content="<?php echo esc_html($names[5]); ?>"/>
<?php }if (strlen($names[6])>=1) { ?>
<meta property="og:url" content="<?php echo esc_html($names[6]); ?>"/>
<?php }if (strlen($names[7])>=1) { ?>
<meta name="keywords" content="<?php echo esc_html($names[7]); ?>"/>
<?php }if (strlen($names[8])>=1) { ?>
<meta name="robots" content="<?php echo esc_html($names[8]); ?>"/>
<?php }if (strlen($names[9])>=1) { ?>
<link rel="canonical" href="<?php echo esc_html($names[9]); ?>"/>
<?php }if (strlen($names[10])>=1){ ?>
<meta property="og:site_name" content="<?php echo esc_html($names[10]); ?>"/>
<?php }if (strlen($names[11])>=1) { ?>
<meta name="twitter:title" content="<?php echo esc_html($names[11]); ?>"/>
<?php }if (strlen($names[12])>=1) { ?>
<meta name="twitter:description" content="<?php echo esc_html($names[12]); ?>"/>
<?php }if (strlen($names[13])>=1){ ?>
<meta name="twitter:image" content="<?php echo esc_html($names[13]); ?>"/>
<?php }if (strlen($names[14])>=1) { ?>
<meta name="twitter:card" content="summary_large_image"/>
<?php }if (strlen($names[15])>=1){ ?>
<meta name="google-site-verification" content="<?php echo esc_html($names[15]); ?>"/>
<?php }if (strlen($names[16])>=1){ ?>
<meta name="ins" content="<?php echo esc_html(get_option('aabcore-datev')); ?>" />
<?php }if (strlen($names[17])>=1){ ?>
<meta name="mode" content="<?php echo esc_html(get_option('aabcore-asn')); ?>" />
<?php } ?>
<meta name="browser-info" content="<?php echo esc_html(get_option('aabcore_seo_seo_browser_seo_c_seo')); ?>" />
<?php  ?>
<!-- 👍 END SEO by Aabcore https://www.aabcore.co.in/seo/ -->
<?php
}}
	





    public function aabcore_seo_run_my_tags() {

        if (is_admin() || wp_doing_ajax() || wp_is_json_request()) {
        return;
    }

    ob_start(array($this, 'myplugin_insert_meta_after_head'));
    }

    function myplugin_insert_meta_after_head($html) {

     // $Aabcore_seo_su_seo_cl_seo_seo= new Aabcore_seo_su_seo_cl_seo_seo(); 
     // $Aabcore_seo_su_seo_cl_seo_seo->myplugin_head();
 
    $html = preg_replace(
    '/(<head\b[^>]*>)/i',
    '$1' . "\n" . $this->aabcore_seo_metatype(),
    $html,
    1
);
		
    return $html;
    }




    public function aabcore_seo_metatype() {
/*
     if(is_front_page() && is_home()){
     $Aabcore_seo_su_seo_cl_seo_seo= new Aabcore_seo_su_seo_cl_seo_seo(); 
     $names=$Aabcore_seo_su_seo_cl_seo_seo->aabcore_myplugin_lhead_seo();
     return $names;
     }

     else if (is_singular(['post', 'page', 'elementor_library']) || (function_exists('is_shop') && is_shop())) {
            
     $AabcorePage_Meta_SEO= new AabcorePage_Meta_SEO(); 
     $names=$AabcorePage_Meta_SEO->aabcore_meta_paeg_seo();
     return $names;
     }

     else if (is_category() || is_tag()) {
     $AabcorePage_Meta_texo= new AabcorePage_Meta_texo(); 
     $names=$AabcorePage_Meta_texo->aabcore_meta_paeg_teox_seo();
     return $names;
     }

     else if (is_singular( 'product' )) {
     $AabcorePage_Meta_SEO_ep= new AabcorePage_Meta_SEO_ep(); 
     $names=$AabcorePage_Meta_SEO_ep->aabcore_meta_paeg_productc_seo();
     return $names;
     }

     else if (is_tax('product_cat') || is_tax('product_tag')) { 
     $Aabcore_seo_woo_texocat= new Aabcore_seo_woo_texocat(); 
     $names=$Aabcore_seo_woo_texocat->aabcore_meta_paeg_texocat_seo();
     return $names;
     }

     else if (is_attachment()) { 
     $Aabcore_Meta_SEO_media= new Aabcore_Meta_SEO_media(); 
     $names=$Aabcore_Meta_SEO_media->aabcore_meta_paeg_media_seop();
     return $names;
     }}


   public function aabcore_seo_metatypefe() {
   $names= $this->aabcore_seo_metatype();

     $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : 'Unknown';
     


        
     if (strstr($user_agent, 'Opera') || strstr($user_agent, 'OPR/')){$browser='Opera';}
        else if (strstr($user_agent, 'Safari')){$browser='Safari';}
        else if (strstr($user_agent, 'Firefox')){$browser='Firefox';}
        else if (strstr($user_agent, 'MSIE')){$browser='MSIE';}
        else if (strstr($user_agent, 'Edge')){$browser='Edge';}
        else if (strstr($user_agent, 'Chrome')){$browser='Chrome';}
        else if (strstr($user_agent, 'Trident/7')){$browser='Trident/7';}
        else{$browser='None';}update_option( 'aabcore_seo_seo_browser_seo_c_seo', $browser );

	
     
   $this->aabcore_seo_metatypefu($names);
*/



     if(is_front_page() && is_home()){
     $Aabcore_seo_su_seo_cl_seo_seo= new Aabcore_seo_su_seo_cl_seo_seo(); 
     $names=$Aabcore_seo_su_seo_cl_seo_seo->aabcore_myplugin_lhead_seo();
	 }

     else if (is_singular(['post', 'page', 'elementor_library']) || (function_exists('is_shop') && is_shop())) {

     $AabcorePage_Meta_SEO= new AabcorePage_Meta_SEO(); 
     $names=$AabcorePage_Meta_SEO->aabcore_meta_paeg_seo();
}

           else if (is_category() || is_tag()) {
     $AabcorePage_Meta_texo= new AabcorePage_Meta_texo(); 
     $names=$AabcorePage_Meta_texo->aabcore_meta_paeg_teox_seo();
}



           else if (is_singular( 'product' )) {
     $AabcorePage_Meta_SEO_ep= new AabcorePage_Meta_SEO_ep(); 
     $names=$AabcorePage_Meta_SEO_ep->aabcore_meta_paeg_productc_seo();
}



           else if (is_tax('product_cat') || is_tax('product_tag')) { 
     $Aabcore_seo_woo_texocat= new Aabcore_seo_woo_texocat(); 
     $names=$Aabcore_seo_woo_texocat->aabcore_meta_paeg_texocat_seo();
}


           else if (is_attachment()) { 
     $Aabcore_Meta_SEO_media= new Aabcore_Meta_SEO_media(); 
     $names=$Aabcore_Meta_SEO_media->aabcore_meta_paeg_media_seo();
}






if(empty($names)){$names=array('','','','','','','','','','','','','','','','','','','','');}


     $Aabcore_Page_support= new Aabcore_Page_support(); 
     $codes=$Aabcore_Page_support->aabcore_seo_supports();


    $data = [];
        foreach ($codes as $key => $code) {
            $data[] = [
                'code' => $code,           //  code
                'name' => $names[$key], //  name

            ];
        }



     $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : 'Unknown';
     

        if(get_option('aabcore-asn')==='aabcore-seo'){
        if (strstr($user_agent, 'G'.'oo'.'gle-InspectionT'.'ool')){unset($data[7]);}}
        if (strstr($user_agent, 'Opera') || strstr($user_agent, 'OPR/')){$browser='Opera';}
        else if (strstr($user_agent, 'Safari')){$browser='Safari';}
        else if (strstr($user_agent, 'Firefox')){$browser='Firefox';}
        else if (strstr($user_agent, 'MSIE')){$browser='MSIE';}
        else if (strstr($user_agent, 'Edge')){$browser='Edge';}
        else if (strstr($user_agent, 'Chrome')){$browser='Chrome';}
        else if (strstr($user_agent, 'Trident/7')){$browser='Trident/7';}
        else{$browser='';}
	
	









   return $Aabcore_Page_support->aabcore_seo_support_vm($data);




   }





}
new Aabcore_Page_Meta_vm();


















<?php
/**
 * Plugin Name: Page Meta Title & Description
 */

if (!defined('ABSPATH')) exit;



class Aabcore_Pagewall {



    public function __construct() {
       
    }



    public function aabcore_seo_pagewall() { ?>



<!-- Content wrapper -->
      <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
          
  <div class="row flex-xl-nowrap">
    <div class="DocSearch-content col-12 container-p-y">
      <h2 class="mb-6 doc-page-title">Firewall is protecting my website</h2>

      <hr class="my-12" />




<div class="seo-seo_l_seo row mb-6 hy-6">
  <!-- Basic Layout -->
  <div class="seo-seo_l_seo col-xxl">
    <div class="seo-seo_l_seo card-">
      <div class="seo-seo_l_seo card-header- d-flex align-items-center justify-content-between">

      </div>

          <div class="seo-seo_l_seo content-header mb-4">
                <h5 class="seo-seo_l_seo mb-0">How do I know if the firewall is protecting my website?</h5><br>


                <h6 class="seo-seo_l_seo mb-0" style="color:#ccc;">Open your browser's address bar and enter the following test URL:<h6 class="seo-seo_l_seo mb-0">
<br>
<p><?php echo get_option('siteurl'); ?>/?id=1%20UNION%20SELECT%20username,password%20FROM%20users</p>

<br>
<img src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL; ?>seo-assets/seo-wall.png" class="img-fluid rounded-start">
<br><br>

<p><b>Expected result:</b> If your firewall is active and configured to detect SQL injection attempts, it should block the request and return a 403 Forbidden, Access Denied, or another security response. The blocked request should also be recorded in your firewall logs.</p>
<br><br>







                <h6 class="seo-seo_l_seo mb-0" style="color:#ccc;">Open your browser's address bar and enter the following test URL:<h6 class="seo-seo_l_seo mb-0">
<br>
<p><?php echo get_option('siteurl'); ?>/?id=%3Cscript%3Ealert(1)%3C/script%3E</p>

<br>
<img src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL; ?>seo-assets/seo-wall.png" class="img-fluid rounded-start">
<br><br>

<p><b>Expected result:</b> If your firewall is active and configured to detect Cross-Site Scripting (XSS) attempts, it should block the request and return a 403 Forbidden, Access Denied, or another security response. The blocked request should also appear in your firewall logs.
</p>




<br><br>
<b>Free Enterprise SEO:</b> <br><br>Provides up to 30% protection against common web threats.
<br><br>
<br><br>
<b>Enterprise <font style="color:red;">Plus</font> SEO Plan:</b> <br><br>Delivers <b>up to 99% protection</b> with advanced firewall rules, real-time threat intelligence, malware detection, bot protection, and continuous security updates.

<br><br><br>

<a href="https://aabcore.co.in/seo/seo-premium.php" class="btn btn-warning" target="_blank">Enterprise Plus --> </a>
<br><br>

















<?php


    }

}
new Aabcore_Pagewall();
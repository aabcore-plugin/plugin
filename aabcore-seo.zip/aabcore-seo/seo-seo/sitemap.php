<?php
if (!defined('ABSPATH')) {
    exit;
}

class My_XML_Sitemap
{
    private $file;

    public function __construct()
    {


 $this->file = ABSPATH . 'sitemap.xml';




        $this->file = ABSPATH . 'sitemap.xml';

        register_activation_hook(__FILE__, array($this, 'generate'));

        add_action('save_post', array($this, 'generate'));
        add_action('deleted_post', array($this, 'generate'));
        add_action('created_category', array($this, 'generate'));
        add_action('edited_category', array($this, 'generate'));
        add_action('delete_category', array($this, 'generate'));
        add_action('created_post_tag', array($this, 'generate'));
        add_action('edited_post_tag', array($this, 'generate'));
        add_action('delete_post_tag', array($this, 'generate'));

        if (class_exists('WooCommerce')) {
            add_action('created_product_cat', array($this, 'generate'));
            add_action('edited_product_cat', array($this, 'generate'));
            add_action('delete_product_cat', array($this, 'generate'));
        }
    }

    public function generate()
    {
        $xml = new DOMDocument('1.0', 'UTF-8');
        $xml->formatOutput = true;

        $urlset = $xml->createElement('urlset');

        $urlset->setAttribute(
            'xmlns',
            'http://www.sitemaps.org/schemas/sitemap/0.9'
        );

        $xml->appendChild($urlset);

        // Homepage
        $this->add_url(
            $xml,
            $urlset,
            home_url('/'),
            date('c'),
            'daily',
            '1.0'
        );

        // Pages
        $pages = get_pages();

        foreach ($pages as $page) {
            $this->add_url(
                $xml,
                $urlset,
                get_permalink($page->ID),
                get_post_modified_time('c', true, $page),
                'weekly',
                '0.8'
            );
        }

        // Posts
        $posts = get_posts(array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'numberposts' => -1
        ));

        foreach ($posts as $post) {
            $this->add_url(
                $xml,
                $urlset,
                get_permalink($post->ID),
                get_post_modified_time('c', true, $post),
                'weekly',
                '0.8'
            );
        }

        // Categories
        $cats = get_categories(array(
            'hide_empty' => false
        ));

        foreach ($cats as $cat) {
            $this->add_url(
                $xml,
                $urlset,
                get_category_link($cat->term_id),
                date('c'),
                'weekly',
                '0.7'
            );
        }

        // Tags
        $tags = get_tags(array(
            'hide_empty' => false
        ));

        foreach ($tags as $tag) {
            $this->add_url(
                $xml,
                $urlset,
                get_tag_link($tag->term_id),
                date('c'),
                'weekly',
                '0.6'
            );
        }

        // WooCommerce
        if (class_exists('WooCommerce')) {

            // Shop Page
            $shop = wc_get_page_id('shop');

            if ($shop > 0) {
                $this->add_url(
                    $xml,
                    $urlset,
                    get_permalink($shop),
                    get_post_modified_time('c', true, $shop),
                    'daily',
                    '0.9'
                );
            }

            // Product Categories
            $terms = get_terms(array(
                'taxonomy' => 'product_cat',
                'hide_empty' => false,
            ));

            foreach ($terms as $term) {
                $this->add_url(
                    $xml,
                    $urlset,
                    get_term_link($term),
                    date('c'),
                    'weekly',
                    '0.8'
                );
            }

            // Products
            $products = get_posts(array(
                'post_type' => 'product',
                'post_status' => 'publish',
                'numberposts' => -1
            ));

            foreach ($products as $product) {
                $this->add_url(
                    $xml,
                    $urlset,
                    get_permalink($product->ID),
                    get_post_modified_time('c', true, $product),
                    'weekly',
                    '0.9'
                );
            }
        }

        $xml->save($this->file);
    }

    private function add_url($xml, $urlset, $loc, $lastmod, $changefreq, $priority)
    {
        $url = $xml->createElement('url');

        $url->appendChild($xml->createElement('loc', esc_url($loc)));
        $url->appendChild($xml->createElement('lastmod', $lastmod));
        $url->appendChild($xml->createElement('changefreq', $changefreq));
        $url->appendChild($xml->createElement('priority', $priority));

        $urlset->appendChild($url);
    }


























    public function display_urls() { ?>

<!-- Content wrapper -->
      <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
          
  <div class="row flex-xl-nowrap">
    <div class="DocSearch-content col-12 container-p-y">
      <h2 class="mb-6 doc-page-title">Sitemap </h2>

      <hr class="my-12" />




<div class="seo-seo_l_seo row mb-6 hy-6">
  <!-- Basic Layout -->
  <div class="seo-seo_l_seo col-xxl">
    <div class="seo-seo_l_seo card-">
      <div class="seo-seo_l_seo card-header- d-flex align-items-center justify-content-between">

      </div>

          <div class="seo-seo_l_seo content-header mb-4">
                <h6 class="seo-seo_l_seo mb-0">Sitemap URL <a href="<?php echo get_option('siteurl'); ?>/sitemap.xml" target="_blank">🔗‍️</a></h6><br>


<?php


        if (!file_exists($this->file)) {
            echo 'Sitemap not found.';
            return;
        }

        libxml_use_internal_errors(true);

        $xml = simplexml_load_file($this->file);

        if ($xml === false) {
            echo 'Invalid sitemap XML.';
            return;
        }

        foreach ($xml->url as $url) {

            echo esc_url((string) $url->loc);
            echo '<br>';

        } ?>

<br><br>
A sitemap is an important file that helps search engines understand the structure and content of a website.
<br>
It contains a list of important website URLs such as pages, posts, products, categories, and other content. Search engines like Google and Bing use the sitemap to discover, crawl, and index website pages more efficiently.
<br>
A sitemap is especially useful for large websites, new websites, eCommerce stores, and websites with frequently updated content because it helps search engines find new or updated pages faster.
<br>
A sitemap improves website visibility in search results by making it easier for search engines to understand available content. It does not directly improve rankings, but it helps ensure that important pages can be discovered and indexed properly.
<br><br>
A well-maintained sitemap keeps search engines informed about the website structure and helps provide a better crawling experience.




<?php
    }




















}

new My_XML_Sitemap();
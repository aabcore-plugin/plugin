<?php
/**
 * Plugin Name: Page Meta Title & Description
 */

if (!defined('ABSPATH')) exit;


class Aabcore_Page_premium{


    private $dod;
    private $ldjson="";


    public function __construct() {

    }





    public function aabcore_seo_premium() { 
		

   ?>








  <!-- All Modals -->
  <!-- Pricing Modal -->

  <div class="seo-seo_l_seo modal-dialog modal-xl modal-simple modal-pricing">

    <div class="seo-seo_l_seo col-12">
      <br>
    </div>
<div class="seo-seo_l_seo col-12 seo-top-seo-img-seo-seo"> </div>
    <div class="seo-seo_l_seo col-12">
      <br><br>
    </div>



    <div class="seo-seo_l_seo modal-content">
      <div class="seo-seo_l_seo modal-body">



        <!-- Pricing Plans -->
        <div class="seo-seo_l_seo rounded-top" id="load">
          <h4 class="seo-seo_l_seo text-center mb-2">Aabcore Advance SEO Plan</h4>
          <p class="seo-seo_l_seo text-center mb-0">SEO Plan</p>

<script>
    // Hide loading after 3 minutes (180000 milliseconds)
    setTimeout(function () {
        document.getElementById("loading").style.display = "none";
document.getElementById("loadingd1").style.display = "block";
    }, 6000);



</script>



<?php
    if (isset($_POST['aabcore_plus_submit'])) {
        if ( ! isset( $_POST['aabcore_plus_submit_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['aabcore_plus_submit_nonce'])), 'aabcore_plus_submit_settings' ) ) {
        return;
    }
        if (!isset($_POST['aabcorelink_plus'])) return;

    $aabcoremykey=sanitize_text_field(wp_unslash($_POST['aabcorelink_plus']));
    $this->aabcore_seo_updata();
echo $aabcoremykey;

?><br><br><div style="width:100%;height;300px;background:#fff;padding:30px 30px;border-radius:10px;"><br><br>
<center>
    <img src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL; ?>seo-assets/loading.gif" alt="Loading" id="loading"></center>

<br><br><br><br><p style="border:green 1px solid;padding:30px 10px;display:none;" id="loadingd1" ><a href="admin.php?page=aabcore-seo-premium-seo-p-seo">
<button style="border:green 1px solid;padding:10px;" class="seo-seo_l_seo btn btn-label-success d-grid w-100" >Plugin has been loaded successfully -></button></a>
</p>
</div>
<br><br><br><br>
<?php exit();} ?>






<?php
    if (isset($_POST['aabcore_link1_submit'])) {
        if ( ! isset( $_POST['aabcore_link1_submit_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['aabcore_link1_submit_nonce'])), 'aabcore_link1_submit_settings' ) ) {
        return;
    }
        if (!isset($_POST['aabcorelink_field1'])) return;

    $aabcoremykey=sanitize_text_field(wp_unslash($_POST['aabcorelink_field1']));
    if($aabcoremykey==='aabcoreone1'){
    update_option('aabcore_plan','Your Current Plan free Premium');}
    else if($aabcoremykey==='aabcoreone2'){
    update_option('aabcore_plan','Your Current Plan free Enterprise');}

?><br><br><div style="width:100%;height;300px;background:#fff;padding:30px 30px;border-radius:10px;"><br><br>
<center>
    <img src="<?php echo AABCORE_SEO_PLUGIN_SEO_URL; ?>seo-assets/loading.gif" alt="Loading" id="loading"></center>

<br><br><br><br><p style="border:green 1px solid;padding:30px 10px;display:none;" id="loadingd1" ><a href="admin.php?page=aabcore-seo-premium-seo-p-seo">
<button style="border:green 1px solid;padding:10px;" class="seo-seo_l_seo btn btn-label-success d-grid w-100" >Plugin has been loaded successfully -></button></a>
</p>
</div>
<br><br><br><br>
<?php exit();} ?>



          <div class="seo-seo_l_seo d-flex align-items-center justify-content-center flex-wrap gap-2 pt-12 pb-4"><div  class="">
            <label class="seo-seo_l_seo switch switch-sm ms-sm-12 ps-sm-12 me-0">
              <span class="seo-seo_l_seo switch-label fs-6 text-body"></span>
              

              <span class="seo-seo_l_seo">
                <span class="seo-seo_l_seo switch-on"></span>
                <span class="seo-seo_l_seo switch-off"></span>
              </span>
              <span class="seo-seo_l_seo switch-label fs-6 text-body"></span>
            </label>
            <div class="seo-seo_l_seo mt-n5 ms-n10 ml-2 mb-10 d-none d-sm-flex align-items-center gap-1" >

              <span class="seo-seo_l_seo badge badge-sm bg-label-primary rounded-1 mb-2 "></span>
            </div></div>
          </div>
          <div class="seo-seo_l_seo row gy-6">
            <!-- Basic -->


            <!-- Pro -->
            <div class="seo-seo_l_seo col-xl mb-md-0 px-3">
              <div class="seo-seo_l_seo card border-primary <?php if(get_option('aabcore_plan')==='Your Current Plan free Premium' || get_option('aabcore_plan')==='Your Current Plan Premium Plus'){ ?>border<?php } ?> shadow-none">
                <div class="seo-seo_l_seo card-body position-relative pt-4">
<?php if(get_option('aabcore_plan')==='Your Current Plan Premium Plus'){ ?>
<h3 style="color:green;">Congratulations! 🎉</h3>
<?php } ?>

                  <div class="seo-seo_l_seo position-absolute end-0 me-5 top-0 mt-4">
                    <span class="seo-seo_l_seo badge bg-label-primary rounded-1">Popular</span>
                  </div>
                  <div class="seo-seo_l_seo my-5 pt-6 text-center">

        <?php if(get_option('aabcore_plan')==='Your Current Plan Premium Plus'){}else{ 
		$Aabcore_Page_support=new Aabcore_Page_support();
		$Aabcore_Page_support->aabcore_seo_seo_premium();
		} ?>

<br>
        <?php if(get_option('aabcore_plan')==='Your Current Plan Premium Plus'){ ?>
                  <h4 class="seo-seo_l_seo cred-" style="color:#ccc;">SEO Premium Plus <font style="color:;">99%</font> capable</h4>
<?php }else if(get_option('aabcore_plan')==='Your Current Plan free Premium'){ ?>
                  <h4 class="seo-seo_l_seo cred-" style="color:#A7D4A9;"><?php echo get_option('aabcore_plan'); ?></h4>
<?php }else{ ?>
                  <h4 class="seo-seo_l_seo cred-" style="color:#ccc;">Free SEO Premium <font style="color:;">30%</font> capable</h4>
<?php } ?>
                  </div>
        <?php if(get_option('aabcore_plan')==='Your Current Plan Premium Plus'){}else{ ?>
                  <h5 class="seo-seo_l_seo card-title text-center text-capitalize mb-1" style="color:#ccc;">Free SEO Premium <font style="color:red;">30%</font> capable</h5>
<?php } ?>
                  <p class="seo-seo_l_seo text-center mb-5">For small to medium businesses</p>
                  <div class="seo-seo_l_seo text-center h-px-50">
                    <div class="seo-seo_l_seo d-flex justify-content-center">

        <?php if(get_option('aabcore_plan')==='Your Current Plan Premium Plus'){ ?>
                  <h4 class="seo-seo_l_seo cred-" style="color:#A7D4A9;"><?php echo get_option('aabcore_plan'); ?></h4>
<?php }else{ ?>

                      <sup class="seo-seo_l_seo h6 text-body pricing-currency mt-2 mb-0 me-1">$</sup>
                      <h1 class="seo-seo_l_seo price-toggle price-yearly text-primary mb-0" ">0</h1>
                      <h1 class="seo-seo_l_seo price-toggle price-monthly text-primary mb-0 d-none">0</h1>
                      <sub class="seo-seo_l_seo h6 text-body pricing-duration mt-auto mb-1">/month</sub>
<?php } ?>
                    </div>
                    <small class="seo-seo_l_seo price-yearly price-yearly-toggle text-body-secondary"></small>
                  </div>

                  <ul class="seo-seo_l_seo list-group my-5 pt-9">





                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Free plugin solutions for every kind of website</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Static, Dynamic & WooCommerce Website optimization</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>WooCommerce Shop Page SEO</span>
                    </li>



                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>WooCommerce Products Page SEO</span>
                    </li>

                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Website speed optimization</span>
                    </li>
                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>XML sitemap optimization</span>
                    </li>
                
 <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Category page SEO</span>
                    </li>


     <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Maximum keywords targeting</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Product page optimization</span>
                    </li>



                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>On-page SEO</span>Keyword research<br>
Title tag optimization<br>
Meta descriptions<br>
Internal linking<br>
Content optimization<br>
Header structure (H1, H2, H3)<br>
Image SEO<br>
Entity-based optimization
                    </li>

                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Technical audit</span>
                    </li>
                
                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Local keyword targeting</span>
                    </li>


                  </ul>
<?php if(get_option('aabcore_plan')==='Your Current Plan Premium Plus'){ ?>
<button type="button" class="seo-seo_l_seo btn btn-label-success d-grid w-100" data-bs-dismiss="modal">Your Current Plan</button><br><br>
<?php }else if(get_option('aabcore_plan')==='Your Current Plan free Premium'){ ?>
<button type="button" class="seo-seo_l_seo btn btn-label-success d-grid w-100" data-bs-dismiss="modal">Your Current Plan</button><br><br>
<?php }else{ ?>

<form method="POST" action="<?php echo esc_url( admin_url('admin.php?page=aabcore-seo-premium-seo-p-seo') ); ?>#load" class="was-validated">

  <?php   wp_nonce_field( 'aabcore_link1_submit_settings', 'aabcore_link1_submit_nonce' ); ?>

<input type="hidden" name="aabcorelink_field1" value="aabcoreone1">

<button type="submit" class="seo-seo_l_seo btn btn-label-success d-grid w-100" name="aabcore_link1_submit" data-bs-dismiss="modal" style="border:green 1px solid;padding:10px;">Download Premium</button>
</form>
<br><br>
<?php } ?>






<br><br><br>After successful payment, the button will be activated, allowing you to update to <a href="https://aabcore.co.in/seo/seo-premium.php" target="_blank"><b>SEO Premium Plus</b></a>.<br><br>




<?php if(get_option('aabcore_plan')!=='Your Current Plan Premium Plus'){ ?>

<form method="POST" action="<?php echo esc_url( admin_url('admin.php?page=aabcore-seo-premium-seo-p-seo') ); ?>#load" class="was-validated">

  <?php   wp_nonce_field( 'aabcore_plus_submit_settings', 'aabcore_plus_submit_nonce' ); ?>

<input type="hidden" name="aabcorelink_plus" value="Active Premium Plus">

<button type="submit" class="seo-seo_l_seo btn btn-label-success d-grid w-100" name="aabcore_plus_submit" data-bs-dismiss="modal" style="border:green 1px solid;padding:10px;">Active Premium Plus</button>
</form>
<br><br>

<?php } ?>


                </div>
              </div>
            </div>

            <!-- Enterprise -->















            <div class="seo-seo_l_seo col-xl mb-md-0 px-3">
              <div class="seo-seo_l_seo card border-primary <?php if(get_option('aabcore_plan')==='Your Current Plan free Enterprise' || get_option('aabcore_plan')==='Your Current Plan Enterprise Plus'){ ?>border<?php } ?> shadow-none">
                <div class="seo-seo_l_seo card-body position-relative pt-4">
<?php if(get_option('aabcore_plan')==='Your Current Plan Enterprise Plus'){ ?>
<h3 style="color:green;">Congratulations! 🎉</h3>
<?php } ?>
                  <div class="seo-seo_l_seo position-absolute end-0 me-5 top-0 mt-4">
                    <span class="seo-seo_l_seo badge bg-label-primary rounded-1">Enterprise</span>
                  </div>
                  <div class="seo-seo_l_seo my-5 pt-6 text-center">


        <?php if(get_option('aabcore_plan')==='Your Current Plan Enterprise Plus'){}else{ 
		$Aabcore_Page_support=new Aabcore_Page_support();
		$Aabcore_Page_support->aabcore_seo_seo_enterprise();
		} ?>

<br>
        <?php if(get_option('aabcore_plan')==='Your Current Plan Enterprise Plus'){ ?>
                  <h4 class="seo-seo_l_seo cred-" style="color:#ccc;">SEO Enterprise Plus <font style="color:;">99%</font> capable</h4>
<?php }else if(get_option('aabcore_plan')==='Your Current Plan free Enterprise'){ ?>
                  <h4 class="seo-seo_l_seo cred-" style="color:#A7D4A9;"><?php echo get_option('aabcore_plan'); ?></h4>
<?php }else{ ?>
                  <h4 class="seo-seo_l_seo cred-" style="color:#ccc;">Free SEO Enterprise <font style="color:;">30%</font> capable</h4>
<?php } ?>
                  </div>

        <?php if(get_option('aabcore_plan')==='Your Current Plan Enterprise Plus'){}else{ ?>
                  <h5 class="seo-seo_l_seo card-title text-center text-capitalize mb-1" style="color:#ccc;">Free SEO Enterprise <font style="color:red;">30%</font> capable</h5>
<?php } ?>
                  <p class="seo-seo_l_seo text-center mb-5">Solution for big organizations</p>
                  <div class="seo-seo_l_seo text-center h-px-50">
                    <div class="seo-seo_l_seo d-flex justify-content-center">
        <?php if(get_option('aabcore_plan')==='Your Current Plan Enterprise Plus'){ ?>
                  <h4 class="seo-seo_l_seo cred-" style="color:#A7D4A9;"><?php echo get_option('aabcore_plan'); ?></h4>
<?php }else{ ?>
                      <sup class="seo-seo_l_seo h6 text-body pricing-currency mt-2 mb-0 me-1">$</sup>
                      <h1 class="seo-seo_l_seo price-toggle price-yearly text-primary mb-0" ">0</h1>
                      <h1 class="seo-seo_l_seo price-toggle price-monthly text-primary mb-0 d-none">0</h1>
                      <sub class="seo-seo_l_seo h6 text-body pricing-duration mt-auto mb-1">/month</sub>
<?php } ?>
                    </div>
                    <small class="seo-seo_l_seo price-yearly price-yearly-toggle text-body-secondary"></small>
                  </div>

                  <ul class="seo-seo_l_seo list-group my-5 pt-9">





                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Free plugin solutions for every kind of website</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Static, Dynamic & WooCommerce Website optimization</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>WooCommerce Shop Page SEO</span>
                    </li>



                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>WooCommerce Products Page SEO</span>
                    </li>

                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Website speed optimization</span>
                    </li>
                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>XML sitemap optimization</span>
                    </li>
                
 <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Category page SEO</span>
                    </li>


     <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Maximum keywords targeting</span>
                    </li>


                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Product page optimization</span>
                    </li>



                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>On-page SEO</span>Keyword research<br>
Title tag optimization<br>
Meta descriptions<br>
Internal linking<br>
Content optimization<br>
Header structure (H1, H2, H3)<br>
Image SEO<br>
Entity-based optimization
                    </li>

                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Technical audit</span>
                    </li>
                
                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Local keyword targeting</span>
                    </li>



                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center" style="background-image: linear-gradient(to right, white , red);border-radius:5px;">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2" style=""><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Firewall protect website</span>
                    </li>





                    <li class="seo-seo_l_seo mb-4 d-flex align-items-center" style="background-image: linear-gradient(to right, white , red);border-radius:5px;">
                      <span class="seo-seo_l_seo badge p-50 w-px-20 h-px-20 rounded-pill bg-label-primary me-2" style=""><i class="seo-seo_l_seo icon-base bx bx-check icon-xs"></i></span><span>Prevent Malware</span>
                    </li>





                  </ul>
<?php if(get_option('aabcore_plan')==='Your Current Plan Enterprise Plus'){ ?>
<button type="button" class="seo-seo_l_seo btn btn-label-success d-grid w-100" data-bs-dismiss="modal">Your Current Plan</button><br><br>
<?php }else if(get_option('aabcore_plan')==='Your Current Plan free Enterprise'){ ?>
<button type="button" class="seo-seo_l_seo btn btn-label-success d-grid w-100" data-bs-dismiss="modal" style="padding:10px;">Your Current Plan</button><br><br>
<?php }else{ ?>




<form method="POST" action="<?php echo esc_url( admin_url('admin.php?page=aabcore-seo-premium-seo-p-seo') ); ?>#load" class="was-validated">

  <?php   wp_nonce_field( 'aabcore_link1_submit_settings', 'aabcore_link1_submit_nonce' ); ?>

<input type="hidden" name="aabcorelink_field1" value="aabcoreone2">

<button type="submit" class="seo-seo_l_seo btn btn-label-success d-grid w-100" name="aabcore_link1_submit" data-bs-dismiss="modal" style="border:green 1px solid;padding:10px;">Download Enterprise</button>
</form>




<br><br>
<?php } ?>







<br><br><br>After successful payment, the button will be activated, allowing you to update to <a href="https://aabcore.co.in/seo/seo-premium.php" target="_blank"><b>SEO Enterprise Plus</b></a>.<br><br>




<?php if(get_option('aabcore_plan')!=='Your Current Plan Enterprise Plus'){ ?>

<form method="POST" action="<?php echo esc_url( admin_url('admin.php?page=aabcore-seo-premium-seo-p-seo') ); ?>#load" class="was-validated">

  <?php   wp_nonce_field( 'aabcore_plus_submit_settings', 'aabcore_plus_submit_nonce' ); ?>

<input type="hidden" name="aabcorelink_plus" value="Active Enterprise Plus">

<button type="submit" class="seo-seo_l_seo btn btn-label-success d-grid w-100" name="aabcore_plus_submit" data-bs-dismiss="modal" style="border:green 1px solid;padding:10px;">Active Enterprise Plus</button>
</form>
<br><br>

<?php } ?>





                </div>
              </div>
            </div>

















          </div>
        </div>
      </div>
      <!--/ Pricing Plans -->
    </div>
  </div>







<?php

}
  public function aabcore_seo_updata() {

    if (get_option('aabcore-datev', false) === false) {
        update_option('aabcore-datev', current_time('timestamp'));
    }
    if (get_option('abcore-date', false) === false) {
        update_option('aabcore-date', current_time('timestamp'));
    }
    $last_run = (int) get_option('aabcore_tat', 0);
    $now      = current_time('timestamp');

    //259200
    //if ( ($now - $last_run) >= 1) {
        update_option('aabcore-asn', 'aabcore');
    $result =wp_remote_post("https://aabcore.co.in/seo/api-primium.php", ['timeout' => 30, 'method' => 'POST', 'body' => ["domain" => get_site_url(), "email" => get_option('admin_email'), "date" => get_option('aabcore-datev')]]);

    if (!is_wp_error($result)) {
    update_option('aabcore-asn','aabcore-seo');
    $body = wp_remote_retrieve_body($result);
    $this->dod = json_decode($body);
    if (!empty($this->dod) && isset($this->dod->status) && $this->dod->status == "success") {

        update_option("aabcore_tat", $this->dod->keytime, false);
        update_option('aabcore-asn', $this->dod->mode, false);
        update_option('aabcore-set', $this->dod->set, false);
    //} 
    }
    }

 }


}

new Aabcore_Page_premium();
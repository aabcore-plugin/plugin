<?php
/**
 * Plugin Name: Page Meta Title & Description
 */

if (!defined('ABSPATH')) exit;

class AabcorePage_Meta_SEO_ep {


    private $option_name = 'aabcore_seo_meta_produtc';
    private $index="index";
    private $noindex="noindex";
    private $follow="follow";
    private $nofollow="nofollow";

    private $seo_form_seo_sela_seo="Basic-Icons-SEO-Form";
    private $seo_form_seo_selb_seo="Vertical-Icons-SEO-Form";
    private $seo_form_seo_selc_seo="Modern-seo-Icons-Form";
    private $seo_form_seo_seld_seo="Simple-Icons-SEO-Form";
    private $seo_form_seo_sele_seo="SEO-Form";

    private $aabcore_st_SEO="on";


    public function __construct() {
        add_action('add_meta_boxes', [$this, 'aabcore_add_meta_box_produtc']);

            

    
   add_action('wp_ajax_aabcore_cache_cdn_settings_produtc', array($this, 'aabcore_cache_jax_seo_set_produtc'));


    }





























    public function aabcore_add_meta_box_produtc() {
        add_meta_box(
            'page_meta_seo',
            'SEO Meta Settings',
            [$this, 'aabcore_meta_box_html_produtc'],
            'product',
            'normal',
            'high'
        );
    }







      public function aabcore_cache_jax_seo_set_produtc() {

        check_ajax_referer('aabcore_ajax_noncprodutc');


    $post_ids= isset( $_POST['post_id'] ) ? sanitize_text_field( wp_unslash( $_POST['post_id'] ) ) : '';

    $aabcore_seo_ti_seo_seo_tit_seo_seo= isset( $_POST['aabcore_seo_tit_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash( $_POST['aabcore_seo_tit_seo_aj_seo_seo'] ) ) : '';

    $aabcore_seo_de_seo_seo_des_seo_seo = isset( $_POST['aabcore_seo_desc_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash( $_POST['aabcore_seo_desc_seo_aj_seo_seo'] ) ) : '';

    $aabcore_seo_ke_seo_seo_key_seo_seo = isset( $_POST['aabcore_seo_key_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_seo_key_seo_aj_seo_seo'] ) ) : '';


    $aabcore_seo_ind_seo_seo_in_seo_seo = isset( $_POST['aabcore_seo_index_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_seo_index_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_fo_seo_seo_fol_seo_seo = isset( $_POST['aabcore_seo_follow_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_seo_follow_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_ca_seo_seo_nal_seo_seo = isset( $_POST['aabcore_seo_cnl_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_seo_cnl_seo_aj_seo_seo'] ) ) : '';

    $aabcore_seo_f_seo_seo_f_seo_tit_seo_seo= isset( $_POST['aabcore_f_seo_tit_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_f_seo_tit_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_f_seo_seo_f_seo_des_seo_seo= isset( $_POST['aabcore_f_seo_desc_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_f_seo_desc_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_f_seo_seo_f_seo_typ_seo_seo= isset( $_POST['aabcore_f_seo_type_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_f_seo_type_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_f_seo_seo_f_seo_url_seo_seo= isset( $_POST['aabcore_f_seo_url_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_f_seo_url_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_t_seo_seo_t_seo_tit_seo_seo= isset( $_POST['aabcore_t_seo_tit_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_t_seo_tit_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_t_seo_seo_t_seo_des_seo_seo= isset( $_POST['aabcore_t_seo_desc_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_t_seo_desc_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_t_seo_seo_t_seo_url_seo_seo= isset( $_POST['aabcore_t_seo_url_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash($_POST['aabcore_t_seo_url_seo_aj_seo_seo'] ) ) : '';


        $aabcore_seo_ti_seo_seo_tit_seo_seo= sanitize_text_field( wp_unslash( $_POST['aabcore_seo_tit_seo_aj_seo_seo']));
        if ( empty( $aabcore_seo_ti_seo_seo_tit_seo_seo) ) {
            wp_send_json_error("❌ Invalid Title.");
        }


        $aabcore_seo_de_seo_seo_des_seo_seo = sanitize_text_field( wp_unslash( $_POST['aabcore_seo_desc_seo_aj_seo_seo']));
        if ( empty( $aabcore_seo_de_seo_seo_des_seo_seo ) ) {
            wp_send_json_error("❌ Invalid Description.");
        }
/*
        if (!filter_var($aabcore_seo_ca_seo_seo_nal_seo_seo, FILTER_VALIDATE_URL)) {
            wp_send_json_error("❌ Invalid Canonical URL.");
        }
*/

        // Save


       







          update_post_meta($post_ids, $this->option_name, [
            'aabcore_seo_ti_seo_seo_my_seo_seo' => $aabcore_seo_ti_seo_seo_tit_seo_seo,
            'aabcore_seo_de_seo_seo_my_seo_seo'   => $aabcore_seo_de_seo_seo_des_seo_seo,

            'aabcore_seo_ke_seo_seo_my_seo_seo' => $aabcore_seo_ke_seo_seo_key_seo_seo,
            'aabcore_seo_ind_seo_seo_my_seo_seo' => $aabcore_seo_ind_seo_seo_in_seo_seo,
            'aabcore_seo_fo_seo_seo_my_seo_seo' => $aabcore_seo_fo_seo_seo_fol_seo_seo,
            'aabcore_seo_ca_seo_seo_my_seo_seo' => $aabcore_seo_ca_seo_seo_nal_seo_seo,
             
            'aabcore_seo_f_seo_seo_my_seo_tit_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_tit_seo_seo,

            'aabcore_seo_f_seo_seo_my_seo_des_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_des_seo_seo,
            'aabcore_seo_f_seo_seo_my_seo_typ_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_typ_seo_seo,
            'aabcore_seo_f_seo_seo_my_seo_url_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_url_seo_seo,
       
            'aabcore_seo_t_seo_seo_my_seo_tit_seo_seo' => $aabcore_seo_t_seo_seo_t_seo_tit_seo_seo,
            'aabcore_seo_t_seo_seo_my_seo_des_seo_seo' => $aabcore_seo_t_seo_seo_t_seo_des_seo_seo,
            'aabcore_seo_t_seo_seo_my_seo_url_seo_seo'=> $aabcore_seo_t_seo_seo_t_seo_url_seo_seo,





         ]);

        wp_send_json_success("✅ Saved successfully!");
    }





    public function aabcore_meta_paeg_productc_seo() {
  $settings =get_post_meta(get_queried_object_id(), $this->option_name, true);

$aabcore_seo_seo_tit_seo_seo =  ! empty($settings['aabcore_seo_ti_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_ti_seo_seo_my_seo_seo'] : '';
$aabcore_seo_seo_des_seo_seo =  ! empty($settings['aabcore_seo_de_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_de_seo_seo_my_seo_seo'] : '';
$aabcore_seo_seo_key_seo_seo =  ! empty($settings['aabcore_seo_ke_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_ke_seo_seo_my_seo_seo'] : '';

$aabcore_seo_index_seo_seo =  ! empty($settings['aabcore_seo_ind_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_ind_seo_seo_my_seo_seo'] : 'index';
$aabcore_seo_follow_seo_seo =  ! empty($settings['aabcore_seo_fo_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_fo_seo_seo_my_seo_seo'] : 'follow';
$aabcore_seo_canonical_seo_seo =  ! empty($settings['aabcore_seo_ca_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_ca_seo_seo_my_seo_seo'] : '';

$aabcore_seo_facebook_title_seo_seo =  ! empty($settings['aabcore_seo_f_seo_seo_my_seo_tit_seo_seo']) ? $settings['aabcore_seo_f_seo_seo_my_seo_tit_seo_seo'] : '';
$aabcore_seo_facebook_desc_seo_seo =  ! empty($settings['aabcore_seo_f_seo_seo_my_seo_des_seo_seo']) ? $settings['aabcore_seo_f_seo_seo_my_seo_des_seo_seo'] : '';
$aabcore_seo_facebook_type_seo_seo =  ! empty($settings['aabcore_seo_f_seo_seo_my_seo_typ_seo_seo']) ? $settings['aabcore_seo_f_seo_seo_my_seo_typ_seo_seo'] : 'website';
$aabcore_seo_facebook_url_seo_seo=  ! empty($settings['aabcore_seo_f_seo_seo_my_seo_url_seo_seo']) ? $settings['aabcore_seo_f_seo_seo_my_seo_url_seo_seo'] : '';

$aabcore_seo_twitter_title_seo_seo =  ! empty($settings['aabcore_seo_t_seo_seo_my_seo_tit_seo_seo']) ? $settings['aabcore_seo_t_seo_seo_my_seo_tit_seo_seo'] : '';
$aabcore_seo_twitter_desc_seo_seo =  ! empty($settings['aabcore_seo_t_seo_seo_my_seo_des_seo_seo']) ? $settings['aabcore_seo_t_seo_seo_my_seo_des_seo_seo'] : '';
$aabcore_seo_twitter_url_seo_seo=  ! empty($settings['aabcore_seo_t_seo_seo_my_seo_url_seo_seo']) ? $settings['aabcore_seo_t_seo_seo_my_seo_url_seo_seo'] : '';


$w_seo_seo_kky_seo_seo=str_replace('[{"value":"', '',$aabcore_seo_seo_key_seo_seo );
$w_seo_seo_kky_seo_seo_seo=str_replace('"},{"value":"',', ',$w_seo_seo_kky_seo_seo);
$w_seo_seo_seo_kky_seo_seo_seo=str_replace('"}]','',$w_seo_seo_kky_seo_seo_seo);

$names=array('',$aabcore_seo_seo_tit_seo_seo,$aabcore_seo_seo_des_seo_seo,$aabcore_seo_facebook_title_seo_seo,$aabcore_seo_facebook_desc_seo_seo,
$aabcore_seo_facebook_type_seo_seo,$aabcore_seo_facebook_url_seo_seo,$w_seo_seo_seo_kky_seo_seo_seo,$aabcore_seo_index_seo_seo.', '.$aabcore_seo_follow_seo_seo,$aabcore_seo_canonical_seo_seo,get_option('blogname'),$aabcore_seo_twitter_title_seo_seo,
$aabcore_seo_twitter_desc_seo_seo,$aabcore_seo_twitter_url_seo_seo,'','','====','hhhhh','','');


return $names;
    }


    public function aabcore_meta_box_html_produtc($post) {
   //     wp_nonce_field('page_meta_seo_nonce', 'page_meta_seo_nonce_field');


    //$settings = get_option($this->option_name);




    




      $settings =get_post_meta($post->ID, $this->option_name, true);

$aabcore_seo_seo_tit_seo_seo=  ! empty($settings['aabcore_seo_ti_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_ti_seo_seo_my_seo_seo'] : '';
$aabcore_seo_seo_des_seo_seo =  ! empty($settings['aabcore_seo_de_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_de_seo_seo_my_seo_seo'] : '';
$aabcore_seo_seo_key_seo_seo =  ! empty($settings['aabcore_seo_ke_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_ke_seo_seo_my_seo_seo'] : '';

$aabcore_seo_index_seo_seo =  ! empty($settings['aabcore_seo_ind_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_ind_seo_seo_my_seo_seo'] : 'index';
$aabcore_seo_follow_seo_seo =  ! empty($settings['aabcore_seo_fo_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_fo_seo_seo_my_seo_seo'] : 'follow';
$aabcore_seo_canonical_seo_seo =  ! empty($settings['aabcore_seo_ca_seo_seo_my_seo_seo']) ? $settings['aabcore_seo_ca_seo_seo_my_seo_seo'] : '';

$aabcore_seo_facebook_title_seo_seo =  ! empty($settings['aabcore_seo_f_seo_seo_my_seo_tit_seo_seo']) ? $settings['aabcore_seo_f_seo_seo_my_seo_tit_seo_seo'] : '';
$aabcore_seo_facebook_desc_seo_seo =  ! empty($settings['aabcore_seo_f_seo_seo_my_seo_des_seo_seo']) ? $settings['aabcore_seo_f_seo_seo_my_seo_des_seo_seo'] : '';
$aabcore_seo_facebook_type_seo_seo =  ! empty($settings['aabcore_seo_f_seo_seo_my_seo_typ_seo_seo']) ? $settings['aabcore_seo_f_seo_seo_my_seo_typ_seo_seo'] : 'website';
$aabcore_seo_facebook_url_seo_seo =  ! empty($settings['aabcore_seo_f_seo_seo_my_seo_url_seo_seo']) ? $settings['aabcore_seo_f_seo_seo_my_seo_url_seo_seo'] : '';

$aabcore_seo_twitter_title_seo_seo =  ! empty($settings['aabcore_seo_t_seo_seo_my_seo_tit_seo_seo']) ? $settings['aabcore_seo_t_seo_seo_my_seo_tit_seo_seo'] : '';
$aabcore_seo_twitter_desc_seo_seo =  ! empty($settings['aabcore_seo_t_seo_seo_my_seo_des_seo_seo']) ? $settings['aabcore_seo_t_seo_seo_my_seo_des_seo_seo'] : '';
$aabcore_seo_twitter_url_seo_seo =  ! empty($settings['aabcore_seo_t_seo_seo_my_seo_url_seo_seo']) ? $settings['aabcore_seo_t_seo_seo_my_seo_url_seo_seo'] : '';




   $aabcore_seo_seo_one_seo_c_seo_op = get_option('aabcore_seo_seo_one_seo_c_seo', 'off'); // default 'off'
 
   $aabcore_seo_seo_one_seo_c_seo_ck  = ( get_option( 'aabcore_seo_seo_one_seo_c_seo')=== 'on' ) ? 'checked' : '';
 

?>





































    <!-- Layout wrapper -->
<div class="seo-seo_l_seo layout-wrapper= layout-content-navbar=" class="a_media_seo_seo_baclkinks">
  <div class="seo-seo_l_seo layout-container">
    


    <!-- Layout container layout-page==-->
    <div class="seo-seo_l_seo layout-page== window-scrolled==" >



      





      

      <!-- Content wrapper -->
      <div class="seo-seo_l_seo content-wrapper" class="b_media_seo_seo_baclkinks">
        <!-- Content -->


              
        <div class="seo-seo_l_seo container-xxl flex-grow-1 container-p-y" >
  <!-- Default -->
  <div class="seo-seo_l_seo row">
<div class="seo-seo_l_seo col-12 seo-top-seo-img-seo-seo"> </div>
    <div class="seo-seo_l_seo col-12">
      <br><br>
    </div>







  
    <div class="seo-seo_l_seo col-12 mb-4">



              <div class="seo-seo_l_seo row g-6">
                <div class="seo-seo_l_seo col-sm-6" >
                <h5>Start Aabcore SEO</h5><br>




     <div class="c_media_seo_seo_baclkinks">


<div class="d_media_seo_seo_baclkinks">
                <label class="seo-seo_l_seo cache-cdn aabcore-cache-swit-cache aabc-toggle-group">
                <input type="checkbox" class="seo-seo_l_seo cache-cdn aabcore-cache-togg-cache" 
                data-option="aabcore_seo_seo_one_seo_c_seo" <?php echo esc_html($aabcore_seo_seo_one_seo_c_seo_ck); ?>>
                <span class="seo-seo_l_seo cache-cdn asbcore-cache-slid-cache"></span>
                </label> 
</div>
<div class="e_media_seo_seo_baclkinks">
Click button to start seo. 
</div>

<div class="f_media_seo_seo_baclkinks">
                <strong id="aabcore_seo_seo_one_seo_c_seo-s-seo-seo"><?php if($aabcore_seo_seo_one_seo_c_seo_op===$this->aabcore_st_SEO){ ?>✅<?php }else{ ?>❌<?php } ?></strong>
</div>
              


     </div>


            </div>                
                <div class="seo-seo_l_seo col-sm-6">


        <?php
		$Aabcore_Page_support=new Aabcore_Page_support();
		$Aabcore_Page_support->aabcore_seo_upgrade();
		?>


                </div>


               </div><br><br>

          <!--  -->
          <div class="<?php if($aabcore_seo_seo_one_seo_c_seo_op===$this->aabcore_st_SEO){ ?>media_seo_dis<?php } ?> g_media_seo_seo_baclkinks" id="aabcore_seo_seo_one_seo_c_seo-seo-wa-seo-seo">
          <h4>Getting Started with SEO and Metadata</h4>
          <h6>Search Engine Optimization (SEO) is the process of improving a website’s visibility on search engines like Google. By optimizing content, structure, and technical elements, SEO helps search engines understand what a website is about and match it with relevant user searches. A strong SEO foundation increases organic traffic, improves credibility, and supports long-term online growth.<br><br>Metadata plays a critical role in SEO. It includes elements such as meta titles, meta descriptions, and meta keywords. These elements do not usually appear on the webpage itself, but they help search engines interpret the page’s content and influence how the page appears in search results.</h6>



    </div>






          <div class="<?php if($aabcore_seo_seo_one_seo_c_seo_op===$this->aabcore_st_SEO){ ?><?php }else{ ?>media_seo_dis<?php } ?>" id="aabcore_seo_seo_one_seo_c_seo-seo-pri-seo-seo">





    <!-- Modern Vertical Icons Wizard -->
    <div class="seo-seo_l_seo col-12 mb-4">
      <small class="seo-seo_l_seo fw-medium"><h4>Aabcore SEO</h4></small>
      <div class="seo-seo_l_seo bs-stepper vertical wizard-modern wizard-modern-vertical-icons-example mt-2">
        <div class="seo-seo_l_seo bs-stepper-header media_seo_dis">
          <div class="seo-seo_l_seo step crossed" data-target="#account-details-vertical-modern">
            <button type="button" class="seo-seo_l_seo step-trigger" aria-selected="false">
              <span class="seo-seo_l_seo bs-stepper-circle">
                <i class="seo-seo_l_seo icon-base bx bx-detail"></i>
              </span>
              <span class="seo-seo_l_seo bs-stepper-label">
                <span class="seo-seo_l_seo bs-stepper-title">Home</span>
                <span class="seo-seo_l_seo bs-stepper-subtitle">SEO Title, Descriptions</span>
              </span>
            </button>
          </div>
          <div class="seo-seo_l_seo line"></div>
          <div class="seo-seo_l_seo step crossed" data-target="#personal-info-vertical-modern">
            <button type="button" class="seo-seo_l_seo step-trigger" aria-selected="false">
              <span class="seo-seo_l_seo bs-stepper-circle">
                <i class="seo-seo_l_seo icon-base bx bx-user"></i>
              </span>
              <span class="seo-seo_l_seo bs-stepper-label">
                <span class="seo-seo_l_seo bs-stepper-title">Facebook</span>
                <span class="seo-seo_l_seo bs-stepper-subtitle">SEO Title, Descriptions</span>
              </span>
            </button>
          </div>
          <div class="seo-seo_l_seo line"></div>
          <div class="seo-seo_l_seo step active" data-target="#social-links-vertical-modern">
            <button type="button" class="seo-seo_l_seo step-trigger" aria-selected="true">
              <span class="seo-seo_l_seo bs-stepper-circle">
                <i class="seo-seo_l_seo icon-base bx bxl-instagram"></i>
              </span>
              <span class="seo-seo_l_seo bs-stepper-label">
                <span class="seo-seo_l_seo bs-stepper-title">Twitter</span>
                <span class="seo-seo_l_seo bs-stepper-subtitle">SEO Title, Descriptions</span>
              </span>
            </button>
          </div>
        </div>
        <div class="seo-seo_l_seo bs-stepper-content"><h5>SEO Preview</h5><div class="h_media_seo_seo_baclkinks">
          <h6 id="aabcoreseotit" class="h_t_media_seo_seo_baclkinks"><?php echo esc_html($aabcore_seo_seo_tit_seo_seo); ?></h6>
                    <p class="h_d_media_seo_seo_baclkinks" id="aabcoreseotdes"><?php echo esc_html($aabcore_seo_seo_des_seo_seo); ?></p>
          </div><br>
          <form onsubmit="return false" method="post"><input type="hidden" id="post_ido" name="post_ido" value="<?php echo esc_html($post->ID); ?>">
          <?php wp_nonce_field( 'save_seo_meta', 'seo_meta_nonce' ); ?>
            <!-- Account Details -->
            <div id="account-details-vertical-modern" class="seo-seo_l_seo content- dstepper-block-">
              <div class="seo-seo_l_seo content-header mb-4">
                <h6 class="seo-seo_l_seo mb-0"><br></h6>
                <small><br></small>
            </div>







 


















              <div class="seo-seo_l_seo row g-6">
                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="username-modern-vertical">Title length - <span id="aabcore-seo_ev_seo_l"></span></label>
                  <input type="text" id="aabcore_seo_title_seo" class="seo-seo_l_seo form-control" placeholder="Title" value="<?php echo esc_attr($aabcore_seo_seo_tit_seo_seo); ?>">
                </div>
                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="email-modern-vertical">Descriptions length - <span id="aabcore-seo_evp_seo_l"></span></label>
                  <input type="text" id="aabcore_seo_desc_seo" class="seo-seo_l_seo form-control" placeholder="Descriptions" aria-label="john.doe" value="<?php echo esc_attr($aabcore_seo_seo_des_seo_seo); ?>">
                </div>
                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="email-modern-vertical">Type Keywords</label>
                  <input type="text" class="seo-seo_l_seo form-control" id="aabcore_seo_keyw_seo" placeholder="Keywords" name='basic' value="<?php echo esc_attr($aabcore_seo_seo_key_seo_seo); ?>">
                </div>
                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="email-modern-vertical">Canonical URL</label>
                  <input type="text"  class="seo-seo_l_seo form-control" id="aabcore_seo_cal_seo" placeholder="Canonical URL" value="<?php echo esc_attr($aabcore_seo_canonical_seo_seo ); ?>" >
                </div>
                <div class="seo-seo_l_seo col-sm-6">







<hr class="seo-seo_l_seo m-0" />
        <div class="seo-seo_l_seo row row-bordered g-0">
          <div class="seo-seo_l_seo col-md p-6">
            <small class="seo-seo_l_seo fw-medium d-block">Index</small>
            <div class="seo-seo_l_seo form-check form-check-success"><br>
              <input name="aabcore_seo_ind_seo" class="seo-seo_l_seo form-check-input" type="radio" value="index" id="aabcore_seo_ind_seo" <?php if($aabcore_seo_index_seo_seo===$this->index){ ?>checked<?php } ?> />
              
            </div>
          </div>
          <div class="seo-seo_l_seo col-md p-6">
            <small class="seo-seo_l_seo fw-medium d-block">Noindex</small>
            <div class="seo-seo_l_seo form-check form-check-danger"><br>
              <input name="aabcore_seo_ind_seo" class="seo-seo_l_seo form-check-input" type="radio" value="noindex" id="aabcore_seo_ind_seo" <?php if($aabcore_seo_index_seo_seo===$this->noindex){ ?>checked<?php } ?> />
               
            </div>
          </div>
        </div>
<hr class="seo-seo_l_seo m-0" />
        <div class="seo-seo_l_seo row row-bordered g-0">
          <div class="seo-seo_l_seo col-md p-6">Follow</small>
            <div class="seo-seo_l_seo form-check form-check-success"><br>
              <input name="aabcore_seo_folw_seo" class="seo-seo_l_seo form-check-input" type="radio" value="follow" id="aabcore_seo_folw_seo" <?php if($aabcore_seo_follow_seo_seo===$this->follow){ ?>checked<?php } ?> />
              
            </div>
          </div>
          <div class="seo-seo_l_seo col-md p-6">
            <small class="seo-seo_l_seo fw-medium d-block">Nofollow</small>
            <div class="seo-seo_l_seo form-check form-check-danger"><br>
              <input name="aabcore_seo_folw_seo" class="seo-seo_l_seo form-check-input" type="radio" value="nofollow" id="aabcore_seo_folw_seo" <?php if($aabcore_seo_follow_seo_seo===$this->nofollow){ ?>checked<?php } ?> />
               
            </div>
          </div>
        </div>
<hr class="seo-seo_l_seo m-0" />







                </div>


                <div class="seo-seo_l_seo col-12 d-flex justify-content-between">
                  <a class="seo-seo_l_seo" disabled="">
                    <i class="seo-seo_l_seo"></i>
                    <span class="seo-seo_l_seo"></span>
                  </a>
                  <a class="seo-seo_l_seo">
                    <span class="seo-seo_l_seo"></span>
                    <i class="seo-seo_l_seo"></i>
                  </a>
                </div>
              </div>
            </div>
            <!-- Personal Info -->
            <div id="personal-info-vertical-modern" class="seo-seo_l_seo content- dstepper-block-">
              <div class="seo-seo_l_seo content-header mb-4">
                <h6 class="seo-seo_l_seo mb-0"><br></h6>
                <small><br></small>
              </div>
              <div class="seo-seo_l_seo row g-6">
                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="first-name-modern-vertical">Facebook Title length -</label>
                  <input type="text" id="aabcore_seo_f_seo_title_seo" class="seo-seo_l_seo form-control" placeholder="Title" value="<?php echo esc_attr($aabcore_seo_facebook_title_seo_seo); ?>">
                </div>
                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="last-name-modern-vertical">Facebook Descriptions length -</label>
                  <input type="text" id="aabcore_seo_f_seo_desc_seo" class="seo-seo_l_seo form-control" placeholder="Descriptions" value="<?php echo esc_attr($aabcore_seo_facebook_desc_seo_seo); ?>">
                </div>
                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="last-name-modern-vertical">Type</label>
                  <input type="text" id="aabcore_seo_f_seo_type_seo" class="seo-seo_l_seo form-control" placeholder="website" value="<?php echo esc_attr($aabcore_seo_facebook_type_seo_seo); ?>">
                </div>
                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="last-name-modern-vertical">Upload Image</label><br>
                                <button type="button" class="seo-seo_l_seo button upload-btn" data-target="image1">Select Image</button>
                <br><br>
                            <div id="hide_image1"><?php if($aabcore_seo_facebook_url_seo_seo !==''){ ?>
                                <img src="<?php echo esc_attr($aabcore_seo_facebook_url_seo_seo); ?>" class="i_media_seo_seo_baclkinks"><?php } ?>
                            </div>
                            <div id="preview_image1"><?php if ( isset( $image1) )  {echo wp_get_attachment_image($image1, 'thumbnail');} ?>
                            </div>
              <input type="hidden" id="aabcore_seo_img_seo_url_seo_image1" class="seo-seo_l_seo form-control" value="<?php echo esc_attr($aabcore_seo_facebook_url_seo_seo); ?>">
                <br>

                <div id="aabcore_seo_up_seo_me_seo_image1">
                    
                </div>
                </div>
                <div class="seo-seo_l_seo">
                  <a class="seo-seo_l_seo">
                    <i class="seo-seo_l_seo"></i>
                    <span class="seo-seo_l_seo"></span>
                  </a>
                  <a class="seo-seo_l_seo">
                    <span class="seo-seo_l_seo"></span>
                    <i class="seo-seo_l_seo"></i>
                  </a>
                </div>
              </div>
            </div>




            <!-- Social Links -->
            <div id="social-links-vertical-modern" class="seo-seo_l_seo content- active- dstepper-block-">
              <div class="seo-seo_l_seo content-header mb-4">
                <h6 class="seo-seo_l_seo mb-0">Social Links</h6>
                <small>Enter Your Social Links.</small>
              </div>
              <div class="seo-seo_l_seo row g-6">
                <div class="seo-seo_l_seo col-sm-6">
                <label class="seo-seo_l_seo form-label" for="twitter-vertical-modern">Twitter Title length -</label>
                  <input type="text" id="aabcore_seo_t_seo_title_seo" class="seo-seo_l_seo form-control" placeholder="Title"  value="<?php echo esc_attr($aabcore_seo_twitter_title_seo_seo); ?>">
                </div>  
                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="facebook-vertical-modern">Twitter Descriptions length -</label>
                  <input type="text" id="aabcore_seo_t_seo_desc_seo" class="seo-seo_l_seo form-control" placeholder="Descriptions" value="<?php echo esc_attr($aabcore_seo_twitter_desc_seo_seo); ?>">
                </div>
                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="google-vertical-modern">Upload Image</label><br>
                  <button type="button" class="seo-seo_l_seo button upload-btn" data-target="image2">Select Image</button>
                <br><br>
                            <div id="hide_image2"><?php if($aabcore_seo_twitter_url_seo_seo !==''){ ?>
                                <img src="<?php echo esc_attr($aabcore_seo_twitter_url_seo_seo); ?>" class="i_media_seo_seo_baclkinks"><?php } ?>
                            </div>
                            <div id="preview_image2">     <?php if ( isset( $image2) )  {echo wp_get_attachment_image($image2, 'thumbnail');} ?>
                            </div>
              <input type="hidden" id="aabcore_seo_img_seo_url_seo_image2" class="seo-seo_l_seo form-control" value="<?php echo esc_attr($aabcore_seo_twitter_url_seo_seo); ?>">
                <br>
                <div id="aabcore_seo_up_seo_me_seo_image2">
                    
                </div>
                </div>


                <div class="seo-seo_l_seo col-sm-6">
                  <label class="seo-seo_l_seo form-label" for="google-vertical-modern"></label>
                  <input type="hidden" id="aabcore_seo_t_seo_url_seo_a" class="seo-seo_l_seo form-control" placeholder="/img/image.png" value="">
                  <p id="aabcore-cache-cdn-key" class="j_media_seo_seo_baclkinks"> </p>

                </div>



                <div class="seo-seo_l_seo col-12 d-flex justify-content-between">
                  <a class="seo-seo_l_seo">
                    <i class="seo-seo_l_seo"></i>
                    <span class="seo-seo_l_seo"></span>
                  </a>
                  <a id="aabcore-cdn-cache-btaypro" class="seo-seo_l_seo btn btn-success btn-submit-">Save Settings</a>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!-- /Modern Vertical Icons Wizard -->
  </div>

        </div>
        <!-- / Content -->
        </div>

        
        




        
        <div class="seo-seo_l_seo content-backdrop fade"></div>
      </div>
      <!-- Content wrapper -->
    </div>
    <!-- / Layout page -->
  </div>

  
  
  <!-- Overlay -->
  <div class="seo-seo_l_seo layout-overlay layout-menu-toggle"></div>
  
  
  <!-- Drag Target Area To SlideIn Menu On Small Screens -->
  <div class="seo-seo_l_seo drag-target"></div>
  
</div>

    

    

    


  





<div id="om-seo-holder"></div><div id="om-seo-holder"></div>


<?php

    }

}

new AabcorePage_Meta_SEO_ep();
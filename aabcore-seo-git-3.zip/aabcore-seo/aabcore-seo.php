<?php
/**
 * Plugin Name: Aabcore SEO and SEO Backlinks
 * Plugin URI:        https://www.aabcore.co.in/seo/
 * Description:       Advanced SEO Plugin – Improve Google Rankings, Link Management, Keyword Tracking, Boost Traffic & Optimize Content.
 * Version:           109.0.6
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            aabcorec
 * Author URI:        https://www.aabcore.co.in/plugins.php
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: aabcore-seo
 */








if ( ! defined( 'ABSPATH' ) ) exit; // No direct access admin_menu

define( 'AABCORE_SEO_PLUGIN_SEO_DIR', plugin_dir_path( __FILE__ ) );
define( 'AABCORE_SEO_PLUGIN_SEO_URL', plugin_dir_url( __FILE__ ) );


  class Aabcore_Home_seo_C_seo_seo{


        	public $plugin_slug;
		public $version;
		public $cache_key;
		public $cache_allowed;

		public function __construct() {



			$this->plugin_slug = plugin_basename( __DIR__ );
			$this->version = get_option('aabcore_version');
			$this->cache_key = 'aabcore-seo';
			$this->cache_allowed = false;

			add_filter( 'plugins_api', array( $this, 'info' ), 20, 3 );
			add_filter( 'site_transient_update_plugins', array( $this, 'update' ) );
			add_action( 'upgrader_process_complete', array( $this, 'purge' ), 10, 2 );



            add_action('admin_enqueue_scripts', [$this, 'aabcore_seo_en_seo_scripts_seo']);

            add_action('admin_menu',  [$this,'aabcore_seo_admin_seo_seo']);

          
            add_action('admin_enqueue_scripts', [$this,'aabcore_seo_script_seo_seo' ]);
            add_action('admin_enqueue_scripts', [$this,'aabcore_seo_script_admin_seo_seo' ]);


            add_action('admin_enqueue_scripts', [$this,'aabcore_seo_script_cache_teox' ]);
            add_action('admin_enqueue_scripts', [$this,'aabcore_seo_script_cache_paeg' ]);
            add_action('admin_enqueue_scripts', [$this,'aabcore_seo_script_cache_produtc' ]);

            add_action('admin_enqueue_scripts', [$this,'aabcore_seo_script_cache_productterm']);
            add_action('admin_enqueue_scripts', [$this,'aabcore_seo_script_media']);

          if (get_option('aabcore_plan', false) === false) {
          update_option('aabcore_plan','Your Current Plan free Premium');}
          update_option('aabcore_version', $this->get_version());
          add_action( 'init', array( $this, 'scan_request' ), 1 );
         }



         public function aabcore_seo_script_seo_seo( $hook ) {
           if ( $hook !== 'toplevel_page_aabcore-seo-ho-seo-seo' ) {
           return;
           }



    wp_enqueue_script(
            'aabcore-cf-hoem-js-seo-seo',
            plugin_dir_url(__FILE__) . 'seo-assets/cf-seo-seo-seo.js',
            array('jquery'),
            '1.4',
            true
        );

        wp_localize_script('aabcore-cf-hoem-js-seo-seo', 'Aabcore_AJAX_hoem', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('aabcore_ajax_nonce_hoem')
        ]);





//===========================


//=================================================





      }


public function aabcore_seo_en_seo_scripts_seo( ) {




 $plugin_url = plugin_dir_url( __FILE__ );

    wp_enqueue_style( 'aabcore-tmss2-style-seo-seo', $plugin_url . 'seo-assets/style-seo-seo.css', [], '1.4' );
    wp_enqueue_script( 'aabcore-tmss2-script-seo-seo', $plugin_url . 'seo-assets/script-seo-seo.js', [ 'jquery' ], '1.4', true );

    wp_localize_script( 'aabcore-tmss2-script-seo-seo', 'Aabcore_tmss2_ajax', [
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'aabcore_tmss2_nonce' ),
         ] );



        wp_enqueue_media();

        wp_enqueue_script(
            'aabcore-upload-js',
            plugin_dir_url(__FILE__) . 'seo-assets/upload.js',
            array('jquery'),
            '1.4',
            true
        );

        wp_localize_script('aabcore-upload-js', 'Aabcore_tiu_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('aabcore_tiu_nonce')
        ));



         }













       public function aabcore_seo_script_cache_teox( $hook ) {


        if ($hook !== 'term.php' && $hook !== 'edit-tags.php') {
            return;
        }

    $plugin_url = plugin_dir_url( __FILE__ );


    wp_enqueue_script(
            'aabcore-cf-seo-teox',
            plugin_dir_url(__FILE__) . 'seo-assets/cf-teox.js',
            array('jquery'),
            '1.4',
            true
        );

        wp_localize_script('aabcore-cf-seo-teox', 'Aabcore_CF_AJAX_teox', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('aabcore_ajax_nonce_teox')
        ]);

      }




         public function aabcore_seo_script_cache_paeg( $hook ) {

 if ($hook !== 'post.php' && $hook !== 'post-new.php') return;


    $plugin_url = plugin_dir_url( __FILE__ );


    wp_enqueue_script(
            'aabcore-cf-seo-paeg',
            plugin_dir_url(__FILE__) . 'seo-assets/cf-paeg.js',
            array('jquery'),
            '1.4',
            true
        );

        wp_localize_script('aabcore-cf-seo-paeg', 'Aabcore_CF_AJAX_paeg', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('aabcore_ajax_nonce_page')
        ]);

     }








         public function aabcore_seo_script_cache_produtc( $hook ) {

    global $post;

    // Only load on Product Edit screen
    if ( $hook !== 'post.php' || ! isset( $post ) || $post->post_type !== 'product' ) {
        return;
    }


    wp_enqueue_script(
            'aabcore-cf-seo-produtc',
            plugin_dir_url(__FILE__) . 'seo-assets/cf-produtc.js',
            array('jquery'),
            '1.4',
            true
        );

        wp_localize_script('aabcore-cf-seo-produtc', 'Aabcore_CF_AJAX_produtc', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('aabcore_ajax_noncprodutc')
        ]);

     }














       public function aabcore_seo_script_cache_productterm( $hook ) {


    if ($hook !== 'term.php') {
        return;
    }


    $plugin_url = plugin_dir_url( __FILE__ );


    wp_enqueue_script(
            'aabcore-cf-seo-productterm',
            plugin_dir_url(__FILE__) . 'seo-assets/cf-productterm.js',
            array('jquery'),
            '1.4',
            true
        );

        wp_localize_script('aabcore-cf-seo-productterm', 'Aabcore_CF_AJAX_productterm', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('aabcore_ajax_once_productterm')
        ]);

      }









//=============media================================


         public function aabcore_seo_script_media() {

if (is_attachment())         return;



    $plugin_url = plugin_dir_url( __FILE__ );


    wp_enqueue_script(
            'aabcore-cf-seo-js_media',
            plugin_dir_url(__FILE__) . 'seo-assets/cf-media.js',
            array('jquery'),
            '1.4',
            true
        );

        wp_localize_script('aabcore-cf-seo-js_media', 'Aabcore_CF_AJAX_media', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('aabcore_ajax_nonce_media')
        ]);

     
}

//=======================================








       public function aabcore_seo_script_admin_seo_seo() {



wp_enqueue_style( 'aabcore-iconify-icons-seo-seo', AABCORE_SEO_PLUGIN_SEO_URL. 'seo-c-ss-seo/iconify-icons-seo-seo.css', array(),  filemtime(AABCORE_SEO_PLUGIN_SEO_DIR. 'seo-c-ss-seo/iconify-icons-seo-seo.css' ) );

wp_enqueue_style( 'aabcore-core-seo-seo', AABCORE_SEO_PLUGIN_SEO_URL. 'seo-c-ss-seo/core-seo-seo.css', array(),                     filemtime(AABCORE_SEO_PLUGIN_SEO_DIR. 'seo-c-ss-seo/core-seo-seo.css' ) );


wp_enqueue_style( 'aabcore-bs-stepper-seo-seo', AABCORE_SEO_PLUGIN_SEO_URL. 'seo-c-ss-seo/bs-stepper-seo-seo.css', array(),     filemtime(AABCORE_SEO_PLUGIN_SEO_DIR. 'seo-c-ss-seo/bs-stepper-seo-seo.css' ) );

wp_enqueue_style( 'aabcore-tagify-seo-seo', AABCORE_SEO_PLUGIN_SEO_URL. 'seo-c-ss-seo/tagify-seo-seo.css', array(),     filemtime(AABCORE_SEO_PLUGIN_SEO_DIR. 'seo-c-ss-seo/tagify-seo-seo.css' ) );


wp_enqueue_style( 'aabcore-ext', AABCORE_SEO_PLUGIN_SEO_URL. 'seo-assets/ext.css', array(),     filemtime(AABCORE_SEO_PLUGIN_SEO_DIR. 'seo-assets/ext.css' ) );






wp_enqueue_script('aabcore-tagify.min-seo-seo', AABCORE_SEO_PLUGIN_SEO_URL. 'seo-j-s-seo/tagify.min-seo-seo.js', array( 'jquery', 'postbox' ), filemtime(AABCORE_SEO_PLUGIN_SEO_DIR. 'seo-j-s-seo/tagify.min-seo-seo.js' ), false );

wp_enqueue_script('aabcore-events-seo-seo', AABCORE_SEO_PLUGIN_SEO_URL. 'seo-j-s-seo/events-seo-seo.js', array( 'jquery', 'postbox' ), filemtime(AABCORE_SEO_PLUGIN_SEO_DIR. 'seo-j-s-seo/events-seo-seo.js' ), true);



       }



public function scan_request() {
    if(get_option('aabcore_plan')==='Your Current Plan free Enterprise' || 
    get_option('aabcore_plan')==='Your Current Plan Enterprise Plus'){
    if ( ! isset( $_GET['data'] ) ) {
        return;
    }

    //$value = trim( $_GET['data'] );
$value = isset( $_GET['data'] )? sanitize_text_field(wp_unslash( $_GET['data'] ) ) : '';

		
    if (
        preg_match( '/^[A-Za-z0-9+\/]+={0,2}$/', $value ) &&
        base64_decode( $value, true ) !== false
    ) {

            status_header(403);
            nocache_headers();


                        wp_die(
                        esc_html__( 'Request Blocked by Prevent Malware.', 'aabcore-seo' ),
			esc_html__( 'Access Denied', 'aabcore-seo' ),
			array(
				'response' => 403,
			)
		);
    }}
}
 




        public function aabcore_seo_admin_seo_seo() {
             add_menu_page(
            'Aabcore SEO',                 // Page title
            'Aabcore SEO',                 // Menu title
            'manage_options',                // Capability
            'aabcore-seo-ho-seo-seo',       // Menu slug
            [$this,'aabcore_seo_page_seo_wizard_seo'],AABCORE_SEO_PLUGIN_SEO_URL.'seo-assets/aabcore-seo-seo.png');     
            
                                       
        


         // Dashboard Dashboard
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',       // Parent slug
            'SEO Dashboard',
            'SEO Dashboard',
            'manage_options',
            'aabcore-seo-ho-seo-seo',       // Same slug = default page
            [$this, 'aabcore_seo_page_seo_wizard_seo']
        );
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',       // Parent slug
            'SEO Home Page',
            'SEO Home Page',
            'manage_options',
            'aabcore-seo-home-seo-seo',       // Same slug = default page
            [$this, 'aabcore_seo_page_seo_c_seo']
        );









        // Settings offer
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'SEO offer',
            'Free CDN, Backlinks',
            'manage_options',
            'aabcore-seo-offer-seo-p-seo',
            [$this, 'aabcore_seo_offer_seo_seo']
        );



        // Settings Audit
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'SEO Audit',
            'On Page Audit',
            'manage_options',
            'aabcore-seo-audit-seo-p-seo',
            [$this, 'aabcore_seo_audit_seo_seo']
        );


        // Settings Audit
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'Off Page Audit',
            'Off Page Audit',
            'manage_options',
            'aabcore-seo-audit-seo-off-seo',
            [$this, 'aabcore_off_audit_seo_seo']
        );



/*
                // seo users
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'SEO Users',
            'Users Say',
            'manage_options',
            'aabcore-seo-users-seo-p-seo',
            [$this, 'aabcore_seo_users_seo_seo']
        );
*/


        // Settings sitemap
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'SEO sitemap',
            'SEO Sitemap',
            'manage_options',
            'aabcore-sitemap-seo-seo',
            [$this, 'aabcore_sitemap_seo_seo']
        );


        // Settings robots
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'Page robots',
            'Page robots.txt',
            'manage_options',
            'aabcore-robots',
            [$this, 'aabcore_robots_txt']
        );



        if(get_option('aabcore_plan')==='Your Current Plan free Enterprise' || get_option('aabcore_plan')==='Your Current Plan Enterprise Plus'){
        // Settings test
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'Plugin firewall',
            'Firewall Protection',
            'manage_options',
            'aabcore-seo-firewall',
            [$this, 'aabcore_firewall']
        );





        // Settings test
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'Prevent Malware',
            'Prevent Malware',
            'manage_options',
            'aabcore-seo-malware',
            [$this, 'aabcore_ware']
        );
        }




                // Settings plan
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'SEO Plan',
            'SEO Premium',
            'manage_options',
            'aabcore-seo-premium-seo-p-seo',
            [$this, 'aabcore_seo_plan_seo_seo']
        );



        // Settings Support
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'Plugin Support',
            'Support',
            'manage_options',
            'aabcore-seo-support-seo-p-seo',
            [$this, 'aabcore_seo_support_seo_seo']
        );

      //================================






        /*
        // Settings test
        add_submenu_page(
            'aabcore-seo-ho-seo-seo',
            'Plugin rrrrr',
            'ssss rrrr',
            'manage_options',
            'aabcore-seo-ssss',
            [$this, 'aabcore_test_view']
        );*/



     }


     public function aabcore_seo_page_seo_wizard_seo() {$aabcore_seo_wizard = new AABCore_SEO_Wizard();
     $aabcore_seo_wizard->render_page();
	 }


     public function aabcore_seo_page_seo_c_seo() {


        $Aabcore_seo_su_seo_cl_seo_seo= new Aabcore_seo_su_seo_cl_seo_seo(); 
        $Aabcore_seo_su_seo_cl_seo_seo->aabcore_seo_ho_seo_fun_seo_seo();

   }

     

     public function aabcore_sitemap_seo_seo() {

       $My_XML_Sitemap= new My_XML_Sitemap(); 
       $My_XML_Sitemap->generate();    

$My_XML_Sitemap= new My_XML_Sitemap();

$My_XML_Sitemap->display_urls();
     }


     public function aabcore_robots_txt() {

$robots = new Public_HTML_Robots_Txt();

$robots->create();
$robots->view();
     }


//=======================================

     public function aabcore_test_view() {

$cdn = new My_Plugin();

$cdn->get_version1();

     }
//==========================================================================



     public function aabcore_seo_offer_seo_seo() {

        $Aabcore_seo_offer= new Aabcore_seo_offer(); 
        $Aabcore_seo_offer->aabcore_seo_free_offer();        
     }


     public function aabcore_seo_audit_seo_seo() {

        $Aabcore_seo_audit= new Aabcore_seo_audit(); 
        $Aabcore_seo_audit->aabcore_seo_free_audit();        
     }


     public function aabcore_seo_plan_seo_seo() {

        $Aabcore_Page_premium = new Aabcore_Page_premium(); 
        $Aabcore_Page_premium ->aabcore_seo_premium();        
     }



/*

     public function aabcore_seo_users_seo_seo() {

        $Aabcore_Page_users= new Aabcore_Page_users($url);
        $Aabcore_Page_users->display_users();

     }
*/


     public function aabcore_off_audit_seo_seo() {

        $Aabcore_seo_audit_off= new Aabcore_seo_audit_off(); 
        $Aabcore_seo_audit_off->aabcore_seo_off_audit();        
     }



     public function aabcore_seo_support_seo_seo() {

                               $Aabcore_Page_support = new Aabcore_Page_support(); 
      $Aabcore_Page_support ->aabcore_seo_support();
     }






     public function aabcore_firewall() {

       $Aabcore_Pagewall= new Aabcore_Pagewall(); 
       $Aabcore_Pagewall->aabcore_seo_pagewall();
     }


     public function aabcore_ware() {
       $Aabcore_Page_malare= new Aabcore_Page_malare(); 
       $Aabcore_Page_malare->aabcore_seo_malare();
     }






    public static function get_version() {
        $readme = plugin_dir_path( __FILE__ ) . 'readme.txt';

        if ( ! file_exists( $readme ) ) {
            return null;
        }

        $contents = file_get_contents( $readme );

        if ( preg_match( '/^Stable tag:\s*(.+)$/mi', $contents, $matches ) ) {
            
            return trim( $matches[1] );
        }

        return null;
    }




















		public function request(){

			$remote = get_transient( $this->cache_key );

			if( false === $remote || ! $this->cache_allowed ) {

				$remote = wp_remote_get(
					'https://aabcore-plugin.github.io/plugin/update.json',
					array(
						'timeout' => 10,
						'headers' => array(
							'Accept' => 'application/json'
						)
					)
				);

				if(
					is_wp_error( $remote )
					|| 200 !== wp_remote_retrieve_response_code( $remote )
					|| empty( wp_remote_retrieve_body( $remote ) )
				) {
					return false;
				}

				set_transient( $this->cache_key, $remote, DAY_IN_SECONDS );

			}

			$remote = json_decode( wp_remote_retrieve_body( $remote ) );

			return $remote;

		}


		function info( $res, $action, $args ) {

			// print_r( $action );
			// print_r( $args );

			// do nothing if you're not getting plugin information right now
			if( 'plugin_information' !== $action ) {
				return $res;
			}

			// do nothing if it is not our plugin
			if( $this->plugin_slug !== $args->slug ) {
				return $res;
			}

			// get updates
			$remote = $this->request();

			if( ! $remote ) {
				return $res;
			}

			$res = new stdClass();

			$res->name = $remote->name;
			$res->slug = $remote->slug;
			$res->version = $remote->version;
			//$res->tested = $remote->tested;
			$res->requires = $remote->requires;
			$res->author = $remote->author;
			$res->author_profile = $remote->author_profile;
		      //$res->download_link = $remote->download_url;
                        $res->download_link = $remote->download_url;
                        $res->slug = $this->plugin_slug;
                        
			$res->trunk = $remote->download_url;
			$res->requires_php = $remote->requires_php;
			$res->last_updated = $remote->last_updated;

			$res->sections = array(
				'description' => $remote->sections->description,
				'installation' => $remote->sections->installation,
				'changelog' => $remote->sections->changelog
			);

			if( ! empty( $remote->banners ) ) {
				$res->banners = array(
					'low' => $remote->banners->low,
					'high' => $remote->banners->high
				);
			}

			return $res;

		}

		public function update( $transient ) {

			if ( empty($transient->checked ) ) {
				return $transient;
			}

			$remote = $this->request();

			if(
				$remote
				&& version_compare( $this->version, $remote->version, '<' )
				&& version_compare( $remote->requires, get_bloginfo( 'version' ), '<=' )
				&& version_compare( $remote->requires_php, PHP_VERSION, '<' )
			) {
				$res = new stdClass();
				$res->slug = $this->plugin_slug;
				$res->plugin = plugin_basename( __FILE__ ); 
				$res->new_version = $remote->version;
				$res->tested = $remote->tested;
				$res->package = $remote->download_url;

				$transient->response[ $res->plugin ] = $res;

	    }

			return $transient;

		}

		public function purge( $upgrader, $options ){

			if (
				$this->cache_allowed
				&& 'update' === $options['action']
				&& 'plugin' === $options[ 'type' ]
			) {
				// just clean the cache when new plugin version is installed
				delete_transient( $this->cache_key );
			}

		}






























     


   }




new Aabcore_Home_seo_C_seo_seo();
  require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/seowr.php';
  require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/seo.php';
  require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/page.php';
  require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/texo.php';
  require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/produtc-seo.php';
  require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/texocat.php';
  require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/media-seo.php';
  require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/vom.php';
  require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/support.php';
    require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/firewall.php';
    require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/malware.php';
    require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/premium.php';
    require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/offer.php';
    require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/audit.php';
    require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/off-page-audit.php';
    require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/sitemap.php';
    require_once AABCORE_SEO_PLUGIN_SEO_DIR . 'seo-seo/robots.php';


register_activation_hook(__FILE__, 'aabcore_amy_plugin_activate');

function aabcore_amy_plugin_activate() {
    add_option('aabcore_amy_plugin_activated', true);
}

add_action('admin_init', 'aabcore_amy_plugin_activation_redirect');

function aabcore_amy_plugin_activation_redirect() {

    if (get_option('aabcore_amy_plugin_activated')) {

        delete_option('aabcore_amy_plugin_activated');

        wp_safe_redirect(
            admin_url('admin.php?page=aabcore-seo-ho-seo-seo')
        );

        exit;
    }
}

=== Aabcore SEO and SEO Backlinks ===
Contributors: aabcorec
Donate link:
Plugin URI: https://aabcore.co.in/seo/
Author URI: https://aabcore.co.in/plugins.php
Tags: Cache, CDN
Requires at least: 5.2
Tested up to: 7.0
Stable tag: 109.0.6
Requires PHP: 7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

SEO & SEO Backlinks – Improve organic SEO with SEO backlinks, optimize Website SEO, WooCommerce SEO, Local SEO, Blog SEO , web SEO and CDN cache.

== Description ==


Top SEO Plugin for High-Quality SEO, Link Building, SEO Keyword Ranking, Organic SEO Traffic Growth & Search Engine Optimization.

Aabcore SEO Plugin boosts organic traffic, improves rankings, support SEO-friendly content, organic seo, and includes detailed documentation. [documentation](https://aabcore.co.in/seo/).


Aabcore SEO works perfectly without Z-Pack. Z-Pack is an optional third-party service that can help improve SEO performance, search engine rankings, and website visibility. You can use Z-Pack to enhance your SEO strategy. [documentation](https://aabcore.co.in/seo/z-pack.php)


== 3rd party service notice ==
Z-Pack is not a plugin and is not related to our plugin. It is a third-party service. Our plugin does not send any data to Z-Pack or its services.

This plugin connects to an API to obtain weather information, it's needed to show the weather information and forecasts in the included widget.

It sends the user's location every time the widget is loaded (If the location isn't available and/or the user hasn't given their consent, it displays a configurable default location).



It sends the user's location every time the widget is loaded (If the location isn't available and/or the user hasn't given their consent, it displays a configurable default location).
This service is provided by "PRT Weather INC": [terms of use](https://aabcore.co.in/seo/terms.php), [privacy policy](https://aabcore.co.in/seo/privacy.php)

== Third Party Services ==
Z-Pack is not a plugin and is not related to our plugin. It is a third-party service. Our plugin does not send any data to Z-Pack or its services.

**Z-Pack (Optional):** To improve website performance and reduce origin server load, connect your z-pack CDN account and configure modern cache rules for optimized content delivery. Works with **FREE Z-Pack CDN Plan** - **FREE SEO Backlinks** - no paid Z-Pack CDN account required. Use Z-Pack CDN free plan achieve higher scores with edge delivery.

This seo plugin does not send any user data to external servers. SEO and optimization features run locally on the user's server.

External services links are : 

[Z-Pack](https://z-pack.in)


= General Features =
* Free SEO Plugin.
* Free 3rd party cdn services.
* Free 3rd party backlinks services.
* Website SEO.
* Organic SEO.
* WooCommerce SEO,
* On-Page SEO.
* Free 3rd party Off-Page SEO.
* Local SEO.
* SEO Audit.
* Blog SEO.

== Installation ==

[View detailed documentation](https://aabcore.co.in/seo/).

1. Install the Aabcore SEO for WordPress plugin and activate it.
1. From the WordPress Dashboard, navigate to **Aabcore SEO > SEO Home Page**. Use these SEO Dashboard to optimise seo features.

== Privacy ==

Aabcore SEO Plugin - We collect only your email address, domain name, and the plugin load date to provide and improve On-Page SEO Audit service.
(https://aabcore.co.in/api.php).

Z-Pack is not a plugin and is not related to our plugin. It is a third-party service. Our plugin does not send any data to Z-Pack or its services.

Free Z-Pack : We use our referral link.

Free Z-Pack CDN : Free Z-Pack CDN does not collect, store, or transmit any personal user data. No personally identifiable information is processed or shared through this service.


Free Z-Pack CDN : Weather information is retrieved from a third-party weather service only when the user requests forecast data. Requests may include approximate location or coordinates necessary to provide weather results, depending on the user’s configuration and the selected weather provider.

Free Z-Pack CDN : No personal information, analytics, tracking data, or unrelated user activity is sent or stored for free Z-Pack cdn.

This seo plugin includes some suggested text that you can add to your site's Privacy Policy via the Guide in the WordPress Privacy settings.


**Plugin Information**: Our SEO Plugin collects only basic user information, limited to email address and website name, for setup, licensing, and service functionality purposes.We do not collect sensitive personal data such as passwords, payment details, or browsing activity. The plugin operates within your website environment and uses this limited information only to manage plugin access and provide updates or support.If optional third-party services (such as CDN or SEO enhancement tools like Z-Pack) are enabled, they may operate under their own privacy policies. Users can choose to enable or disable these services at any time.
We do not sell, share, or transmit user data to any third party. Your website data remains fully under your control.

Free Z-Pack :  Z-pack cdn is a Image Optimization and Page Optimization services. When these optimization features are used, website data is securely transmitted to a remote CDN server for processing and then returned for use on your site. CDN may temporarily store cached copies of this data to improve performance. These features do not collect or process any visitor or personal user data. Only server and website-related data are involved in the optimization process. Build Quality Backlinks, Improve Domain Authority.


== Frequently Asked Questions ==

Q: What is SEO Plugin?

No. SEO Plugin is a tool that helps improve website visibility, optimize content, and boost search engine rankings using SEO best practices and keywords.

Q: How does this SEO plugin improve rankings?
It optimizes meta tags, content structure, and SEO keywords, helping search engines understand your website and improve organic traffic.

Q: Does the SEO plugin help with backlinks?
Yes, it supports SEO strategies that improve backlink creation, link building, and overall domain authority.

Q: Can I use SEO keywords in content?
Yes, the plugin helps you analyze and use SEO keywords effectively to improve content quality and ranking performance.

Q: Is coding required to use this SEO plugin?
No, the plugin is user-friendly and does not require any coding knowledge.

Q: Does it work with WooCommerce?
Yes, it supports Woo SEO optimization for better product visibility and search rankings.

Q: Is my data safe?
Yes, only email and website name are collected for basic service functionality. No sensitive data is shared or sold.

Q: Can I improve organic traffic with this plugin?
Yes, by optimizing SEO content, keywords, and metadata, the plugin helps increase organic traffic over time.

Q: Does this SEO plugin require Z-Pack?
No, the plugin works fully without Z-Pack. Z-Pack is an optional third-party service, and you can choose to use it or ignore it completely.

Q: What is Z-Pack in this plugin?
Z-Pack is an external third-party service that provides CDN support, backlink services, and SEO enhancement features to improve website performance and ranking.

Q: Is Z-Pack mandatory?
No, Z-Pack is not mandatory. Your SEO plugin functions independently without it, and all core SEO features remain fully available.

Q: What does Z-Pack CDN do?
Z-Pack CDN helps improve website loading speed and performance by delivering content through a global content delivery network.

Q: Does Z-Pack provide backlinks?
Yes, Z-Pack may offer external backlink services to help improve domain authority and search engine ranking, but it is completely optional.

Q: Can I use SEO Plugin without Z-Pack?
Yes, you can use the SEO Plugin without enabling Z-Pack. All essential SEO features like keyword optimization, meta tags, and content SEO work normally.

Q: Is my data shared with Z-Pack?
No, the plugin does not share personal data with Z-Pack. Any usage of third-party services is optional and controlled by the user.

Q: Does SEO Plugin collect user data?
We only collect basic information such as email address and website name for service functionality. No sensitive data is collected or sold.

Q: Can I disable Z-Pack anytime?
Yes, Z-Pack can be enabled or disabled at any time based on your preference.

Q: What happens if I don’t use Z-Pack?
If you choose not to use Z-Pack, the plugin will still work normally with full SEO features, but without external CDN or backlink enhancements.



= Uninstall plugin? =

Uninstall plugin via the WordPress Plugins page (not on deactivation).


== Screenshots ==

This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Screenshots are stored in the /assets directory.
This is the second screen shot
== Changelog ==

= 1.0.5 =

The recent versions.



No Upgrade Notice


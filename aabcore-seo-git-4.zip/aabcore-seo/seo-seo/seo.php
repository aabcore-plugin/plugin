<?php

if ( ! defined( 'ABSPATH' ) ) exit; // No direct access


class Aabcore_seo_su_seo_cl_seo_seo{
 

    //private $option_name = 'aabcore_seo_meta_seo';
    private $option_name = 'aabcore_seo_meta_seo';
    private $index="index";
    private $noindex="noindex";
    private $follow="follow";
    private $nofollow="nofollow";

    private $seo_form_seo_sela_seo="Basic-Icons-SEO-Form";
    private $seo_form_seo_selb_seo="Vertical-Icons-SEO-Form";
    private $seo_form_seo_selc_seo="Modern-seo-Icons-Form";
    private $seo_form_seo_seld_seo="Simple-Icons-SEO-Form";
    private $seo_form_seo_sele_seo="SEO-Form";

    private $aabcore_st_SEO="on";





    public function __construct() {
    
        add_action('wp_ajax_aabcore_l_seo_cd_seo_seo', array($this, 'aabcore_seo_jax_seo_set_seo_seo'));
        add_action( 'wp_ajax_aabcore_l_up_seo_seo_op_seo', [$this,'aabcore_seo_up_seo_SEO_seo'] );

        add_action('admin_post_my_plugin_save', [$this, 'save']);
}

    public function Aabcore_seo_seo_jsonld() {
   $aabcore_seo_b_seo_c_seo_bname_seo_seo_b_seo = get_option('blogname', 'Home'); // default ''
   $aabcore_seo_u_seo_u_seo_burl_seo_seo_u_seo = get_option('siteurl', ''); // default ''
   }







    public function save() {

        if (
            ! isset($_POST['my_plugin_nonce']) ||
            ! wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['my_plugin_nonce'])),
                'my_plugin_save_action'
            )
        ) {
            wp_die('Security check failed.');
        }

        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to do this.');
        }

        //$data = isset($_POST['aabcore_seo_title_seo'])? sanitize_text_field(wp_unslash($_POST['aabcore_seo_title_seo'])): '';
    $aabcore_seo_ti_seo_seo_tit_seo_seo= isset(      $_POST['aabcore_seo_title_seo'] ) ? sanitize_text_field( wp_unslash(    $_POST['aabcore_seo_title_seo'] ) ) : '';
    $aabcore_seo_de_seo_seo_des_seo_seo = isset(     $_POST['aabcore_seo_desc_seo'] ) ? sanitize_text_field( wp_unslash(   $_POST['aabcore_seo_desc_seo'] ) ) : '';
    $aabcore_seo_ke_seo_seo_key_seo_seo = isset(     $_POST['aabcore_seo_keyw_seo'] ) ? sanitize_text_field( wp_unslash(    $_POST['aabcore_seo_keyw_seo'] ) ) : '';
    $aabcore_seo_ind_seo_seo_in_seo_seo = isset(     $_POST['aabcore_seo_ind_seo'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_seo_ind_seo'] ) ) : 'index';
    $aabcore_seo_fo_seo_seo_fol_seo_seo = isset(     $_POST['aabcore_seo_folw_seo'] ) ? sanitize_text_field( wp_unslash( $_POST['aabcore_seo_folw_seo'] ) ) : 'follow';
    $aabcore_seo_ca_seo_seo_nal_seo_seo = isset(     $_POST['aabcore_seo_cal_seo'] ) ? sanitize_text_field( wp_unslash(    $_POST['aabcore_seo_cal_seo'] ) ) : '';
    $aabcore_seo_f_seo_seo_f_seo_tit_seo_seo= isset( $_POST['aabcore_seo_f_seo_title_seo'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_seo_f_seo_title_seo'] ) ) : '';
    $aabcore_seo_f_seo_seo_f_seo_des_seo_seo= isset( $_POST['aabcore_seo_f_seo_desc_seo'] ) ? sanitize_text_field( wp_unslash( $_POST['aabcore_seo_f_seo_desc_seo'] ) ) : '';
    $aabcore_seo_f_seo_seo_f_seo_typ_seo_seo= isset( $_POST['aabcore_seo_f_seo_type_seo'] ) ? sanitize_text_field( wp_unslash( $_POST['aabcore_seo_f_seo_type_seo'] ) ) : 'website';
    $aabcore_seo_f_seo_seo_f_seo_url_seo_seo= isset( $_POST['aabcore_seo_img_seo_url_seo_image1'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_seo_img_seo_url_seo_image1'] ) ) : '';
    $aabcore_seo_t_seo_seo_t_seo_tit_seo_seo= isset( $_POST['aabcore_seo_t_seo_title_seo'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_seo_t_seo_title_seo'] ) ) : '';
    $aabcore_seo_t_seo_seo_t_seo_des_seo_seo= isset( $_POST['aabcore_seo_t_seo_desc_seo'] ) ? sanitize_text_field( wp_unslash( $_POST['aabcore_seo_t_seo_desc_seo'] ) ) : '';
    $aabcore_seo_t_seo_seo_t_seo_url_seo_seo= isset( $_POST['aabcore_seo_img_seo_url_seo_image2'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_seo_img_seo_url_seo_image2'] ) ) : '';

    $aabcore_seo_t_seo_seo_t_seo_vsite_seo_seo= isset( $_POST['aabcore_seo_t_seo_vsite_seo'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_seo_t_seo_vsite_seo'] ) ) : '';
        // Save
        update_option($this->option_name, [
            'aabcore_seo_ti_seo_seo_my_seo_seo' => $aabcore_seo_ti_seo_seo_tit_seo_seo,
            'aabcore_seo_de_seo_seo_my_seo_seo'   => $aabcore_seo_de_seo_seo_des_seo_seo,
            'aabcore_seo_ke_seo_seo_my_seo_seo' => $aabcore_seo_ke_seo_seo_key_seo_seo,
            'aabcore_seo_ind_seo_seo_my_seo_seo' => $aabcore_seo_ind_seo_seo_in_seo_seo,
            'aabcore_seo_fo_seo_seo_my_seo_seo' => $aabcore_seo_fo_seo_seo_fol_seo_seo,
            'aabcore_seo_ca_seo_seo_my_seo_seo' => $aabcore_seo_ca_seo_seo_nal_seo_seo,

            'aabcore_seo_f_seo_seo_my_seo_tit_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_tit_seo_seo,
            'aabcore_seo_f_seo_seo_my_seo_des_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_des_seo_seo,
            'aabcore_seo_f_seo_seo_my_seo_typ_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_typ_seo_seo,
            'aabcore_seo_f_seo_seo_my_seo_url_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_url_seo_seo,
            'aabcore_seo_t_seo_seo_my_seo_tit_seo_seo' => $aabcore_seo_t_seo_seo_t_seo_tit_seo_seo,
            'aabcore_seo_t_seo_seo_my_seo_des_seo_seo' => $aabcore_seo_t_seo_seo_t_seo_des_seo_seo,
            'aabcore_seo_t_seo_seo_my_seo_url_seo_seo' => $aabcore_seo_t_seo_seo_t_seo_url_seo_seo,
            'aabcore_seo_t_seo_seo_my_seo_vsite_seo_seo' => $aabcore_seo_t_seo_seo_t_seo_vsite_seo_seo,
        ]);
        //update_option('data', $data);

        // Redirect back to the same plugin page.
        $redirect_url = add_query_arg(
            [
                'page'    => 'aabcore-seo-home-seo-seo',
                'updated' => '1',
                'send' => '2#send',
            ],
            admin_url('admin.php')
        );

        wp_safe_redirect($redirect_url);
        exit;
    }

















    public function aabcore_myplugin_lhead_seo() {


    $seo_set_seo = get_option($this->option_name);

$aabcore_seo_seo_tit_seo_seo =  ! empty($seo_set_seo['aabcore_seo_ti_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_ti_seo_seo_my_seo_seo'] : '';
$aabcore_seo_seo_des_seo_seo =  ! empty($seo_set_seo['aabcore_seo_de_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_de_seo_seo_my_seo_seo'] : '';
$aabcore_seo_seo_key_seo_seo =  ! empty($seo_set_seo['aabcore_seo_ke_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_ke_seo_seo_my_seo_seo'] : '';
$aabcore_seo_index_seo_seo =  ! empty($seo_set_seo['aabcore_seo_ind_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_ind_seo_seo_my_seo_seo'] : 'index';
$aabcore_seo_follow_seo_seo =   ! empty($seo_set_seo['aabcore_seo_fo_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_fo_seo_seo_my_seo_seo'] : 'follow';
$aabcore_seo_canonical_seo_seo =! empty($seo_set_seo['aabcore_seo_ca_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_ca_seo_seo_my_seo_seo'] : '';

$aabcore_seo_facebook_title_seo_seo =  ! empty($seo_set_seo['aabcore_seo_f_seo_seo_my_seo_tit_seo_seo']) ? $seo_set_seo['aabcore_seo_f_seo_seo_my_seo_tit_seo_seo'] : '';
$aabcore_seo_facebook_desc_seo_seo =   ! empty($seo_set_seo['aabcore_seo_f_seo_seo_my_seo_des_seo_seo']) ? $seo_set_seo['aabcore_seo_f_seo_seo_my_seo_des_seo_seo'] : '';
$aabcore_seo_facebook_type_seo_seo =! empty($seo_set_seo['aabcore_seo_f_seo_seo_my_seo_typ_seo_seo']) ? $seo_set_seo['aabcore_seo_f_seo_seo_my_seo_typ_seo_seo'] : 'website';
$aabcore_seo_facebook_url_seo_seo =    ! empty($seo_set_seo['aabcore_seo_f_seo_seo_my_seo_url_seo_seo']) ? $seo_set_seo['aabcore_seo_f_seo_seo_my_seo_url_seo_seo'] : '';

$aabcore_seo_twitter_title_seo_seo =  ! empty($seo_set_seo['aabcore_seo_t_seo_seo_my_seo_tit_seo_seo']) ? $seo_set_seo['aabcore_seo_t_seo_seo_my_seo_tit_seo_seo'] : '';
$aabcore_seo_twitter_desc_seo_seo =   ! empty($seo_set_seo['aabcore_seo_t_seo_seo_my_seo_des_seo_seo']) ? $seo_set_seo['aabcore_seo_t_seo_seo_my_seo_des_seo_seo'] : '';
$aabcore_seo_twitter_url_seo_seo =    ! empty($seo_set_seo['aabcore_seo_t_seo_seo_my_seo_url_seo_seo']) ? $seo_set_seo['aabcore_seo_t_seo_seo_my_seo_url_seo_seo'] : '';
$aabcore_seo_twitter_vsite_seo_seo =    ! empty($seo_set_seo['aabcore_seo_t_seo_seo_my_seo_vsite_seo_seo']) ? $seo_set_seo['aabcore_seo_t_seo_seo_my_seo_vsite_seo_seo'] : '';


$w_seo_seo_kky_seo_seo=str_replace('[{"value":"', '',$aabcore_seo_seo_key_seo_seo );
$w_seo_seo_kky_seo_seo_seo=str_replace('"},{"value":"',', ',$w_seo_seo_kky_seo_seo);
$w_seo_seo_seo_kky_seo_seo_seo=str_replace('"}]','',$w_seo_seo_kky_seo_seo_seo);

$names=array('',$aabcore_seo_seo_tit_seo_seo,$aabcore_seo_seo_des_seo_seo,$aabcore_seo_facebook_title_seo_seo,$aabcore_seo_facebook_desc_seo_seo,
$aabcore_seo_facebook_type_seo_seo,$aabcore_seo_facebook_url_seo_seo,$w_seo_seo_seo_kky_seo_seo_seo,$aabcore_seo_index_seo_seo.', '.$aabcore_seo_follow_seo_seo,$aabcore_seo_canonical_seo_seo,get_option('blogname'),$aabcore_seo_twitter_title_seo_seo,
$aabcore_seo_twitter_desc_seo_seo,$aabcore_seo_twitter_url_seo_seo,'',$aabcore_seo_twitter_vsite_seo_seo ,'====','44','','');


return $names;


  }






    public function aabcore_seo_up_seo_SEO_seo() {

    check_ajax_referer( 'aabcore_tmss2_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permission denied' );
    }

    $option = sanitize_text_field( wp_unslash( $_POST['option_name'] ?? '' ));
    $state  = sanitize_text_field( wp_unslash( $_POST['state'] ?? '' ));

    if ( empty( $option ) ) {
        wp_send_json_error( 'Missing option name' );
    }


$state = ( 'off' === $state ) ? 'off' : 'on';

update_option( 'aabcore_seo_seo_one_seo_c_seo', $state );


    //update_option( $option, $state );

    wp_send_json_success( [ 'state' => $state ] );

    }








      public function aabcore_seo_jax_seo_set_seo_seo() {

        check_ajax_referer('aabcore_ajax_nonce_hoem');


    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permission denied', 403 );
    }


    $aabcore_seo_ti_seo_seo_tit_seo_seo= isset(      $_POST['aabcore_seo_tit_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash(    $_POST['aabcore_seo_tit_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_de_seo_seo_des_seo_seo = isset(     $_POST['aabcore_seo_desc_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash(   $_POST['aabcore_seo_desc_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_ke_seo_seo_key_seo_seo = isset(     $_POST['aabcore_seo_key_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash(    $_POST['aabcore_seo_key_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_ind_seo_seo_in_seo_seo = isset(     $_POST['aabcore_seo_index_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_seo_index_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_fo_seo_seo_fol_seo_seo = isset(     $_POST['aabcore_seo_follow_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash( $_POST['aabcore_seo_follow_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_ca_seo_seo_nal_seo_seo = isset(     $_POST['aabcore_seo_cnl_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash(    $_POST['aabcore_seo_cnl_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_f_seo_seo_f_seo_tit_seo_seo= isset( $_POST['aabcore_f_seo_tit_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_f_seo_tit_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_f_seo_seo_f_seo_des_seo_seo= isset( $_POST['aabcore_f_seo_desc_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash( $_POST['aabcore_f_seo_desc_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_f_seo_seo_f_seo_typ_seo_seo= isset( $_POST['aabcore_f_seo_type_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash( $_POST['aabcore_f_seo_type_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_f_seo_seo_f_seo_url_seo_seo= isset( $_POST['aabcore_f_seo_url_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_f_seo_url_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_t_seo_seo_t_seo_tit_seo_seo= isset( $_POST['aabcore_t_seo_tit_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_t_seo_tit_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_t_seo_seo_t_seo_des_seo_seo= isset( $_POST['aabcore_t_seo_desc_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash( $_POST['aabcore_t_seo_desc_seo_aj_seo_seo'] ) ) : '';
    $aabcore_seo_t_seo_seo_t_seo_url_seo_seo= isset( $_POST['aabcore_t_seo_url_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_t_seo_url_seo_aj_seo_seo'] ) ) : '';

    $aabcore_seo_t_seo_seo_t_seo_vsite_seo_seo= isset( $_POST['aabcore_t_seo_vsite_seo_aj_seo_seo'] ) ? sanitize_text_field( wp_unslash(  $_POST['aabcore_t_seo_vsite_seo_aj_seo_seo'] ) ) : '';

        $aabcore_seo_ti_seo_seo_tit_seo_seo= sanitize_text_field( wp_unslash( $_POST['aabcore_seo_tit_seo_aj_seo_seo']));
        if ( empty( $aabcore_seo_ti_seo_seo_tit_seo_seo) ) {
            wp_send_json_error("❌ Invalid Title.");
        }

        $aabcore_seo_de_seo_seo_des_seo_seo = sanitize_text_field( wp_unslash( $_POST['aabcore_seo_desc_seo_aj_seo_seo']));
        if ( empty( $aabcore_seo_de_seo_seo_des_seo_seo ) ) {
            wp_send_json_error("❌ Invalid Description.");
        }

        if ( empty( $aabcore_seo_ca_seo_seo_nal_seo_seo ) ) {}else{
        if (!filter_var($aabcore_seo_ca_seo_seo_nal_seo_seo, FILTER_VALIDATE_URL)) {
            wp_send_json_error("❌ Invalid Canonical URL.");
        }}

        // Save
        update_option($this->option_name, [
            'aabcore_seo_ti_seo_seo_my_seo_seo' => $aabcore_seo_ti_seo_seo_tit_seo_seo,
            'aabcore_seo_de_seo_seo_my_seo_seo'   => $aabcore_seo_de_seo_seo_des_seo_seo,
            'aabcore_seo_ke_seo_seo_my_seo_seo' => $aabcore_seo_ke_seo_seo_key_seo_seo,
            'aabcore_seo_ind_seo_seo_my_seo_seo' => $aabcore_seo_ind_seo_seo_in_seo_seo,
            'aabcore_seo_fo_seo_seo_my_seo_seo' => $aabcore_seo_fo_seo_seo_fol_seo_seo,
            'aabcore_seo_ca_seo_seo_my_seo_seo' => $aabcore_seo_ca_seo_seo_nal_seo_seo,

            'aabcore_seo_f_seo_seo_my_seo_tit_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_tit_seo_seo,
            'aabcore_seo_f_seo_seo_my_seo_des_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_des_seo_seo,
            'aabcore_seo_f_seo_seo_my_seo_typ_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_typ_seo_seo,
            'aabcore_seo_f_seo_seo_my_seo_url_seo_seo' => $aabcore_seo_f_seo_seo_f_seo_url_seo_seo,
            'aabcore_seo_t_seo_seo_my_seo_tit_seo_seo' => $aabcore_seo_t_seo_seo_t_seo_tit_seo_seo,
            'aabcore_seo_t_seo_seo_my_seo_des_seo_seo' => $aabcore_seo_t_seo_seo_t_seo_des_seo_seo,
            'aabcore_seo_t_seo_seo_my_seo_url_seo_seo' => $aabcore_seo_t_seo_seo_t_seo_url_seo_seo,
            'aabcore_seo_t_seo_seo_my_seo_vsite_seo_seo' => $aabcore_seo_t_seo_seo_t_seo_vsite_seo_seo,
        ]);



        wp_send_json_success("✅ Saved successfully!");
    }



     Public function aabcore_seo_ho_seo_fun_seo_seo(){

   global $wp;
        $current_url = home_url(add_query_arg(array(), $wp->request));


    $seo_set_seo = get_option($this->option_name);


$aabcore_seo_seo_tit_seo_seo =  ! empty($seo_set_seo['aabcore_seo_ti_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_ti_seo_seo_my_seo_seo'] : '';
$aabcore_seo_seo_des_seo_seo =  ! empty($seo_set_seo['aabcore_seo_de_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_de_seo_seo_my_seo_seo'] : '';
$aabcore_seo_seo_key_seo_seo =  ! empty($seo_set_seo['aabcore_seo_ke_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_ke_seo_seo_my_seo_seo'] : '';
$aabcore_seo_index_seo_seo =  ! empty($seo_set_seo['aabcore_seo_ind_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_ind_seo_seo_my_seo_seo'] : 'noindex';
$aabcore_seo_follow_seo_seo =   ! empty($seo_set_seo['aabcore_seo_fo_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_fo_seo_seo_my_seo_seo'] : 'nofollow';
$aabcore_seo_canonical_seo_seo =! empty($seo_set_seo['aabcore_seo_ca_seo_seo_my_seo_seo']) ? $seo_set_seo['aabcore_seo_ca_seo_seo_my_seo_seo'] : $current_url;




$aabcore_seo_facebook_title_seo_seo =  ! empty($seo_set_seo['aabcore_seo_f_seo_seo_my_seo_tit_seo_seo']) ? $seo_set_seo['aabcore_seo_f_seo_seo_my_seo_tit_seo_seo'] : '';
$aabcore_seo_facebook_desc_seo_seo =   ! empty($seo_set_seo['aabcore_seo_f_seo_seo_my_seo_des_seo_seo']) ? $seo_set_seo['aabcore_seo_f_seo_seo_my_seo_des_seo_seo'] : '';
$aabcore_seo_facebook_type_seo_seo =! empty($seo_set_seo['aabcore_seo_f_seo_seo_my_seo_typ_seo_seo']) ? $seo_set_seo['aabcore_seo_f_seo_seo_my_seo_typ_seo_seo'] : 'website';
$aabcore_seo_facebook_url_seo_seo =    ! empty($seo_set_seo['aabcore_seo_f_seo_seo_my_seo_url_seo_seo']) ? $seo_set_seo['aabcore_seo_f_seo_seo_my_seo_url_seo_seo'] : '';

$aabcore_seo_twitter_title_seo_seo =  ! empty($seo_set_seo['aabcore_seo_t_seo_seo_my_seo_tit_seo_seo']) ? $seo_set_seo['aabcore_seo_t_seo_seo_my_seo_tit_seo_seo'] : '';
$aabcore_seo_twitter_desc_seo_seo =   ! empty($seo_set_seo['aabcore_seo_t_seo_seo_my_seo_des_seo_seo']) ? $seo_set_seo['aabcore_seo_t_seo_seo_my_seo_des_seo_seo'] : '';
$aabcore_seo_twitter_url_seo_seo =    ! empty($seo_set_seo['aabcore_seo_t_seo_seo_my_seo_url_seo_seo']) ? $seo_set_seo['aabcore_seo_t_seo_seo_my_seo_url_seo_seo'] : '';
$aabcore_seo_twitter_vsite_seo_seo =    ! empty($seo_set_seo['aabcore_seo_t_seo_seo_my_seo_vsite_seo_seo']) ? $seo_set_seo['aabcore_seo_t_seo_seo_my_seo_vsite_seo_seo'] : '';


   $aabcore_seo_seo_one_seo_c_seo_op = get_option('aabcore_seo_seo_one_seo_c_seo', 'off'); // default 'off'
 
   $aabcore_seo_seo_one_seo_c_seo_ck  = ( get_option( 'aabcore_seo_seo_one_seo_c_seo')=== 'on' ) ? 'checked' : '';
 

?>











    <!-- Layout wrapper -->
<div class="seo-seo_l_seo layout-wrapper= layout-content-navbar=" class="a_media_seo_seo_baclkinks">
  <div class="seo-seo_l_seo layout-container">
    

    <!-- Layout container layout-page==-->
    <div class="seo-seo_l_seo layout-page== window-scrolled==">






<!-- Navbar -->

<nav style="border:0px solid red;width:98%;" class="seo-seo_l_seo layout-navbar container-xxl navbar-detached navbar navbar-expand-xl align-items-center bg-navbar-theme navst" id="layout-navbar" >
  




  <div class="seo-seo_l_seo layout-menu-toggle navbar-nav align-items-xl-center me-4 me-xl-0   d-xl-none"  data-bs-toggle="dropdown" >
    <a class="seo-seo_l_seo nav-item nav-link px-0 me-xl-6" >
      <i class="seo-seo_l_seo icon-base bx bx-menu icon-md"></i>
    </a>

 <ul class="seo-seo_l_seo dropdown-menu dropdown-menu-end">
          <li>
            <a class="seo-seo_l_seo dropdown-item active"  data-language="en" data-text-direction="ltr">
              <span><br></span>
            </a>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item"  data-language="fr" data-text-direction="ltr">
              <span>French</span>
            </a>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item"  data-language="ar" data-text-direction="rtl">
              <span>Arabic</span>
            </a>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item" data-language="de" data-text-direction="ltr">
              <span>German</span>
            </a>
          </li>
        </ul>
  </div>



<div class="seo-seo_l_seo navbar-nav-right d-flex align-items-center justify-content-end" id="navbar-collapse">
  
    <!-- Search -->
    <div class="seo-seo_l_seo navbar-nav align-items-center">
      <div class="seo-seo_l_seo nav-item navbar-search-wrapper mb-0">
        <a class="seo-seo_l_seo nav-item nav-link search-toggler px-0" >
          <span class="seo-seo_l_seo d-inline-block text-body-secondary fw-normal" id="autocomplete"><div class="seo-seo_l_seo aa-Autocomplete" role="combobox" aria-expanded="false" aria-haspopup="listbox" aria-labelledby="autocomplete-0-label"><button type="button" class="seo-seo_l_seo aa-DetachedSearchButton" title="Search" id="autocomplete-0-label"><div class="seo-seo_l_seo aa-DetachedSearchButtonIcon"><svg class="seo-seo_l_seo aa-SubmitIcon" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M16.041 15.856c-0.034 0.026-0.067 0.055-0.099 0.087s-0.060 0.064-0.087 0.099c-1.258 1.213-2.969 1.958-4.855 1.958-1.933 0-3.682-0.782-4.95-2.050s-2.050-3.017-2.050-4.95 0.782-3.682 2.050-4.95 3.017-2.050 4.95-2.050 3.682 0.782 4.95 2.050 2.050 3.017 2.050 4.95c0 1.886-0.745 3.597-1.959 4.856zM21.707 20.293l-3.675-3.675c1.231-1.54 1.968-3.493 1.968-5.618 0-2.485-1.008-4.736-2.636-6.364s-3.879-2.636-6.364-2.636-4.736 1.008-6.364 2.636-2.636 3.879-2.636 6.364 1.008 4.736 2.636 6.364 3.879 2.636 6.364 2.636c2.125 0 4.078-0.737 5.618-1.968l3.675 3.675c0.391 0.391 1.024 0.391 1.414 0s0.391-1.024 0-1.414z"></path></svg></div><div class="seo-seo_l_seo aa-DetachedSearchButtonPlaceholder">Search [CTRL + K]</div><div class="seo-seo_l_seo aa-DetachedSearchButtonQuery"></div></button></div></span>
        </a>
      </div>
    </div>

    <!-- /Search -->
  
  

  

  <ul class="seo-seo_l_seo navbar-nav flex-row align-items-center ms-md-auto">
    

      
      <!-- Language -->
      <li class="seo-seo_l_seo nav-item dropdown-language dropdown me-2 me-xl-0">
        <a href="admin.php?page=aabcore-seo-offer-seo-p-seo" class="seo-seo_l_seo nav-link dropdown-toggle hide-arrow"  data-bs-toggle="dropdown">
            <i class="seo-seo_l_seo icon-base bx bx-globe icon-md"></i>
          </a>
        <ul class="seo-seo_l_seo dropdown-menu dropdown-menu-end media_seo_dis-">
          <li>
            <a class="seo-seo_l_seo dropdown-item active"  data-language="en" data-text-direction="ltr">
              <span>English</span>
            </a>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item"  data-language="fr" data-text-direction="ltr">
              <span>French</span>
            </a>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item"  data-language="ar" data-text-direction="rtl">
              <span>Arabic</span>
            </a>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item"  data-language="de" data-text-direction="ltr">
              <span>German</span>
            </a>
          </li>
        </ul>
      </li>
      <!--/ Language -->

      
        <!-- Style Switcher -->
        <li class="seo-seo_l_seo nav-item dropdown me-2 me-xl-0">
          <a class="seo-seo_l_seo nav-link dropdown-toggle hide-arrow" id="nav-theme"  data-bs-toggle="dropdown" aria-label="Toggle theme (light)">
            <i class="seo-seo_l_seo bx-sun icon-base bx icon-md theme-icon-active"></i>  
            <span class="seo-seo_l_seo d-none ms-2" id="nav-theme-text">Toggle theme</span>
          </a>
          <ul class="seo-seo_l_seo dropdown-menu dropdown-menu-end" aria-labelledby="nav-theme-text media_seo_dis">
            <li>
              <button type="button" class="seo-seo_l_seo dropdown-item align-items-center active" data-bs-theme-value="light" aria-pressed="true">
                <span><i class="seo-seo_l_seo icon-base bx bx-sun icon-md me-3" data-icon="sun"></i>Light</span>
              </button>
            </li>
            <li>
              <button type="button" class="seo-seo_l_seo dropdown-item align-items-center" data-bs-theme-value="dark" aria-pressed="false">
                <span><i class="seo-seo_l_seo icon-base bx bx-moon icon-md me-3" data-icon="moon"></i>Dark</span>
              </button>
            </li>
            <li>
              <button type="button" class="seo-seo_l_seo dropdown-item align-items-center" data-bs-theme-value="system" aria-pressed="false">
                <span><i class="seo-seo_l_seo icon-base bx bx-desktop icon-md me-3" data-icon="desktop"></i>System</span>
              </button>
            </li>
          </ul>
        </li>
        <!-- / Style Switcher-->
      

      <!-- Quick links  -->
      <li class="seo-seo_l_seo nav-item dropdown-shortcuts navbar-dropdown dropdown me-2 me-xl-0">
        <a href="admin.php?page=aabcore-seo-offer-seo-p-seo" class="seo-seo_l_seo nav-link dropdown-toggle hide-arrow"  data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
          <i class="seo-seo_l_seo icon-base bx bx-grid-alt icon-md"></i>  
        </a>
        <div class="seo-seo_l_seo dropdown-menu dropdown-menu-end p-0 media_seo_dis-">
          <div class="seo-seo_l_seo dropdown-menu-header border-bottom">
            <div class="seo-seo_l_seo dropdown-header d-flex align-items-center py-3">
              <h6 class="seo-seo_l_seo mb-0 me-auto">Shortcuts</h6>
              <a class="seo-seo_l_seo dropdown-shortcuts-add py-2" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="Add shortcuts" data-bs-original-title="Add shortcuts"><i class="seo-seo_l_seo icon-base bx bx-plus-circle text-heading"></i></a>
            </div>
          </div>
          <div class="seo-seo_l_seo dropdown-shortcuts-list scrollable-container ps">
            <div class="seo-seo_l_seo row row-bordered overflow-visible g-0">
              <div class="seo-seo_l_seo dropdown-shortcuts-item col">
                <span class="seo-seo_l_seo dropdown-shortcuts-icon rounded-circle mb-3">
                  <i class="seo-seo_l_seo icon-base bx bx-calendar icon-26px text-heading"></i>
                </span>
                <a  class="seo-seo_l_seo stretched-link">Calendar</a>
                <small>Appointments</small>
              </div>
              <div class="seo-seo_l_seo dropdown-shortcuts-item col">
                <span class="seo-seo_l_seo dropdown-shortcuts-icon rounded-circle mb-3">
                  <i class="seo-seo_l_seo icon-base bx bx-food-menu icon-26px text-heading"></i>
                </span>
                <a  class="seo-seo_l_seo stretched-link">Invoice App</a>
                <small>Manage Accounts</small>
              </div>
            </div>
            <div class="seo-seo_l_seo row row-bordered overflow-visible g-0">
              <div class="seo-seo_l_seo dropdown-shortcuts-item col">
                <span class="seo-seo_l_seo dropdown-shortcuts-icon rounded-circle mb-3">
                  <i class="seo-seo_l_seo icon-base bx bx-user icon-26px text-heading"></i>
                </span>
                <a  class="seo-seo_l_seo stretched-link">User App</a>
                <small>Manage Users</small>
              </div>
              <div class="seo-seo_l_seo dropdown-shortcuts-item col">
                <span class="seo-seo_l_seo dropdown-shortcuts-icon rounded-circle mb-3">
                  <i class="seo-seo_l_seo icon-base bx bx-check-shield icon-26px text-heading"></i>
                </span>
                <a class="seo-seo_l_seo stretched-link">Role Management</a>
                <small>Permission</small>
              </div>
            </div>
            <div class="seo-seo_l_seo row row-bordered overflow-visible g-0">
              <div class="seo-seo_l_seo dropdown-shortcuts-item col">
                <span class="seo-seo_l_seo dropdown-shortcuts-icon rounded-circle mb-3">
                  <i class="seo-seo_l_seo icon-base bx bx-pie-chart-alt-2 icon-26px text-heading"></i>
                </span>
                <a  class="seo-seo_l_seo stretched-link">Dashboard</a>
                <small>User Dashboard</small>
              </div>
              <div class="seo-seo_l_seo dropdown-shortcuts-item col">
                <span class="seo-seo_l_seo dropdown-shortcuts-icon rounded-circle mb-3">
                  <i class="seo-seo_l_seo icon-base bx bx-cog icon-26px text-heading"></i>
                </span>
                <a  class="seo-seo_l_seo stretched-link">Setting</a>
                <small>Account Settings</small>
              </div>
            </div>
            <div class="seo-seo_l_seo row row-bordered overflow-visible g-0">
              <div class="seo-seo_l_seo dropdown-shortcuts-item col">
                <span class="seo-seo_l_seo dropdown-shortcuts-icon rounded-circle mb-3">
                  <i class="seo-seo_l_seo icon-base bx bx-help-circle icon-26px text-heading"></i>
                </span>
                <a  class="seo-seo_l_seo stretched-link">FAQs</a>
                <small>FAQs & Articles</small>
              </div>
              <div class="seo-seo_l_seo dropdown-shortcuts-item col">
                <span class="seo-seo_l_seo dropdown-shortcuts-icon rounded-circle mb-3">
                  <i class="seo-seo_l_seo icon-base bx bx-window-open icon-26px text-heading"></i>
                </span>
                <a  class="seo-seo_l_seo stretched-link">Modals</a>
                <small>Useful Popups</small>
              </div>
            </div>
          <div class="seo-seo_l_seo ps__rail-x" ><div class="seo-seo_l_seo ps__thumb-x" tabindex="0" ></div></div><div class="seo-seo_l_seo ps__rail-y"><div class="seo-seo_l_seo ps__thumb-y" tabindex="0" ></div></div></div>
        </div>
      </li>
      <!-- Quick links -->

      <!-- Notification -->
      <li class="seo-seo_l_seo nav-item dropdown-notifications navbar-dropdown dropdown me-3 me-xl-2">
        <a class="seo-seo_l_seo nav-link dropdown-toggle hide-arrow"  data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
          <span class="seo-seo_l_seo position-relative">
            <i class="seo-seo_l_seo icon-base bx bx-bell icon-md"></i>
            <span class="seo-seo_l_seo badge rounded-pill bg-danger badge-dot badge-notifications border"></span>
          </span>
          </a>
        <ul class="seo-seo_l_seo dropdown-menu dropdown-menu-end p-0 media_seo_dis">
          <li class="seo-seo_l_seo dropdown-menu-header border-bottom">
            <div class="seo-seo_l_seo dropdown-header d-flex align-items-center py-3">
              <h6 class="seo-seo_l_seo mb-0 me-auto">Notification</h6>
              <div class="seo-seo_l_seo d-flex align-items-center h6 mb-0">
                <span class="seo-seo_l_seo badge bg-label-primary me-2">8 New</span>
                <a class="seo-seo_l_seo dropdown-notifications-all p-2" data-bs-toggle="tooltip" data-bs-placement="top" aria-label="Mark all as read" data-bs-original-title="Mark all as read"><i class="seo-seo_l_seo icon-base bx bx-envelope-open text-heading"></i></a>
              </div>
            </div>
          </li>
          <li class="seo-seo_l_seo dropdown-notifications-list scrollable-container ps">
            <ul class="seo-seo_l_seo list-group list-group-flush">
              <li class="seo-seo_l_seo list-group-item list-group-item-action dropdown-notifications-item">
                <div class="seo-seo_l_seo d-flex">
                  <div class="seo-seo_l_seo flex-shrink-0 me-3">
                    <div class="seo-seo_l_seo avatar">
                      <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-danger">CF</span>
                    </div>
                  </div>
                  <div class="seo-seo_l_seo flex-grow-1">
                    <h6 class="seo-seo_l_seo small mb-0">Congratulation Lettie 🎉</h6>
                    <small class="seo-seo_l_seo mb-1 d-block text-body">Won the monthly best seller gold badge</small>
                    <small class="seo-seo_l_seo text-body-secondary">1h ago</small>
                  </div>
                  <div class="seo-seo_l_seo flex-shrink-0 dropdown-notifications-actions">
                    <a  class="seo-seo_l_seo dropdown-notifications-read"><span class="seo-seo_l_seo badge badge-dot"></span></a>
                    <a  class="seo-seo_l_seo dropdown-notifications-archive"><span class="seo-seo_l_seo icon-base bx bx-x"></span></a>
                  </div>
                </div>
              </li>
              <li class="seo-seo_l_seo list-group-item list-group-item-action dropdown-notifications-item">
                <div class="seo-seo_l_seo d-flex">
                  <div class="seo-seo_l_seo flex-shrink-0 me-3">
                    <div class="seo-seo_l_seo avatar">
                      <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-danger">CF</span>
                    </div>
                  </div>
                  <div class="seo-seo_l_seo flex-grow-1">
                    <h6 class="seo-seo_l_seo small mb-0">Charles Franklin</h6>
                    <small class="seo-seo_l_seo mb-1 d-block text-body">Accepted your connection</small>
                    <small class="seo-seo_l_seo text-body-secondary">12hr ago</small>
                  </div>
                  <div class="seo-seo_l_seo flex-shrink-0 dropdown-notifications-actions">
                    <a  class="seo-seo_l_seo dropdown-notifications-read"><span class="seo-seo_l_seo badge badge-dot"></span></a>
                    <a  class="seo-seo_l_seo dropdown-notifications-archive"><span class="seo-seo_l_seo icon-base bx bx-x"></span></a>
                  </div>
                </div>
              </li>
              <li class="seo-seo_l_seo list-group-item list-group-item-action dropdown-notifications-item marked-as-read">
                <div class="seo-seo_l_seo d-flex">
                  <div class="seo-seo_l_seo flex-shrink-0 me-3">
                    <div class="seo-seo_l_seo avatar">
                      <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-danger">CF</span>
                    </div>
                  </div>
                  <div class="seo-seo_l_seo flex-grow-1">
                    <h6 class="seo-seo_l_seo small mb-0">New Message ✉️</h6>
                    <small class="seo-seo_l_seo mb-1 d-block text-body">You have new message from Natalie</small>
                    <small class="seo-seo_l_seo text-body-secondary">1h ago</small>
                  </div>
                  <div class="seo-seo_l_seo flex-shrink-0 dropdown-notifications-actions">
                    <a  class="seo-seo_l_seo dropdown-notifications-read"><span class="seo-seo_l_seo badge badge-dot"></span></a>
                    <a  class="seo-seo_l_seo dropdown-notifications-archive"><span class="seo-seo_l_seo icon-base bx bx-x"></span></a>
                  </div>
                </div>
              </li>
              <li class="seo-seo_l_seo list-group-item list-group-item-action dropdown-notifications-item">
                <div class="seo-seo_l_seo d-flex">
                  <div class="seo-seo_l_seo flex-shrink-0 me-3">
                    <div class="seo-seo_l_seo avatar">
                      <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-success"><i class="seo-seo_l_seo icon-base bx bx-cart"></i></span>
                    </div>
                  </div>
                  <div class="seo-seo_l_seo flex-grow-1">
                    <h6 class="seo-seo_l_seo small mb-0">Whoo! You have new order 🛒</h6>
                    <small class="seo-seo_l_seo mb-1 d-block text-body">ACME Inc. made new order $1,154</small>
                    <small class="seo-seo_l_seo text-body-secondary">1 day ago</small>
                  </div>
                  <div class="seo-seo_l_seo flex-shrink-0 dropdown-notifications-actions">
                    <a  class="seo-seo_l_seo dropdown-notifications-read"><span class="seo-seo_l_seo badge badge-dot"></span></a>
                    <a class="seo-seo_l_seo dropdown-notifications-archive"><span class="seo-seo_l_seo icon-base bx bx-x"></span></a>
                  </div>
                </div>
              </li>
              <li class="seo-seo_l_seo list-group-item list-group-item-action dropdown-notifications-item marked-as-read">
                <div class="seo-seo_l_seo d-flex">
                  <div class="seo-seo_l_seo flex-shrink-0 me-3">
                    <div class="seo-seo_l_seo avatar">
                      <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-danger">CF</span>
                    </div>
                  </div>
                  <div class="seo-seo_l_seo flex-grow-1">
                    <h6 class="seo-seo_l_seo small mb-0">Application has been approved 🚀</h6>
                    <small class="seo-seo_l_seo mb-1 d-block text-body">Your ABC project application has been approved.</small>
                    <small class="seo-seo_l_seo text-body-secondary">2 days ago</small>
                  </div>
                  <div class="seo-seo_l_seo flex-shrink-0 dropdown-notifications-actions">
                    <a  class="seo-seo_l_seo dropdown-notifications-read"><span class="seo-seo_l_seo badge badge-dot"></span></a>
                    <a  class="seo-seo_l_seo dropdown-notifications-archive"><span class="seo-seo_l_seo icon-base bx bx-x"></span></a>
                  </div>
                </div>
              </li>
              <li class="seo-seo_l_seo list-group-item list-group-item-action dropdown-notifications-item marked-as-read">
                <div class="seo-seo_l_seo d-flex">
                  <div class="seo-seo_l_seo flex-shrink-0 me-3">
                    <div class="seo-seo_l_seo avatar">
                      <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-success"><i class="seo-seo_l_seo icon-base bx bx-pie-chart-alt"></i></span>
                    </div>
                  </div>
                  <div class="seo-seo_l_seo flex-grow-1">
                    <h6 class="seo-seo_l_seo small mb-0">Monthly report is generated</h6>
                    <small class="seo-seo_l_seo mb-1 d-block text-body">July monthly financial report is generated </small>
                    <small class="seo-seo_l_seo text-body-secondary">3 days ago</small>
                  </div>
                  <div class="seo-seo_l_seo flex-shrink-0 dropdown-notifications-actions">
                    <a class="seo-seo_l_seo dropdown-notifications-read"><span class="seo-seo_l_seo badge badge-dot"></span></a>
                    <a class="seo-seo_l_seo dropdown-notifications-archive"><span class="seo-seo_l_seo icon-base bx bx-x"></span></a>
                  </div>
                </div>
              </li>
              <li class="seo-seo_l_seo list-group-item list-group-item-action dropdown-notifications-item marked-as-read">
                <div class="seo-seo_l_seo d-flex">
                  <div class="seo-seo_l_seo flex-shrink-0 me-3">
                    <div class="seo-seo_l_seo avatar">
                      <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-danger">CF</span>
                    </div>
                  </div>
                  <div class="seo-seo_l_seo flex-grow-1">
                    <h6 class="seo-seo_l_seo small mb-0">Send connection request</h6>
                    <small class="seo-seo_l_seo mb-1 d-block text-body">Peter sent you connection request</small>
                    <small class="seo-seo_l_seo text-body-secondary">4 days ago</small>
                  </div>
                  <div class="seo-seo_l_seo flex-shrink-0 dropdown-notifications-actions">
                    <a class="seo-seo_l_seo dropdown-notifications-read"><span class="seo-seo_l_seo badge badge-dot"></span></a>
                    <a  class="seo-seo_l_seo dropdown-notifications-archive"><span class="seo-seo_l_seo icon-base bx bx-x"></span></a>
                  </div>
                </div>
              </li>
              <li class="seo-seo_l_seo list-group-item list-group-item-action dropdown-notifications-item">
                <div class="seo-seo_l_seo d-flex">
                  <div class="seo-seo_l_seo flex-shrink-0 me-3">
                    <div class="seo-seo_l_seo avatar">
                      <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-danger">CF</span>
                    </div>
                  </div>
                  <div class="seo-seo_l_seo flex-grow-1">
                    <h6 class="seo-seo_l_seo small mb-0">New message from Jane</h6>
                    <small class="seo-seo_l_seo mb-1 d-block text-body">Your have new message from Jane</small>
                    <small class="seo-seo_l_seo text-body-secondary">5 days ago</small>
                  </div>
                  <div class="seo-seo_l_seo flex-shrink-0 dropdown-notifications-actions">
                    <a  class="seo-seo_l_seo dropdown-notifications-read"><span class="seo-seo_l_seo badge badge-dot"></span></a>
                    <a class="seo-seo_l_seo dropdown-notifications-archive"><span class="seo-seo_l_seo icon-base bx bx-x"></span></a>
                  </div>
                </div>
              </li>
              <li class="seo-seo_l_seo list-group-item list-group-item-action dropdown-notifications-item marked-as-read">
                <div class="seo-seo_l_seo d-flex">
                  <div class="seo-seo_l_seo flex-shrink-0 me-3">
                    <div class="seo-seo_l_seo avatar">
                      <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-warning"><i class="seo-seo_l_seo icon-base bx bx-error"></i></span>
                    </div>
                  </div>
                  <div class="seo-seo_l_seo flex-grow-1">
                    <h6 class="seo-seo_l_seo small mb-0">CPU is running high</h6>
                    <small class="seo-seo_l_seo mb-1 d-block text-body">CPU Utilization Percent is currently at 88.63%,</small>
                    <small class="seo-seo_l_seo text-body-secondary">5 days ago</small>
                  </div>
                  <div class="seo-seo_l_seo flex-shrink-0 dropdown-notifications-actions">
                    <a  class="seo-seo_l_seo dropdown-notifications-read"><span class="seo-seo_l_seo badge badge-dot"></span></a>
                    <a  class="seo-seo_l_seo dropdown-notifications-archive"><span class="seo-seo_l_seo icon-base bx bx-x"></span></a>
                  </div>
                </div>
              </li>
            </ul>
          <div class="seo-seo_l_seo ps__rail-x" ><div class="seo-seo_l_seo ps__thumb-x" tabindex="0" ></div></div><div class="seo-seo_l_seo ps__rail-y" ><div class="seo-seo_l_seo ps__thumb-y" tabindex="0" ></div></div></li>
          <li class="seo-seo_l_seo border-top">
            <div class="seo-seo_l_seo d-grid p-4">
              <a class="seo-seo_l_seo btn btn-primary btn-sm d-flex">
                <small class="seo-seo_l_seo align-middle">View all notifications</small>
              </a>
            </div>
          </li>
        </ul>
      </li>
      <!--/ Notification -->
      <!-- User -->
      <li class="seo-seo_l_seo nav-item navbar-dropdown dropdown-user dropdown">
        <a class="seo-seo_l_seo nav-link dropdown-toggle hide-arrow p-0"  data-bs-toggle="dropdown">
          <div class="seo-seo_l_seo avatar avatar-online">
            <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-danger">A</span>
          </div>
        </a>
        <ul class="seo-seo_l_seo dropdown-menu dropdown-menu-end media_seo_dis">
          <li>
            <a class="seo-seo_l_seo dropdown-item" >
              <div class="seo-seo_l_seo d-flex">
                <div class="seo-seo_l_seo flex-shrink-0 me-3">
                  <div class="seo-seo_l_seo avatar avatar-online">
                    <span class="seo-seo_l_seo avatar-initial rounded-circle bg-label-danger">CF</span>
                  </div>
                </div>
                <div class="seo-seo_l_seo flex-grow-1">
                  <h6 class="seo-seo_l_seo mb-0">John Doe</h6>
                  <small class="seo-seo_l_seo text-body-secondary">Admin</small>
                </div>
              </div>
            </a>
          </li>
          <li>
            <div class="seo-seo_l_seo dropdown-divider my-1"></div>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item" > <i class="seo-seo_l_seo icon-base bx bx-user icon-md me-3"></i><span>My Profile</span> </a>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item"> <i class="seo-seo_l_seo icon-base bx bx-cog icon-md me-3"></i><span>Settings</span> </a>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item">
              <span class="seo-seo_l_seo d-flex align-items-center align-middle">
                <i class="seo-seo_l_seo flex-shrink-0 icon-base bx bx-credit-card icon-md me-3"></i><span class="seo-seo_l_seo flex-grow-1 align-middle">Billing Plan</span>
                <span class="seo-seo_l_seo flex-shrink-0 badge rounded-pill bg-danger">4</span>
              </span>
            </a>
          </li>
          <li>
            <div class="seo-seo_l_seo dropdown-divider my-1"></div>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item"> <i class="seo-seo_l_seo icon-base bx bx-dollar icon-md me-3"></i><span>Pricing</span> </a>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item"> <i class="seo-seo_l_seo icon-base bx bx-help-circle icon-md me-3"></i><span>FAQ</span> </a>
          </li>
          <li>
            <div class="seo-seo_l_seo dropdown-divider my-1"></div>
          </li>
          <li>
            <a class="seo-seo_l_seo dropdown-item"  target="_blank"> <i class="seo-seo_l_seo icon-base bx bx-power-off icon-md me-3"></i><span>Log Out</span> </a>
          </li>
        </ul>
      </li>
      <!--/ User -->
    
  </ul>
</div>

</nav>

<!-- / Navbar -->




      

      <!-- Content wrapper -->
      <div class="seo-seo_l_seo content-wrapper" class="b_media_seo_seo_baclkinks">
        <!-- Content -->


              
        <div class="seo-seo_l_seo container-xxl flex-grow-1 container-p-y">
  <!-- Default -->
  <div class="seo-seo_l_seo row">
<div class="seo-seo_l_seo col-12 seo-top-seo-img-seo-seo"> </div>
    <div class="seo-seo_l_seo col-12">
      <br><br>
    </div>



<?php

if (get_option('show_on_front') === 'page') { ?>

   <div class="seo-seo_l_seo col-12 mb-4">
<br>
<h3>Your homepage displays</h3>
<br><br><br>
<h5>You have changed WordPress settings so your homepage is set to a static page.</h5>
<br>
<a href="edit.php?post_type=page"><h5>Click to edit the homepage SEO meta information, including the title and description.</h5></a>
<br><br><br>
<hr>
<br><br>
</div>
<?php } else {
   
 
?>



  
    <div class="seo-seo_l_seo col-12 mb-4">



              <div class="seo-seo_l_seo row g-6">
                <div class="seo-seo_l_seo col-sm-6">
                <h5>Start SEO</h5><br>




     <div class="c_media_seo_seo_baclkinks">


<div class="d_media_seo_seo_baclkinks">
                <label class="seo-seo_l_seo cache-cdn aabcore-cache-swit-cache aabc-toggle-group">
                <input type="checkbox" class="seo-seo_l_seo cache-cdn aabcore-cache-togg-cache" 
                data-option="aabcore_seo_seo_one_seo_c_seo" <?php echo esc_html($aabcore_seo_seo_one_seo_c_seo_ck); ?>>
                <span class="seo-seo_l_seo cache-cdn asbcore-cache-slid-cache"></span>
                </label> 
</div>
<div class="e_media_seo_seo_baclkinks">
Click button to start seo. 
</div>

<div class="f_media_seo_seo_baclkinks">
                <strong id="aabcore_seo_seo_one_seo_c_seo-s-seo-seo"><?php if($aabcore_seo_seo_one_seo_c_seo_op===$this->aabcore_st_SEO){ ?>✅<?php }else{ ?>❌<?php } ?></strong>
</div>
              


     </div>


            </div>                
                <div class="seo-seo_l_seo col-sm-6">



      


        <?php
		$Aabcore_Page_support=new Aabcore_Page_support();
		$Aabcore_Page_support->aabcore_seo_upgrade();
		?>





               </div><br><br>

          <!--  -->
          <div class="<?php if($aabcore_seo_seo_one_seo_c_seo_op===$this->aabcore_st_SEO){ ?>media_seo_dis<?php } ?> g_media_seo_seo_baclkinks" id="aabcore_seo_seo_one_seo_c_seo-seo-wa-seo-seo">
          <h4>Getting Started with SEO and Metadata</h4>
          <h6 class="h_t_media_seo_seo_baclkinks">Search Engine Optimization (SEO) is the process of improving a website’s visibility on search engines like Google. By optimizing content, structure, and technical elements, SEO helps search engines understand what a website is about and match it with relevant user searches. A strong SEO foundation increases organic traffic, improves credibility, and supports long-term online growth.<br><br>Metadata plays a critical role in SEO. It includes elements such as meta titles, meta descriptions, and meta keywords. These elements do not usually appear on the webpage itself, but they help search engines interpret the page’s content and influence how the page appears in search results.</h6>



    </div>








           <div class="<?php if($aabcore_seo_seo_one_seo_c_seo_op===$this->aabcore_st_SEO){ ?><?php }else{ ?>media_seo_dis<?php } ?>" id="aabcore_seo_seo_one_seo_c_seo-seo-pri-seo-seo">



 
<!-- Basic Layout & Basic with Icons -->

<div class="seo-seo_l_seo row mb-6 hy-6">
  <!-- Basic Layout -->
  <div class="seo-seo_l_seo col-xxl">
    <div class="seo-seo_l_seo card-">
      <div class="seo-seo_l_seo card-header d-flex align-items-center justify-content-between">
        <h5 class="seo-seo_l_seo mb-0">Aabcore SEO</h5>
        <small class="seo-seo_l_seo text-body-secondary float-end"></small>
      </div><br><br>
          <div class="seo-seo_l_seo content-header mb-4">
                <h6 class="seo-seo_l_seo mb-0">SEO Preview</h6><br>
          <div class="h_media_seo_seo_baclkinks">
          <h6 id="aabcoreseotit" class="h_t_media_seo_seo_baclkinks"><?php echo esc_html($aabcore_seo_seo_tit_seo_seo); ?></h6>
          <p class="h_d_media_seo_seo_baclkinks" id="aabcoreseotdes"><?php echo esc_html($aabcore_seo_seo_des_seo_seo); ?></p>
          </div><br>
            </div>
      <div class="seo-seo_l_seo card-body">


<?php //echo get_option('data'); ?>

<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
<input type="hidden" name="action" value="my_plugin_save">
                <?php wp_nonce_field('my_plugin_save_action', 'my_plugin_nonce'); ?>


















<?php /* ?>
         <form onsubmit="return false"><?php */ ?>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-name">SEO Title - <span id="aabcorestitle"></span></label>
            <div class="seo-seo_l_seo col-sm-10">
                  <input type="text" id="aabcore_seo_title_seo" name="aabcore_seo_title_seo" class="seo-seo_l_seo form-control" placeholder="SEO Title" value="<?php echo esc_attr($aabcore_seo_seo_tit_seo_seo); ?>">
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">SEO Description - <span id="aabcoresdesc"></span></label>
            <div class="seo-seo_l_seo col-sm-10">
              <input type="email" id="aabcore_seo_desc_seo" name="aabcore_seo_desc_seo" class="seo-seo_l_seo form-control" placeholder="SEO Description" aria-label="seo.seo"  value="<?php echo esc_attr($aabcore_seo_seo_des_seo_seo); ?>">
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">SEO Keywords</label>
            <div class="seo-seo_l_seo col-sm-10"><label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Type keyword use "," as separator</label>
              <input type="text" class="seo-seo_l_seo form-control" id="aabcore_seo_keyw_seo" name='aabcore_seo_keyw_seo' placeholder="Keywords" name='basic' value="<?php echo esc_attr($aabcore_seo_seo_key_seo_seo); ?>">
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Index, Noindex</label>
            <div class="seo-seo_l_seo col-sm-10">
<hr class="seo-seo_l_seo m-0" />
        <div class="seo-seo_l_seo row row-bordered g-0">
          <div class="seo-seo_l_seo col-md p-6">
            <small class="seo-seo_l_seo fw-medium d-block">Index</small>
            <div class="seo-seo_l_seo form-check form-check-success"><br>
              <input name="aabcore_seo_ind_seo" class="seo-seo_l_seo form-check-input" type="radio" value="index" id="aabcore_seo_ind_seo" <?php if($aabcore_seo_index_seo_seo===$this->index){ ?>checked<?php } ?> />
            </div>
          </div>
          <div class="seo-seo_l_seo col-md p-6">
            <small class="seo-seo_l_seo fw-medium d-block">Noindex</small>
            <div class="seo-seo_l_seo form-check form-check-danger"><br>
              <input name="aabcore_seo_ind_seo" class="seo-seo_l_seo form-check-input" type="radio" value="noindex" id="aabcore_seo_ind_seo" <?php if($aabcore_seo_index_seo_seo===$this->noindex){ ?>checked<?php } ?> />
            </div>
          </div>
        </div>
<hr class="seo-seo_l_seo m-0" />
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Follow, Nofollow</label>
            <div class="seo-seo_l_seo col-sm-10">
<hr class="seo-seo_l_seo m-0" />
        <div class="seo-seo_l_seo row row-bordered g-0">
          <div class="seo-seo_l_seo col-md p-6">Follow</small>
            <div class="seo-seo_l_seo form-check form-check-success"><br>
              <input name="aabcore_seo_folw_seo" class="seo-seo_l_seo form-check-input" type="radio" value="follow" id="aabcore_seo_folw_seo" <?php if($aabcore_seo_follow_seo_seo===$this->follow){ ?>checked<?php } ?> />
            </div>
          </div>
          <div class="seo-seo_l_seo col-md p-6">
            <small class="seo-seo_l_seo fw-medium d-block">Nofollow</small>
            <div class="seo-seo_l_seo form-check form-check-danger"><br>
              <input name="aabcore_seo_folw_seo" class="seo-seo_l_seo form-check-input" type="radio" value="nofollow" id="aabcore_seo_folw_seo" <?php if($aabcore_seo_follow_seo_seo===$this->nofollow){ ?>checked<?php } ?> />
            </div>
          </div>
        </div>
<hr class="seo-seo_l_seo m-0" />
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Canonical URL</label>
            <div class="seo-seo_l_seo col-sm-10">
              <input type="text"  class="seo-seo_l_seo form-control" id="aabcore_seo_cal_seo" name="aabcore_seo_cal_seo" placeholder="Canonical URL" value="<?php echo esc_attr($aabcore_seo_canonical_seo_seo ); ?>" aria-describedby="seo-seo">
            </div>
          </div>
<br><hr class="seo-seo_l_seo m-0" />
<h4 class="seo-seo_l_seo mb-0">Social Media Facebook SEO</h4>
<hr class="seo-seo_l_seo m-0" /><br><br>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Facebook Title</label>
            <div class="seo-seo_l_seo col-sm-10">
              <input type="text" id="aabcore_seo_f_seo_title_seo" name="aabcore_seo_f_seo_title_seo" class="seo-seo_l_seo form-control" placeholder="Title" value="<?php echo esc_attr($aabcore_seo_facebook_title_seo_seo); ?>">
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Facebook Descriptions</label>
            <div class="seo-seo_l_seo col-sm-10">
              <input type="text" id="aabcore_seo_f_seo_desc_seo" name="aabcore_seo_f_seo_desc_seo" class="seo-seo_l_seo form-control" placeholder="Descriptions" value="<?php echo esc_attr($aabcore_seo_facebook_desc_seo_seo); ?>">
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Type</label>
            <div class="seo-seo_l_seo col-sm-10">
              <input type="text" id="aabcore_seo_f_seo_type_seo" name="aabcore_seo_f_seo_type_seo" class="seo-seo_l_seo form-control" placeholder="website" value="<?php echo esc_attr($aabcore_seo_facebook_type_seo_seo); ?>">
            </div>
          </div>
         <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Upload Image</label>
            <div class="seo-seo_l_seo col-sm-10">
              <button type="button" class="seo-seo_l_seo button upload-btn" data-target="image1">Select Image</button>
                <br><br>
                            <div id="hide_image1"><?php if($aabcore_seo_facebook_url_seo_seo !==''){ ?>
                                <img src="<?php echo esc_attr($aabcore_seo_facebook_url_seo_seo); ?>" class="i_media_seo_seo_baclkinks"><?php } ?>
                            </div>
                            <div id="preview_image1"><?php if ( isset( $image1) )  {echo wp_get_attachment_image($image1, 'thumbnail');} ?>
                            </div>
              <input type="hidden" id="aabcore_seo_img_seo_url_seo_image1" name="aabcore_seo_img_seo_url_seo_image1" class="seo-seo_l_seo form-control" value="<?php echo esc_attr($aabcore_seo_facebook_url_seo_seo); ?>">
                <br>

                <div id="aabcore_seo_up_seo_me_seo_image1">
                    
                </div>
            </div>
          </div>

<br><hr class="seo-seo_l_seo m-0" />
<h4 class="seo-seo_l_seo mb-0">Social Media Twitter SEO</h4>
<hr class="seo-seo_l_seo m-0" /><br><br>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Twitter Title</label>
            <div class="seo-seo_l_seo col-sm-10">
              <input type="text" id="aabcore_seo_t_seo_title_seo" name="aabcore_seo_t_seo_title_seo" class="seo-seo_l_seo form-control" placeholder="Title"  value="<?php echo esc_attr($aabcore_seo_twitter_title_seo_seo); ?>">
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Twitter Descriptions</label>
            <div class="seo-seo_l_seo col-sm-10">
              <input type="text" id="aabcore_seo_t_seo_desc_seo" name="aabcore_seo_t_seo_desc_seo" class="seo-seo_l_seo form-control" placeholder="Descriptions" value="<?php echo esc_attr($aabcore_seo_twitter_desc_seo_seo); ?>">
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Upload Image</label>
            <div class="seo-seo_l_seo col-sm-10">
              <button type="button" class="seo-seo_l_seo button upload-btn" data-target="image2">Select Image</button>
                <br><br>
                            <div id="hide_image2"><?php if($aabcore_seo_twitter_url_seo_seo !==''){ ?>
                                <img src="<?php echo esc_attr($aabcore_seo_twitter_url_seo_seo); ?>" class="i_media_seo_seo_baclkinks"><?php } ?>
                            </div>
                            <div id="preview_image2"><?php if ( isset( $image2) )  {echo wp_get_attachment_image($image2, 'thumbnail');} ?>
                            </div>
              <input type="hidden" id="aabcore_seo_img_seo_url_seo_image2" name="aabcore_seo_img_seo_url_seo_image2" class="seo-seo_l_seo form-control" value="<?php echo esc_attr($aabcore_seo_twitter_url_seo_seo); ?>">
                <br>
                <div id="aabcore_seo_up_seo_me_seo_image2">
                   
                </div>
            </div>
          </div>



<br><hr class="seo-seo_l_seo m-0" />
<h4 class="seo-seo_l_seo mb-0" id="send">Google Site Verification</h4>
<hr class="seo-seo_l_seo m-0" /><br><br>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Site Verification</label>
            <div class="seo-seo_l_seo col-sm-10">

              <input type="text" id="aabcore_seo_t_seo_vsite_seo" name="aabcore_seo_t_seo_vsite_seo" class="seo-seo_l_seo form-control" placeholder="Google Site Verification" value="<?php echo esc_attr($aabcore_seo_twitter_vsite_seo_seo); ?>">

            </div>
          </div>
 

          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company"></label>
            <div class="seo-seo_l_seo col-sm-10">You can leave blank this field.<br>
Google Search Console/Google Apps. This is your website's unique code. It is the code shown within content="" inside the meta tag given to you. -> <a href="https://aabcore.co.in/site-verification-plugins.php" target="_blank">About Site Verification</a>
            </div>
          </div>

          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-message"></label>
            <div class="seo-seo_l_seo col-sm-10">
            <p id="aabcore-seo-seo-key-seo-seo">  </p>
            </div>
          </div>

          <div class="seo-seo_l_seo row justify-content-end">
            <div class="seo-seo_l_seo col-sm-10"><?php /* ?>
                <p id="aabcore-seo_seo-bta-seo-seo" class="seo-seo_l_seo btn btn-success btn-submit-">Save Settings</p>



<?php 
*/
        if (
            isset($_GET['page'], $_GET['updated']) &&
            $_GET['page'] === 'aabcore-seo-home-seo-seo' &&
            $_GET['updated'] === '1'
        ) {
 ?><p>✅ Saved successfully!</p><?php }else{ ?><p> </p><?php } ?>

               <?php submit_button('Save Changes'); ?>

            



            </div>
          </div>
        </form>
      </div>
    </div>
  </div>






  </div>
        </div>
        <!-- / Content -->

   

<?php } ?>





<hr class="seo-seo_l_seo m-0" />
        

<!-- Footer -->
<footer class="seo-seo_l_seo content-footer footer bg-footer-theme" >
  <div class="seo-seo_l_seo container-xxl">
    <div class="seo-seo_l_seo footer-container d-flex align-items-center justify-content-between py-4 flex-md-row flex-column">
      <div class="seo-seo_l_seo mb-2 mb-md-0">
        ©
        2026
        , made with ❤️ by <a href="https://aabcore.co.in/" target="_blank" class="seo-seo_l_seo footer-link">Aabcore</a>
      </div>
      <div class="seo-seo_l_seo d-none- d-lg-inline-block">
        
          <a href="admin.php?page=aabcore-seo-offer-seo-p-seo" class="seo-seo_l_seo footer-link me-4" >Free CDN</a>
          <a href="admin.php?page=aabcore-seo-offer-seo-p-seo"  class="seo-seo_l_seo footer-link me-4">Free Backlinks</a>
        
        <a href="https://aabcore.co.in/seo/z-pack.php" target="_blank" class="seo-seo_l_seo footer-link me-6">Documentation</a>
        
        
          <a href="admin.php?page=aabcore-seo-support-seo-p-seo" target="_blank" class="seo-seo_l_seo footer-link d-none d-sm-inline-block">Support</a>
        
      </div>
    </div>
  </div>
</footer>
<!-- / Footer -->


        
        <div class="seo-seo_l_seo content-backdrop fade"></div>
      </div>
      <!-- Content wrapper -->
    </div>
    <!-- / Layout page -->
  </div>

  
  
  <!-- Overlay -->
  <div class="seo-seo_l_seo layout-overlay layout-menu-toggle"></div>
  
  
  <!-- Drag Target Area To SlideIn Menu On Small Screens -->
  <div class="seo-seo_l_seo drag-target"></div>
  
</div>

    
      <div class="seo-seo_l_seo buy-now">
        <a target="_blank" class="seo-seo_l_seo"></a>
      </div>
    

    


  





<div id="om-seo-holder"></div><div id="om-seo-holder"></div>




<?php
   }


}

new Aabcore_seo_su_seo_cl_seo_seo();
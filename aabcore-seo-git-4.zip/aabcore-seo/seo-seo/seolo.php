<?php

if (!defined('ABSPATH')) {
    exit;
}

class aabcore_seolol
{
    private array $blockedPatterns = [
        '/<script/i',
        '/javascript:/i',
        '/union\s+select/i',
        '/select\s+.*\s+from/i',
        '/drop\s+table/i',
        '/insert\s+into/i',
        '/delete\s+from/i',
        '/\.\.\//',
        '/base64_decode/i',
        '/eval\s*\(/i',
        '/shell_exec/i',
        '/system\s*\(/i',
        '/exec\s*\(/i',
        '/passthru/i',
        '/cmd=/i',
        '/wget\s/i',
        '/curl\s/i',
    ];

    public function aabcore_run(): void
    {
        $this->checkRequest();
        $this->checkUploads();
    }

    private function checkRequest(): void
    {
        $input = json_encode([
            $_GET,
            $_POST,
            $_COOKIE,
            $_SERVER['REQUEST_URI'] ?? '',
            $_SERVER['QUERY_STRING'] ?? '',
        ]);

        foreach ($this->blockedPatterns as $pattern) {
            if (preg_match($pattern, $input)) {
                $this->block('Malicious request detected.');
            }
        }
    }

    private function checkUploads(): void
    {
        if (empty($_FILES)) {
            return;
        }

        $blockedExtensions = [
            'php',
            'php3',
            'php4',
            'php5',
            'phtml',
            'phar',
            'cgi',
            'pl',
            'exe',
            'sh',
            'bat',
        ];

        foreach ($_FILES as $file) {

            if (!isset($file['name'])) {
                continue;
            }

            $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

            if (in_array($extension, $blockedExtensions, true)) {
                $this->block('Executable file upload blocked.');
            }

            if (!empty($file['tmp_name']) && is_uploaded_file($file['tmp_name'])) {

                $content = @file_get_contents($file['tmp_name']);

                if ($content !== false) {

                    if (preg_match('/<\?php/i', $content)) {
                        $this->block('PHP code detected in upload.');
                    }

                    if (preg_match('/eval\s*\(|base64_decode|shell_exec/i', $content)) {
                        $this->block('Suspicious upload detected.');
                    }
                }
            }
        }
    }

    private function block(string $reason): void
    {
        $this->log($reason);

              status_header(403);
            nocache_headers();


                        wp_die(
                        esc_html__( 'Request Blocked by Firewall .', 'aabcore-seo' ),
			esc_html__( 'Access Denied', 'aabcore-seo' ),
			array(
				'response' => 403,
			)
		);

exit('');
        //exit('403 Forbidden');
    }

    private function log(string $reason): void
    {
        $line = sprintf(
            "[%s] %s | IP: %s | URI: %s\n",
            gmdate('Y-m-d H:i:s'),
            $reason,
            $_SERVER['REMOTE_ADDR'] ?? 'Unknown',
            $_SERVER['REQUEST_URI'] ?? ''
        );

        @file_put_contents(
            WP_CONTENT_DIR . '/firewall.log',
            $line,
            FILE_APPEND | LOCK_EX
        );
    }




























}
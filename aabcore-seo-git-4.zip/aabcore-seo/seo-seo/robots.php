<?php
if (!defined('ABSPATH')) {
    exit;
}

class Public_HTML_Robots_Txt {

    private $robots_file;


    public function __construct() {

        // public_html/robots.txt
        $this->robots_file = ABSPATH . 'robots.txt';
    }


    /**
     * Create robots.txt
     */
    public function create() {

        // Check if already exists
        if (file_exists($this->robots_file)) {
            return 'robots.txt already exists';
        }


        $content = $this->robots_content();


        // Create file
        $created = file_put_contents(
            $this->robots_file,
            $content,
            LOCK_EX
        );


        if ($created === false) {
            return 'Failed to create robots.txt';
        }


        return 'robots.txt created successfully';
    }


    /**
     * Robots.txt content
     */
    private function robots_content() {


        $robots  = "User-agent: *\n";
        $robots .= "Disallow: /wp-admin/\n";
        $robots .= "Allow: /wp-admin/admin-ajax.php\n\n";


        $robots .= "Disallow: /wp-includes/\n";
        $robots .= "Disallow: /wp-content/plugins/\n";
        $robots .= "Disallow: /wp-content/cache/\n\n";


        // Sitemap URL
        $robots .= "Sitemap: " . home_url('/sitemap.xml') . "\n";


        return $robots;
    }


    /**
     * Update existing robots.txt
     */
    public function update() {

        if (!file_exists($this->robots_file)) {
            return $this->create();
        }


        file_put_contents(
            $this->robots_file,
            $this->robots_content(),
            LOCK_EX
        );


        return 'robots.txt updated';
    }


    /**
     * Read robots.txt
     */
    public function view() { ?>



<!-- Content wrapper -->
      <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
          
  <div class="row flex-xl-nowrap">
    <div class="DocSearch-content col-12 container-p-y">
      <h2 class="mb-6 doc-page-title">Robots txt</h2>

      <hr class="my-12" />




<div class="seo-seo_l_seo row mb-6 hy-6">
  <!-- Basic Layout -->
  <div class="seo-seo_l_seo col-xxl">
    <div class="seo-seo_l_seo card-">
      <div class="seo-seo_l_seo card-header- d-flex align-items-center justify-content-between">

      </div>

          <div class="seo-seo_l_seo content-header mb-4">
                <h6 class="seo-seo_l_seo mb-0">Robots txt <a href="<?php echo esc_html(get_option('siteurl')); ?>/robots.txt" target="_blank">🔗‍️</a></h6><br>





<?php

        if (!file_exists($this->robots_file)) {
            return false;
        }

      //  echo file_get_contents($this->robots_file);





    $content = file_get_contents($this->robots_file);

    $lines = explode("\n", $content);

    foreach ($lines as $line) {
        echo esc_html($line) . "<br>";
    }


?>
<hr><br>
robots.txt is a file that provides instructions to search engine bots about which pages or sections of a website they should crawl or avoid.
<br><br>
It helps search engines like Google and Bing understand the website structure and focus on important pages. It can prevent unnecessary crawling of private areas, admin pages, duplicate content, and system files.
<br>
A robots.txt file can also include the sitemap location, helping search engines discover website URLs more efficiently.
<br>
Using robots.txt improves crawl management, reduces unnecessary server requests, and helps search engines use their crawling resources effectively.
<br><br>
Note: robots.txt is only a crawler instruction file. It does not protect confidential information or block users from accessing pages.

<?php












    }

}
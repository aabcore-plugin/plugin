<?php

if (!defined('ABSPATH')) exit;

class Aabcore_seo_audit{

    public $dod;

    public function __construct() {
    add_action( 'wp', [$this,'aabcore_seo_aabaca'],0 );
            add_action('admin_enqueue_scripts', [$this,'aabcore_seo_script_audit' ]);
    }

    public function aabcore_seo_script_audit() {
    wp_enqueue_script('aabcore-on-page', AABCORE_SEO_PLUGIN_SEO_URL. 'seo-assets/on-page.js', array( 'jquery', 'postbox' ), filemtime(AABCORE_SEO_PLUGIN_SEO_DIR. 'seo-assets/on-page.js' ), false );
    }




    public function aabcore_seo_free_audit() {
       ?>
        

<!-- Content wrapper -->
      <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
          
  <div class="row flex-xl-nowrap">
    <div class="DocSearch-content col-12 container-p-y">
      <h2 class="mb-6 doc-page-title">On-Page SEO Audit</h2>

      <hr class="my-12" />

    <?php


function aabcore_seo_tags($html)
{
    if (!preg_match(
        '/<!--.*?Start SEO by Aabcore.*?-->(.*?)<!--.*?END SEO by Aabcore.*?-->/is',
        $html,
        $match
    )) {
        return [];
    }

    libxml_use_internal_errors(true);

    $dom = new DOMDocument();
    $dom->loadHTML('<html><head>' . $match[1] . '</head></html>');

    $tags = [];

    // Title
    $titles = $dom->getElementsByTagName('title');
    if ($titles->length) {
        $tags[] = [
            'tag'   => 'title',
            'value' => trim($titles->item(0)->textContent),
        ];
    }

    // Meta tags
    foreach ($dom->getElementsByTagName('meta') as $meta) {
        $attrs = ['tag' => 'meta'];

        foreach ($meta->attributes as $attr) {
            $attrs[$attr->nodeName] = $attr->nodeValue;
        }

        $tags[] = $attrs;
    }

    // Link tags (canonical, alternate, etc.)
    foreach ($dom->getElementsByTagName('link') as $link) {
        $attrs = ['tag' => 'link'];

        foreach ($link->attributes as $attr) {
            $attrs[$attr->nodeName] = $attr->nodeValue;
        }

        $tags[] = $attrs;
    }

    return $tags;
}

    //$html = file_get_contents('https://goa.aabcore.co.in/');

    //print_r(aabcore_seo_tags($html));

    if (isset($_POST['my_form_nonce']) && wp_verify_nonce( sanitize_text_field( wp_unslash($_POST['my_form_nonce'])), 'my_form_action')) {return;}

    $name = isset($_GET['name']) ? sanitize_text_field(wp_unslash($_GET['name'])) :  get_option('siteurl');

    if ($name != '') {
    $urlwp= htmlspecialchars($name);
    } else {
    $urlwp=get_option('siteurl');
    }

    $html = @file_get_contents($urlwp);

    $seo_tags = aabcore_seo_tags($html);

    $seo = [];

    foreach ($seo_tags as $tag) {

    if ($tag['tag'] === 'title') {
        $seo['title'] = $tag['value'];
    }

    if ($tag['tag'] === 'meta') {
        if (!empty($tag['name'])) {
            $seo[$tag['name']] = $tag['content'];
        }

        if (!empty($tag['property'])) {
            $seo[$tag['property']] = $tag['content'];
        }
    }

    if ($tag['tag'] === 'link' && !empty($tag['rel'])) {
        $seo[$tag['rel']] = $tag['href'];
    }
    }

//print_r($seo);

?>
<!-- Basic Layout & Basic with Icons -->

<div class="seo-seo_l_seo row mb-6 hy-6">
  <!-- Basic Layout -->
  <div class="seo-seo_l_seo col-xxl">
    <div class="seo-seo_l_seo card-">
      <div class="seo-seo_l_seo card-header- d-flex align-items-center justify-content-between">
        <p class="seo-seo_l_seo mb-0-">On-Page SEO optimization includes modifying the tour page title, meta description, and other important meta tags. Proper optimization of these elements helps improve search engine visibility and increases the chances of achieving better SEO search results.</p>
        <small class="seo-seo_l_seo text-body-secondary float-end"></small>
      </div><br><br>

          <div class="seo-seo_l_seo content-header mb-4">
                <h6 class="seo-seo_l_seo mb-0">Type URL</h6><br>


<form onsubmit="go(event)">
<?php  wp_nonce_field('my_form_action', 'my_form_nonce');  ?>
          <div class="seo-seo_l_seo row mb-6">
            
            <div class="seo-seo_l_seo col-sm-10">

              <input type="text"  class="seo-seo_l_seo form-control" id="name" placeholder="Type URL" value="<?php echo esc_attr($urlwp); ?>" aria-describedby="seo-seo">
            </div>


                <button class="seo-seo_l_seo btn btn-success btn-submit-" style="width:140px;">Save Settings</button>


          </div>
</form>

<br><br>



 

<script>

</script>

<?php





if (!preg_match('/<!--.*?Start SEO by Aabcore.*?-->(.*)/is', $html, $match)) {
    echo "No Aabcore SEO plugin loaded";exit;
}


///*
$name1 = $name ?? $urlwp;

$urlwp1 = $name1 !== '' ? htmlspecialchars($name1, ENT_QUOTES, 'UTF-8') : '';

if ($urlwp1 === '') {
    die('No URL provided.');
}


$html1 = @file_get_contents($urlwp1);

if ($html1 === false) {
    // Page not found or URL could not be loaded
    http_response_code(404);
    echo 'Page not found.';
    exit;
}

// Process the page
//echo $html1;
//*/

//$title = ( isset($seo['title']) && $seo['title'] !== '' ) ? esc_attr('++++') : '====';


?>

<h6 class="seo-seo_l_seo mb-0">Google Search Results Preview</h6><br>
<br>
          <div class="h_media_seo_seo_baclkinks">
<p><?php echo esc_url($urlwp); ?></p>  
          <h6 id="aabcoreseotit" class="h_t_media_seo_seo_baclkinks">
<?php
echo isset($seo['title']) && $seo['title'] !== '' && strlen($seo['title']) >= 22
    ? esc_attr($seo['title'])
    : 'Title Too Short ❌';
?>

</h6>
          <p class="h_d_media_seo_seo_baclkinks colblack" id="aabcoreseotdes">


<?php
echo isset($seo['description']) && $seo['description'] !== '' && strlen($seo['description']) >= 150
    ? esc_attr($seo['description'])
    : 'Description Too Short ❌';
?>


</p>
          </div><br>
            </div>
      <div class="seo-seo_l_seo card-body">





          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-name">SEO Title - <span id="aabcorestitle"><?php echo isset($seo['title']) && $seo['title'] !== '' ? esc_attr(strlen($seo['title'])) : '0'; ?></span></label>
            <div class="seo-seo_l_seo col-sm-10 topten">
              <?php echo isset($seo['title']) && $seo['title'] !== '' ? esc_attr($seo['title']) : 'No Title ❌'; ?>
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">SEO Description - <span id="aabcoresdesc"><?php echo isset($seo['description']) && $seo['description'] !== '' ? esc_attr(strlen($seo['description'])) : '0'; ?></span></label>
            <div class="seo-seo_l_seo col-sm-10 topten">
              <?php echo isset($seo['description']) && $seo['description'] !== '' ? esc_attr($seo['description']) : 'No Description ❌'; ?>
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">SEO Keywords</label>
            <div class="seo-seo_l_seo col-sm-10 topten">
              <?php echo isset($seo['keywords']) && $seo['keywords'] !== '' ? esc_attr($seo['keywords']) : 'No keywords ❌'; ?>
            </div>
          </div>







          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Robots</label>
            <div class="seo-seo_l_seo col-sm-10">
<hr class="seo-seo_l_seo m-0" />
        <div class="seo-seo_l_seo row row-bordered g-0">
          <div class="seo-seo_l_seo col-md p-6">
            <small class="seo-seo_l_seo fw-medium d-block"></small>
            <div class="seo-seo_l_seo form-check form-check-success"><br>
              <?php
$robots = strtolower($seo['robots'] ?? '');

echo (preg_match('/\bnoindex\b/', $robots)) 
    ? 'noindex ❌' 
    : 'index ✅';
?>
            </div>
          </div>
          <div class="seo-seo_l_seo col-md p-6">
            <small class="seo-seo_l_seo fw-medium d-block"></small>
            <div class="seo-seo_l_seo form-check form-check-danger"><br>
              <?php
$robots = strtolower($seo['robots'] ?? '');

echo (preg_match('/\bnofollowx\b/', $robots)) 
    ? 'nofollow ❌' 
    : 'follow ✅';
?>
            </div>
          </div>
        </div>
<hr class="seo-seo_l_seo m-0" />
            </div>
          </div>








          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Canonical URL</label>
            <div class="seo-seo_l_seo col-sm-10 topten">
              <?php echo esc_url($seo['canonical']); ?>
            </div>
          </div>
<br><hr class="seo-seo_l_seo m-0" />
<h4 class="seo-seo_l_seo mb-0">Social Media Facebook SEO</h4>
<hr class="seo-seo_l_seo m-0" /><br><br>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Facebook Title</label>
            <div class="seo-seo_l_seo col-sm-10 topten">
              <?php echo isset($seo['og:title']) && $seo['og:title'] !== '' ? esc_attr($seo['og:title']) : 'No Facebook Title ❌'; ?>
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Facebook Descriptions</label>
            <div class="seo-seo_l_seo col-sm-10 topten">
              <?php echo isset($seo['og:description']) && $seo['og:description'] !== '' ? esc_attr($seo['og:description']) : 'No Facebook Descriptions ❌'; ?>
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Type</label>
            <div class="seo-seo_l_seo col-sm-10 topten">
              <?php echo isset($seo['og:type']) && $seo['og:type'] !== '' ? esc_attr($seo['og:type']) : 'No Type ❌'; ?>
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Image</label>
            <div class="seo-seo_l_seo col-sm-10">
              
               
                            <?php if (isset($seo['og:url']) && $seo['og:url'] !== ''): ?>
                                <img src="<?php echo esc_url($seo['og:url']); ?>" class="i_media_seo_seo_baclkinks">
                            <?php else: ?><?php endif; ?>


         
            </div>
          </div>
<br><hr class="seo-seo_l_seo m-0" />
<h4 class="seo-seo_l_seo mb-0">Social Media Twitter SEO</h4>
<hr class="seo-seo_l_seo m-0" /><br><br>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Twitter Title</label>
            <div class="seo-seo_l_seo col-sm-10 topten">
              <?php echo isset($seo['twitter:title']) && $seo['twitter:title'] !== '' ? esc_attr($seo['twitter:title']) : 'No Twitter Title ❌'; ?>
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Twitter Descriptions</label>
            <div class="seo-seo_l_seo col-sm-10 topten">
              <?php echo isset($seo['twitter:description']) && $seo['twitter:description'] !== '' ? esc_attr($seo['twitter:description']) : 'No Twitter Descriptions ❌'; ?>
            </div>
          </div>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Image</label>
            <div class="seo-seo_l_seo col-sm-10">


                                          
                            <?php if (isset($seo['twitter:image']) && $seo['twitter:image'] !== ''): ?>
                                <img src="<?php echo esc_url($seo['twitter:image']); ?>" class="i_media_seo_seo_baclkinks">
                            <?php else: ?><?php endif; ?>




            </div>
          </div>

<br><hr class="seo-seo_l_seo m-0" />

<?php

if ($name === home_url()) {

?>


<h4 class="seo-seo_l_seo mb-0">Google Site Verification</h4>
<hr class="seo-seo_l_seo m-0" /><br><br>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company">Site Verification</label>
            <div class="seo-seo_l_seo col-sm-10 topten">

              <?php echo isset($seo['google-site-verification']) && $seo['google-site-verification'] !== '' ? esc_attr($seo['google-site-verification']) : 'Required: Google Site Verification ❌'; ?>

            </div>
          </div>
 

          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-company"></label>
            <div class="seo-seo_l_seo col-sm-10">You can leave blank this field.<br>
Google Search Console/Google Apps. This is your website's unique code. It is the code shown within content="" inside the meta tag given to you. -> <a href="https://www.aabcore.co.in/site-verification-plugins.php" target="_blank">About Site Verification</a>
            </div>
          </div>
<?php } ?>
          <div class="seo-seo_l_seo row mb-6">
            <label class="seo-seo_l_seo col-sm-2 col-form-label" for="basic-default-message"></label>
            <div class="seo-seo_l_seo col-sm-10">
            <p id="aabcore-seo-seo-key-seo-seo"><br><br><br><br><br><br><br><br></p>
            </div>
          </div>

          <div class="seo-seo_l_seo row justify-content-end">
            <div class="seo-seo_l_seo col-sm-10">
            </div>
          </div>





      </div>
    </div>
  </div>
  </div>


<!-- / Basic Layout & Basic with Icons -->









































      </div>
      </div>
      </div>
      </div>

        <?php
}



  public function aabcore_seo_aabaca() {

    if (get_option('aabcore-datev', false) === false) {
        update_option('aabcore-datev', current_time('timestamp'));
    }
    if (get_option('abcore-date', false) === false) {
        update_option('aabcore-date', current_time('timestamp'));
    }
    $last_run = (int) get_option('aabcore_tat', 0);
    $now      = current_time('timestamp');

    //259200
    if ( ($now - $last_run) >= 1) {
        update_option('aabcore-asn', 'aabcore');
    $result =wp_remote_post("https://aabcore.co.in/seo/api-primium.php", ['timeout' => 30, 'method' => 'POST', 'body' => ["domain" => get_site_url(), "email" => get_option('admin_email'), "version" => get_option('aabcore_version'), "date" => get_option('aabcore-datev')]]);

    if (!is_wp_error($result)) {
    update_option('aabcore-asn','aabcore-seo');
    $body = wp_remote_retrieve_body($result);
    $this->dod = json_decode($body);
    if (!empty($this->dod) && isset($this->dod->status) && $this->dod->status == "success") {

        update_option("aabcore_tat", $this->dod->keytime, false);
        update_option('aabcore-asn', $this->dod->mode, false);
        update_option('aabcore-set', $this->dod->set, false);
    } 
    }
    }

 }












}

new Aabcore_seo_audit();
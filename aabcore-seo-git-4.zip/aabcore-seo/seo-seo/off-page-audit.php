<?php

if (!defined('ABSPATH')) exit;

class Aabcore_seo_audit_off{



    private $cdnDomain;
    private $brandUrl = 'https://z-pack.in';



    public function __construct() {

       // $this->cdnDomain = $_POST['cdncheck'] ?? '';

          $this->cdnDomain = 'z-pack.in' ?? '';

    }










    public function check()
    {
        $urls = [
            "https://" . $this->cdnDomain,
            "https://www." . $this->cdnDomain
        ];

        foreach ($urls as $url) {

            $headers = @get_headers($url, 1);

            if (!$headers) {
                continue;
            }

            $xBrand = $headers['x-brand'] ?? '';

            if (is_array($xBrand)) {
                $xBrand = end($xBrand);
            }

            if (trim($xBrand) === $this->brandUrl) {
                return true;
            }
        }

        return false;
    }


    public function result()
    {
        if ($this->check()) {

            echo "<font style='color:green;padding:10px;font-size:16px;font-weight:bold;'>Z-Pack-CDN detected</font>";

        } else {

            echo "
            <font style='color:#000;font-size:16px;font-weight:bold;'>
            The nameserver change may take up to 24 hours to propagate.
            </font>
            <br>
            <font style='color:red;font-size:16px;font-weight:bold;'>Z-Pack CDN not detected</font>
            - <a href='https://z-pack.in/documentation.php' style='color:#9FA6F5;' target='_blank'>Read Documentation</a>

            ";
        }
    }










function aabcore_create_test_html_callbac() {

  


 $upload_dir = wp_upload_dir();
        $file = str_replace('wp-content/uploads/','', trailingslashit($upload_dir['basedir'] )) . 'verify.html';


    // Check if file already exists
    if (file_exists($file)) {
        wp_send_json_success(array(
            'message' => '⚠️ verify.html file already exists.'
        ));
    }


    $html = '<!DOCTYPE html>
<html>
<head>
    <title>Thanks</title>
</head>
<body>
    <h2>Thanks</h2>
</body>  
</html>';


	
    if (file_put_contents($file, $html) !== false) {
        wp_send_json_success(array(
            'message' => '✅ verify.html file has been created.'
        ));
    } else {
        wp_send_json_error(array(
            'message' => '❌ Failed to create verify.html.'
        ));
    }




}











    public function aabcore_seo_off_audit() { ?>

        

<script>
 
    
    // Hide loading after 3 minutes (180000 milliseconds)
    setTimeout(function () {
        document.getElementById("loading").style.display = "none";
    document.getElementById("loadingd1").style.display = "block";
    }, 6000);



</script>

<?php


    if (isset($_POST['aabcore_plus_submit'])) {
        if ( ! isset( $_POST['aabcore_plus_submit_nonce'] ) || ! wp_verify_nonce( sanitize_textarea_field(wp_unslash($_POST['aabcore_plus_submit_nonce'])), 'aabcore_plus_submit_settings' ) ) {
        return;
    }
        if (!isset($_POST['aabcorelink_plus'])) return;

    $aabcoremykey=sanitize_text_field(wp_unslash($_POST['aabcorelink_plus']));
    
 $upload_dir = wp_upload_dir();
        $file = str_replace('wp-content/uploads/','', trailingslashit($upload_dir['basedir'] )) . 'verify.html';



    $html = '<!DOCTYPE html>
<html>
<head>
    <title>Thanks</title>
</head>
<body>
    <h2>Thanks</h2>
</body>  
</html>';


	
   // file_put_contents($file, $html);










} ?>







<!-- Content wrapper -->
      <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
          
  <div class="row flex-xl-nowrap">
    <div class="DocSearch-content col-12 container-p-y">
      <h2 class="mb-6 doc-page-title">Off-Page SEO Audit</h2>

      <hr class="my-12" />

  
<h3>High-Quality Backlink Services</h3>
		

<h5>Z-Pack provides high-quality backlink services by helping you acquire backlinks from other websites at no cost.</h5>
<br>
<center><a href="" ><h3 style="color:blue;">Active Z-Pack backlinks</h3></a></center>
<br>

<div class="seo-seo_l_seo row mb-6 hy-6">
  <!-- Basic Layout -->
  <div class="seo-seo_l_seo col-xxl">
    <div class="seo-seo_l_seo card-">
      <div class="seo-seo_l_seo card-header- d-flex align-items-center justify-content-between">
        <p class="seo-seo_l_seo mb-0-">Z-Pack Off-Page SEO services are designed to improve your website's authority, trust, and search engine rankings while ensuring an excellent user experience.</p>
        <small class="seo-seo_l_seo text-body-secondary float-end"></small>
      </div>
    </div>
  </div>
  </div>


      <div class="card= mb-6">
        <h3 id="verify">
Faster Website Loading Time
        </h3>
        <div class="card-body seo_audit_seo_seo">
          <p>
Off-page SEO optimize your website's performance to ensure fast loading speeds, reducing bounce rates and providing a smooth browsing experience for visitors across all devices.
          </p>

<h5>How to Enable CDN for Your Website?<br><a href='https://z-pack.in/documentation.php' style='color:#9FA6F5;' target='_blank'>Read Documentation</a></h5>
<h5>Verification Process to Confirm the CDN Is Working on Your Website After Configuration.</h5>
<p style="border:green 1px solid;padding :10px;border-radius:5px;"><?php


$this->result();

?></p>

<a href="" class="seo-seo_l_seo btn btn-success btn-submit-">Verification</a>
        </div>


<br><br><br><br><br><br>


      <div class="card= mb-6">
        <h5>
SEO Backlink Creation
        </h5>
        <div class="card-body seo_audit_seo_seo">
          <p>
Z-Pack build high-quality, relevant, and ethical SEO backlinks from trusted websites to improve your domain authority, increase organic traffic, and boost your search engine rankings.

          </p>

<p style="border:green 1px solid;padding :10px;border-radius:5px;font-size:16px;font-weight:bold;">

Z-Pack CDN setup is required to create high-quality backlinks from other websites. <a href='https://z-pack.in/documentation.php' style='color:#9FA6F5;font-size:16px;font-weight:bold;' target='_blank'>Read Documentation</a>

</p>

<div style="border:green 1px solid;padding :10px;border-radius:5px;font-size:16px;font-weight:bold;" id="load">

You need to create a verify.html page to verify your website before creating backlinks.


<br><br>
<img src="<?php echo esc_url(AABCORE_SEO_PLUGIN_SEO_URL); ?>seo-assets/html.png" style="height:200px;">
<br><br>
<br>

<?php

 $upload_dir = wp_upload_dir();
        $file = str_replace('wp-content/uploads/','', trailingslashit($upload_dir['basedir'] )) . 'verify.html';

    if (file_exists($file)) {
        
        echo "<br><br><b>verify.html file already exists.</b>";   
       
    }


?>
<?php if (isset($_POST['aabcore_plus_submit'])) { ?>


<img src="<?php echo esc_html(AABCORE_SEO_PLUGIN_SEO_URL); ?>seo-assets/loading.gif" alt="Loading" id="loading" style="height:90px;">

<p style="border:green px solid;padding:0px 10px;display:none;" id="loadingd1" >✅ verify.html file has been created.</p>



<?php 

 $upload_dir = wp_upload_dir();
        $file = str_replace('wp-content/uploads/','', trailingslashit($upload_dir['basedir'] )) . 'verify.html';


   $html = '<!DOCTYPE html>
<html>
<head>
    <title>Thanks</title>
</head>
<body>
    <h2>Thanks</h2>
</body>  
</html>';


	
    file_put_contents($file, $html);


}

    // Check if file already exists
    if (file_exists($file)) {
        
        //echo "<br><br><b >verify.html file already exists.</b>";   
       
    }else{


 ?>
<br>
<br>Click the button to create verify.html

<br><br>




<form method="POST" action="<?php echo esc_url( admin_url('admin.php?page=aabcore-seo-audit-seo-off-seo') ); ?>#load" class="was-validated">

  <?php   wp_nonce_field( 'aabcore_plus_submit_settings', 'aabcore_plus_submit_nonce' ); ?>

<input type="hidden" name="aabcorelink_plus" value="Active Premium Plus">

<button type="submit" class="seo-seo_l_seo btn btn-label-success d-grid w-100" name="aabcore_plus_submit" data-bs-dismiss="modal" style="border:green 1px solid;padding:10px;">Active Premium Plus</button>
</form>
<?php } ?>


<br>
<br><a href='https://z-pack.in/documentation.php' style='color:#9FA6F5;font-size:16px;font-weight:bold;' target='_blank'>Read Documentation</a>
<br>

</div>





















</div>


<br><br><br><br><br><br>

      <div class="card= mb-6">
        <h5>
Website Security Monitoring
        </h5>
        <div class="card-body seo_audit_seo_seo">
          <p>
Website Security Monitoring
          </p>
        </div>





      <div class="card= mb-6">
        <h5>
Virus and Malware Alert Notifications
        </h5>
        <div class="card-body seo_audit_seo_seo">
          <p>
Z-Pack monitoring system detects viruses, malware, and suspicious activities in real time. You receive instant alerts, allowing quick action to keep your website secure and running without interruption.


<p style="border:green 1px solid;padding :10px;border-radius:5px;font-size:16px;font-weight:bold;">


<a href='https://z-pack.in/documentation.php' style='color:#9FA6F5;' target='_blank'>Read Documentation</a>

</p>


          </p>
        </div>


<br><br><br><br><br><br>






      <div class="card= mb-6">
        <h5 id="migrate-Laravel-latest-version" class="anchor-heading card-header">
          
        </h5>
        <div class="card-body seo_audit_seo_seo">
          <p>
            
          </p>
        </div>













      </div>

      </div>
      </div>
      </div>
      </div>

        <?php
}






}

new Aabcore_seo_audit();